﻿    # Введенные мною вспомогательные переменные
define player_name = ""
define gender = ""
define architect = 0
define botanist = 0
define archaeologist = 0
define journalist = 0

define reality = 0
define ghost = 0
define t_name = "Неизвестный"

define book_lermnt = 0
define book_canal = 0
define book_coi = 0
define book_misticPeter = 0
define book_promish = 0
define book_rest = 0

define rightornot = 0
define time_menu = 0
define verno = 0

define scenered = 0
define sceneredbook = 0

define scenehuse = 0
define zagadka = 0
define scenehusebook = 0

define scenemedic = 0
define zagadkamedic = 0

define zagadkaotragenie = 0

define scenepht = 0
define sceneised = 0
define seria4vibr = 0
define attack = 0
define vstret_rab = 0

    # Определение персонажей
define character = DynamicCharacter("player_name", color="#ffffff")
define tmrz = DynamicCharacter("t_name", color="#ffffff")

define characterchildren = Character("Призрак ребёнка", color="#ffffff")
define characterht1 = Character("Хтонь", color="#ffffff")
define characterht2 = Character("Призрак дуэлянта", color="#ffffff")
define characterlerm = Character("Лермонтов", color="#ffffff")
define charactermagic = Character("Колдун", color="#ffffff")
define characterpevica = Character("Певица", color="#ffffff")
define characterfish = Character("Русалка", color="#ffffff")
define characterpacient = Character("Пациент", color="#ffffff")
define characterht3 = Character("Хтонь", color="#ffffff")
define characterpiyanica = Character("Призрак пьяницы", color="#ffffff")
define characterwrker = Character("Призрак рабочего", color="#ffffff")
define characterwrkhe = Character("Рабочий", color="#ffffff")
define characterwrkshe = Character("Призрак рабочей", color="#ffffff")
define characterVoiswrk = Character("Голос работающих", color="#ffffff")
define characternikolay2 = Character("Император Николай II", color="#ffffff")
define characterpolicia = Character("Полицейский", color="#ffffff")
define characterdoctor = Character("Врач", color="#ffffff")

define characterlena = Character("Библиотекарь Елена", color="#ffffff")
define characteririnaErnestovna = Character("Заведующая", color="#ffffff")
define characteririna = Character("Библиотекарь Ирина", color="#ffffff")
define characterelizaveta = Character("Библиотекарь Елизавета", color="#ffffff")
define characteranastasia = Character("Библиотекарь Анастасия", color="#ffffff")

define characterotragenie = Character("Отражение", color="#ffffff")
define characterghost = Character("Призрак", color="#ffffff")
define characterPrd = Character("Продавец", color="#ffffff") 
define characterCir = Character("Цирюльник", color="#ffffff")
define characterVois = Character("Голос", color="#ffffff")

    # Изображения средней концовки good
image anastasia_2 = "images/good/anastasia_2.png"
image elisaveta_2 = "images/good/elisaveta_2.png"
image irina_2 = "images/good/irina_2.png"
image irina_Ernestovna_2 = "images/good/irina_Ernestovna_2.png"
image lena2 = "images/good/lena2.png"
image 1_1_2 = "images/good/1_1.webp"
image 2_1_2 = "images/good/2_1.webp"
image 3_1_2 = "images/good/3_1.webp"
image 4_1_2 = "images/good/4_1.webp"
image titri_2 = "images/good/Titri_2.webp"

    # Изображения хорошей концовки great
image anastasia_3 = "images/great/anastasia_3.png"
image elisaveta_3 = "images/great/elisaveta_3.png"
image irina_3 = "images/great/irina_3.png"
image irina_Ernestovna_3 = "images/great/irina_Ernestovna_3.png"
image lena_3 = "images/great/lena_3.png"
image 1_0_3 = "images/great/1.webp"
image 1_1_3 = "images/great/1.1.webp"
image 1_2_3 = "images/great/1.2.webp"
image 1_3_3 = "images/great/1.3.webp"
image 1_4_3 = "images/great/1.4.webp"
image 1_5_3 = "images/great/1.5.webp"
image 1_6_3 = "images/great/1.6.webp"
image 1_7_3 = "images/great/1.7.webp"
image 1_8_3 = "images/great/1.8.webp"
image 1_9_3 = "images/great/1.9.webp"
image 1_10_3 = "images/great/1.10.webp"
image titri_3 = "images/great/Titri_3.webp"

    # Изображения плохой концовки plox
image g_1 = "images/plox/G_1.webp"
image g_ryki0 = "images/plox/G_ryki0.webp"
image g_ryki1 = "images/plox/G_ryki1.webp"
image g_ryki2 = "images/plox/G_ryki2.webp"
image g_ryki3 = "images/plox/G_ryki3.webp"
image m_1 = "images/plox/M_1.webp"
image m_ryki0 = "images/plox/M_ryki0.webp"
image m_ryki1 = "images/plox/M_ryki1.webp"
image m_ryki2 = "images/plox/M_ryki2.webp"
image m_ryki3 = "images/plox/M_ryki3.webp"
image titri_1 = "images/plox/titri_1.webp"
image skapina = "images/plox/skapina.webp"

    # Изображения back
image seria1 = "seria/1_seria.webp"
image seria2 = "seria/2_seria.webp"
image seria3 = "seria/3_seria.webp"
image seria4 = "seria/4_seria.webp"
image seria5 = "seria/5_seria.webp"

image back0 = "back1/0.webp" 
image back1 = "back1/1.webp"
image back2 = "back1/2.webp"
image back3 = "back1/3.webp"
image back4 = "back1/4.webp"
image back5 = "back1/5.webp"
image back6 = "back1/6.webp"
image back7 = "back1/7.webp"
image back8 = "back1/8.webp"
image back9 = "back1/9.webp"
image back10 = "back1/10.webp"
image back11 = "back1/11.webp"
image back12 = "back1/12.webp"
image back12_1 = "back1/12.1.webp"
image back12_2 = "back1/12.2.webp"
image back13 = "back1/13.webp"
image back14 = "back1/14.webp"
image back15 = "back1/15.webp"
image back16 = "back1/16.webp"
image back17 = "back1/17.webp"

image 1back1 = "back2/1.webp"
image 1back2 = "back2/2.webp"
image 1back3 = "back2/3.webp"
image 1back4 = "back2/4.webp"
image 1back5 = "back2/5.webp"
image 1back6 = "back2/6.webp"
image 1back7 = "back2/7.webp"
image 1back8 = "back2/8.webp"
image 1backtime1 = "back2/time1.webp"
image 1backtime2 = "back2/time2.webp"
image 1backtime3 = "back2/time3.webp"
image 1backtime4 = "back2/time4.webp"
image 1backtime5 = "back2/time5.webp"
image 1backtimemen = "back2/timemen.webp"

image 2back1 = "back3/1.webp"
image 2back2 = "back3/2.webp"
image 2back3 = "back3/3.webp"
image 2back4 = "back3/4.webp"
image 2back5 = "back3/5.webp"
image 2back6 = "back3/6.webp"
image 2back7 = "back3/7.webp"
image 2back8 = "back3/8.webp"
image 2back9 = "back3/9.webp"
image 2back10 = "back3/10.webp"
image 2back11 = "back3/11.webp"

image 3back1 = "back4/1.webp"
image 3back2 = "back4/2.webp"
image 3back3 = "back4/3.webp"
image 3back4 = "back4/4.webp"
image 3back5 = "back4/5.webp"
image 3back6 = "back4/6.webp"
image 3back7 = "back4/7.webp"
image 3back8 = "back4/8.webp"
image 3back9 = "back4/9.webp"
image 3back10 = "back4/10.webp"
image 3back11 = "back4/11.webp"

image 4back1 = "back5/1.webp"
image 4back2 = "back5/2.webp"
image 4back3 = "back5/3.webp"
image 4back4 = "back5/4.webp"
image 4back5 = "back5/5.webp"
image 4back6 = "back5/6.webp"
image 4back7 = "back5/7.webp"

init python:
    if renpy.variant("ios"):
        video_format = "mov"
    else:
        video_format = "mp4"

image anim1 = Movie(
    play="images/anim/12." + video_format,
    mask=None
)

image animcon1 = Movie(
    play="images/anim/animcon1." + video_format,
    mask=None
)

image animcon23 = Movie(
    play="images/anim/animcon3." + video_format,
    mask=None
)

    # Изображения book
image canal = "images/book/canal.webp"
image coi = "images/book/coi.webp"
image lermnt = "images/book/lermnt.webp"
image misticPeter = "images/book/mistic_peter.webp"
image promish = "images/book/promish.webp"
image rest = "images/book/rest.webp"

    # Изображения character
image m0 = "images/M/m0.webp"
image m1 = "images/M/m1.webp"
image m2 = "images/M/m2.webp"
image m3 = "images/M/m3.webp"
image m4 = "images/M/m4.webp"
image m5 = "images/M/m5.webp"
image m6 = "images/M/m6.webp"
image m7 = "images/M/m7.webp"
image m8 = "images/M/m8.webp"
image g0 = "images/G/g0.webp"
image g1 = "images/G/g1.webp"
image g2 = "images/G/g2.webp"
image g3 = "images/G/g3.webp"
image g4 = "images/G/g4.webp"
image g5 = "images/G//g5.webp"
image g6 = "images/G/g6.webp"
image g7 = "images/G/g7.webp"
image g8 = "images/G/g8.webp"
image t1 = "images/T/t1.webp"
image t2 = "images/T/t2.webp"

    # Изображения ghost
image ghost_children = "images/ghosts/children.webp"
image ghost_pacient = "images/ghosts/dntname.webp"
image ghost_fish = "images/ghosts/fish.webp"
image ghost_ht1 = "images/ghosts/ht1.webp"
image ghost_ht2 = "images/ghosts/ht2.webp"
image ghost_ht3 = "images/ghosts/ht3.webp"
image ghost_lerm = "images/ghosts/lerm.webp"
image ghost_magic = "images/ghosts/magic.webp"
image ghost_pevica = "images/ghosts/pevica.webp"
image ghost_piyanica = "images/ghosts/piyanica.webp"
image ghost_wrker = "images/ghosts/wrker.webp"
image ghost_wrkhe = "images/ghosts/wrkhe.webp"
image ghost_wrkshe = "images/ghosts/wrkshe.webp"

image ghost_doctor = "images/ghosts/doctor.png"
image ghost_g = "images/ghosts/G_ghost.png"
image ghost_m = "images/ghosts/M_ghost.png"
image ghost_nikolai = "images/ghosts/Nikolai.png"
image ghost_policia = "images/ghosts/policia.png"

    # Музыка
define ball = "audio/ball.ogg"
define bany = "audio/bany.ogg"
define calmness = "audio/calmness.ogg"
define conec_1 = "audio/conec_1.ogg"
define conec_2 = "audio/conec_2.ogg"
define conec_3 = "audio/conec_3.ogg"
define dktsoy = "audio/dktsoy.ogg"
define factory = "audio/factory.ogg"
define ghostWorld = "audio//ghostWorld.ogg"
define haspit = "audio/haspit.ogg"
define imperator = "audio/imperator.ogg"
define mermaiddone = "audio/mermaiddone.ogg"
define name = "audio/name.ogg"
define office = "audio/office.ogg"
define titleMaster = "audio/titleMaster.ogg"
define untitledMaster = "audio/untitledMaster.ogg"

# Статы
init python:
    def change_stat(stat_name, delta):
        current_value = getattr(store, stat_name)
        new_value = max(0, current_value + delta)
        setattr(store, stat_name, new_value)
        renpy.restart_interaction()
screen stats_counter():
    # Отображение в левом верхнем углу
    frame:
        xpos 10
        ypos 5
        background None
        padding (10, 10)
        
        hbox:
            spacing 20
            vbox:
                spacing 5
                text "Призрак [ghost]" size 24 color "#ffffff" outlines [(1, "#000000", 0, 0)]
                hbox:
                    spacing 5
                    textbutton "-" action Function(change_stat, "ghost", -1)
                    textbutton "+" action Function(change_stat, "ghost", 1)
            vbox:
                spacing 5
                text "Явь [reality]" size 24 color "#ffffff" outlines [(1, "#000000", 0, 0)]
                hbox:
                    spacing 5
                    textbutton "-" action Function(change_stat, "reality", -1)
                    textbutton "+" action Function(change_stat, "reality", 1)
            vbox:
                $ total_books = book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest
                spacing 5
                text "Книг [book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest]" size 24 color "#ffffff" outlines [(1, "#000000", 0, 0)]
                hbox:
                    spacing 5
                    textbutton "-" action Function(change_stat, "book_lermnt", -1)
                    textbutton "+" action Function(change_stat, "book_lermnt", 1) sensitive (total_books < 6)

    # Два столбца с остальными переменными
    # frame:
    #     xpos 10
    #     ypos 100
    #     background Solid("#000000AA")
    #     padding (10, 10)
    #     hbox:
    #         spacing 40
    #         # Левый столбец
    #         vbox:
    #             spacing 5
    #             text "rightornot: [rightornot]" size 20 color "#ffffff" 
    #             text "time_menu: [time_menu]" size 20 color "#ffffff" 
    #             text "verno: [verno]" size 20 color "#ffffff" 
    #             text "scenered: [scenered]" size 20 color "#ffffff" 
    #             text "sceneredbook: [sceneredbook]" size 20 color "#ffffff" 
    #             text "scenehuse: [scenehuse]" size 20 color "#ffffff" 
    #             text "zagadka: [zagadka]" size 20 color "#ffffff" 
    #             text "scenehusebook: [scenehusebook]" size 20 color "#ffffff" 
    #             text "scenemedic: [scenemedic]" size 20 color "#ffffff" 
    #             text "zagadkamedic: [zagadkamedic]" size 20 color "#ffffff" 
    #             text "scenepht: [scenepht]" size 20 color "#ffffff" 
    #             text "sceneised: [sceneised]" size 20 color "#ffffff" 
    #             text "seria4vibr: [seria4vibr]" size 20 color "#ffffff" 
    #             text "t_name: [t_name]" size 20 color "#ffffff"
    #             text "all_book: [book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest]" size 20 color "#ffffff"
    #         # Правый столбец
    #         vbox:
    #             spacing 5
    #             text "attack: [attack]" size 20 color "#ffffff" 
    #             text "vstret_rab: [vstret_rab]" size 20 color "#ffffff" 
    #             text "architect: [architect]" size 20 color "#ffffff" 
    #             text "botanist: [botanist]" size 20 color "#ffffff" 
    #             text "archaeologist: [archaeologist]" size 20 color "#ffffff" 
    #             text "journalist: [journalist]" size 20 color "#ffffff" 
    #             text "book_lermnt: [book_lermnt]" size 20 color "#ffffff" 
    #             text "book_canal: [book_canal]" size 20 color "#ffffff" 
    #             text "book_coi: [book_coi]" size 20 color "#ffffff" 
    #             text "book_misticPeter: [book_misticPeter]" size 20 color "#ffffff" 
    #             text "book_promish: [book_promish]" size 20 color "#ffffff" 
    #             text "book_rest: [book_rest]" size 20 color "#ffffff" 
    #             text "player_name: [player_name]" size 20 color "#ffffff" 
    #             text "gender: [gender]" size 20 color "#ffffff"
init python:
    # Добавляем экран в список постоянно отображаемых
    config.overlay_screens.append("stats_counter")   

# Таймер
# $ return_label = "name_scene"        
# show screen choice_timer(time_value)
screen choice_timer(duration):
    default time_left = duration
    timer 0.1 repeat True action If(time_left > 0, 
        SetScreenVariable("time_left", time_left - 0.1), 
        [Hide("choice_timer"), Jump(return_label)]
    )
    
    # Отображение таймера
    vbox:
        xalign 0.5
        ypos 50
        text "Осталось времени:" size 25
        text "[int(time_left)] сек" size 40 color "#f00" bold True
    
    # Автоматический переход при истечении времени
    if time_left <= 0:
        timer 0.01 action [Hide("choice_timer"), Jump(return_label)]

# Мини игра с поиском предмета (расположение тригера)
screen find_item_game_1():
    # Невидимая кнопка в области предмета (координаты x, y, ширина, высота)
    imagebutton:
        xpos 1038  # Настройте под ваше изображение
        ypos 555
        xsize 91
        ysize 129
        idle Solid("#0000")  # Прозрачный цвет
        action [Return("found")]  # Возврат значения при клике

# Титры
init python:
    def credits_transform(trans, st, at, speed, text_height):
        # Вычисляем новую позицию Y на основе времени и скорости
        trans.yoffset = int(-st * speed)
        
        # Когда текст полностью ушел за верхний край
        if st * speed > text_height + 720:  # Высота текста + высота экрана
            return None  # Завершаем трансформ
        return 0
    
    # Создаем обертку для передачи скорости и высоты текста
    def make_credits_transform(speed, text_height):
        return lambda trans, st, at: credits_transform(trans, st, at, speed, text_height)

screen credits(text_content, scroll_speed=50, display_duration=15):
    zorder 100
    
    # Фоновое изображение
    add "titri_3":
        size (1280, 720)
        fit "fill"
    
    # Затемняющий слой с плавным появлением
    add Solid("#000"):
        alpha 0.70
    
    # Вычисляем высоту текста (примерно 40 пикселей на строку)
    $ text_height = len(text_content.split("\n")) * 40
    
    # Контейнер для текста титров
    frame:
        background None
        xsize 1000
        ysize text_height  # Высота текста
        xalign 0.45
        ypos 720  # Начальная позиция (низ экрана)
        
        text text_content:
            size 28
            color "#ffffff"
            text_align 0.5
            xalign 0.5
            yalign -0.5
            line_spacing 5
            
        # Анимация прокрутки
        at transform:
            function make_credits_transform(scroll_speed, text_height)
    
    # Таймер для автоматического выхода
    timer display_duration action [Hide("credits", transition=dissolve), Return()]
    
    # Кнопка для пропуска
    key "dismiss" action [Hide("credits", transition=dissolve), Return()]



# Начало игры
label start:
    window hide
    with None
    # кат - сцена
    scene seria1 with fade:
        size (1280, 720)
        fit "fill"
    $ renpy.pause(delay=4.0, hard=True)
    stop music fadeout 2.0
    play music titleMaster fadein 2.0 loop if_changed
    scene back1 with Dissolve(2.0):
        size (1280, 720)
        fit "fill"
    "Санкт-Петербург — мой родной город… Город с богатой историей и архитектурой. Тут белые ночи и разводные мосты. Он непокорный, гордый и бесконечно красивый."
    "Мне казалось, я знаю его достаточно хорошо: каждую улочку, канал, дворец, музей. Но, как и все жители Северной столицы, я забываю, насколько он многогранен."
    jump scene1

label scene1:
    scene back2 with Dissolve(2.0):
        size (1280, 720)
        fit "fill"
    "Я люблю этот город… Пусть он порой холоден, безэмоционален и  дождлив. Кто-то даже называет его серым. Но меня всегда преследовало одно ощущение — чувство, которое невозможно описать."
    "Оно растекается по венам, как Нева, любовно омывающая берега Санкт-Петербурга. Оно отражается солнцем в лужах после летнего проливного дождя. Оно освежает, словно морской ветер, и влюбляет в мой город раз и навсегда."
    "И, казалось бы, я знаю многие тайны моего Санкт-Петербурга… Но это самообман. Он насмехается над моей самоуверенностью и вызывает стыдливое чувство, ведь я даже на секунду не приближаюсь к разгадке его тайны."
    "Город испытывает, подкидывает новые загадки и смотрит свысока. Мудрый, великий, дальновидный и по-царски гордый. Прямо как его создатель."
    jump scene2

label scene2:
    scene back3 with dissolve:
        size (1280, 720)
        fit "fill"
    "Не обманывайтесь прогулками по дворцам, проспектам, романтикой разводных мостов, запахом выпечки из кондитерских."
    "Это все, чтобы отвлечь вас, чтобы ослабить бдительность, и для того, чтобы вы потерялись в этом мире раз и навсегда."
    "Тем временем «теневая» сторона, далеко не парадная и незаслуженно обделенная вниманием, что-то замышляет."
    "Мы не слышим зов этих улиц, стараемся не замечать его, ведь что может быть интересного в этих неприглядных уголках окраин?"
    "Намного проще видеть сказку там, куда нам указывает экскурсовод, путеводитель или учитель в школе. Но настоящие призраки бродят где-то подальше от этой суеты…"
    "Забытые, одинокие и оскорбленные отсутствием должного внимания к их истории."
    jump scene3

# Ввоd имени и перехоdы по сериям
label scene3:
    scene back4 with dissolve:
        size (1280, 720)
        fit "fill"
    "Жители города стали забывать, что когда-то улица Шкапина носила совсем другое имя. Очень броское, очень величественное. Имя, которое не должно было предаваться забвению… Но имя, которое исчезло со страниц адресных книг…"
    show m0:
        zoom 1.1 xalign -0.3 yalign 0.0
        alpha 0.0
        easein 0.3 alpha 1.0
    show g0:
        zoom 1.1 xalign 1.3 yalign -0.35
        alpha 0.0
        easein 0.3 alpha 1.0
    menu:
        "Выберите персонажа"
        "Мужской":
            hide m0 with dissolve
            hide g0 with dissolve
            $ gender = "M"
        "Женский":
            hide m0 with dissolve
            hide g0 with dissolve
            $ gender = "G"
    $ player_name = renpy.input(
        "Введите ваше имя:",
        length = 10,                                                # Макс. длина ввода (опционально)
        exclude = "][\{}<>:/\\|?*1234567890-=\"`!@#$%^&*()+№;~,\ "  # Запрещенные символы (опционально)
    ).strip()                                                       # Удаление пробелов в начале/конце

    if player_name == "":                                           # Обработка пустого ввода
        $ player_name = "Игрок"

    "В истории содержатся упоминания реальных исторических событий и личностей, воссозданных на основе краеведческой работы библиотеки им. К. А. Тимирязева."
    "Однако данное повествование  – художественный вымысел  и намеренно отступает от некоторых исторических реалий."
    "По ходу истории будут случаться развилки, и от вашего выбора будет зависеть развитие сюжета, и к какому финалу вы придете."
    "Персонаж может пойти по пути призрака или по пути яви."
    "«Призрак»- если ваш персонаж боится трудностей и не хочет смотреть опасности в лицо.\n
    «Явь» - если ваш персонаж силен духом и готов бороться с призраками."
    "Начинаем историю…"
    jump scene4

label scene4:
    scene back5 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music calmness fadein 2.0 loop if_changed
    
    if gender == "M":
        character "Надо успеть в библиотеку,  я просрочил книгу уже на две недели. Если сегодня не забегу, то снова вылетит из головы. А дальше уже как-то стыдно будет появляться."
        character "Да уже, если честно, стыдно… Просто эти зачеты в универе сейчас не вовремя, всю голову забили."
        menu:
            "Когда-то мне казалось, что учиться на"
            "археолога":
                $ archaeologist += 1
                "…на археолога будет романтично, но теперь целый день изучаю унылую эпоху Великого переселения народов. И кому это может быть интересно в таких подробностях? Хотелось бы куда-нибудь на раскопки, а пока провожу раскопки только в старых и пыльных архивах."
            "ботаника":
                $ botanist += 1
                "…на ботаника будет оригинально. Не самая распространенная профессия, есть чем удивить при светском разговоре, но я просто целыми днями штудирую биогеографию и геоботанику, а в голове мало что остается."
                "Я думал, что больше времени буду проводить за практикой на природе, а на деле я все больше зависаю в поисковике браузера, пытаясь перевести с «ботанического» на «человеческий»."
            "архитектора":
                $ architect += 1
                "…на архитектора будет перспективно. Я надеялся, что тут я смогу заняться тем, что я люблю – зданиями. А по итогу я снова сижу в аудитории и рисую эти дурацкие вазы с натюрмортами. Кто бы знал, как меня тошнит от них."
                "И снова ступни Давида, голова Давида, рука Давида… Из моих работ по графике можно целого человека уже составить, но никак не построить дом."
            "журналиста":
                $ journalist += 1
                "…на журналиста будет увлекательно. Но лучше бы я отправился  на  практику в какую-нибудь редакцию и уже получал бы бесценный опыт."
                "Я готов даже кофе разносить настоящим журналистам – во всяком случае, это было бы более продуктивно, чем снова продолжать бесцельно изучать те же предметы, что и в школе, но более углубленно."
        show m1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ладно, пострадаем над моей несчастной долей позже, сдам книги и посижу в кафешке, наслажусь карамельным рафом. Это немного меня вдохновит на подготовку к зачетам."
        jump scene5
    elif gender == "G":
        character "Надо успеть в библиотеку,  я просрочила книгу уже на две недели. Если сегодня не забегу, то снова вылетит из головы. А дальше уже как-то стыдно будет появляться."
        character "Да уже, если честно, стыдно… Просто эти зачеты в универе сейчас не вовремя, всю голову забили."
        menu:
            "Когда-то мне казалось, что учиться на"
            "археолога":
                $ archaeologist += 1
                "…на археолога будет романтично, но теперь целый день изучаю унылую эпоху Великого переселения народов. И кому это может быть интересно в таких подробностях? Хотелось бы куда-нибудь на раскопки, а пока провожу раскопки только в старых и пыльных архивах."
            "ботаника":
                $ botanist += 1
                "…на ботаника будет оригинально. Не самая распространенная профессия, есть чем удивить при светском разговоре, но я просто целыми днями штудирую биогеографию и геоботанику, а в голове мало что остается."
                "Я думала, что больше времени буду проводить за практикой на природе, а на деле я все больше зависаю в поисковике браузера, пытаясь перевести с «ботанического» на «человеческий»."
            "архитектора":
                $ architect += 1
                "…на архитектора будет перспективно. Я надеялась, что тут я смогу заняться тем, что я люблю – зданиями. А по итогу я снова сижу в аудитории и рисую эти дурацкие вазы с натюрмортами. Кто бы знал, как меня тошнит от них."
                "И снова ступни Давида, голова Давида, рука Давида… Из моих работ по графике можно целого человека уже составить, но никак не построить дом."
            "журналиста":
                $ journalist += 1
                "…на журналиста будет увлекательно. Но лучше бы я отправилась  на  практику в какую-нибудь редакцию и уже получала бы бесценный опыт."
                "Я готова даже кофе разносить настоящим журналистам – во всяком случае, это было бы более продуктивно, чем снова продолжать бесцельно изучать те же предметы, что и в школе, но более углубленно."
        show g1:
            zoom 1.0 xalign 1.3 yalign -0.35
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ладно, пострадаем над моей несчастной долей позже, сдам книги и посижу в кафешке, наслажусь карамельным рафом. Это немного меня вдохновит на подготовку к зачетам."
        jump scene5

label scene5:
    scene back6 with fade:
        size (1280, 720)
        fit "fill"
    menu:
        "продолжить":
            pass
        "2 серия":
            $ t_name = "Тимирязев"
            jump scene17
        "3 серия":
            $ t_name = "Тимирязев"
            jump scene26
        "4 серия":
            $ t_name = "Тимирязев"
            jump scene37
        "5 серия":
            $ t_name = "Тимирязев"
            jump scene38
    menu:
        "продолжить":
            pass
        "Плохая концовка":
            $ t_name = "Тимирязев"
            jump sceneplox
        "Хорошая концовка":
            $ t_name = "Тимирязев"
            jump scenegood
        "Отличная концовка":
            $ t_name = "Тимирязев"
            jump scenegreat
        "Титры":
            $ t_name = "Тимирязев"
            jump scenetitri
    if gender == "M":
        show m1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        menu:
            character "Хмм, сейчас 5 часов вечера. Я…"
            "Опоздал, библиотека закрыта":
                character "Так, стоп, свет горит, я что-то путаю, наверно надо лучше высыпаться."
                jump scene6
            "Сегодня санитарный день":
                character "Хмм, но обычно на такой случай библиотекари вешают объявления, я что-то путаю, попробую все-таки сдать книгу."
                jump scene6
            "Я как раз вовремя":
                $ reality += 1
                "+1 Явь"
                jump scene6
            "Зайду все же в другой день":
                $ ghost += 1
                "+1 Призрак"
                character "Но с другой стороны, все-таки не стоит затягивать, быстренько сдам и пойду по своим делам."
                jump scene6
    elif gender == "G":
        show g1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        menu:
            character "Хмм, сейчас 5 часов вечера. Я…"
            "Опоздала, библиотека закрыта":
                character "Так, стоп, свет горит, я что-то путаю, наверно надо лучше высыпаться."
                jump scene6
            "Сегодня санитарный день":
                character "Хмм, но обычно на такой случай библиотекари вешают объявления, я что-то путаю, попробую все-таки сдать книгу."
                jump scene6
            "Я как раз вовремя":
                $ reality += 1
                "+1 Явь"    
                jump scene6
            "Зайду все же в другой день":
                $ ghost += 1
                "+1 Призрак"
                character "Но с другой стороны, все-таки не стоит затягивать, быстренько сдам и пойду по своим делам."
                jump scene6

label scene6:
    scene back7 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        show m1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Странно, никого нет, может быть все-таки санитарный день? Ни охраны, ни библиотекарей."
        hide m1 with dissolve
        "[player_name] осмотрелся по сторонам."
        show m1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "ЭЙ! Здравствуйте! Есть кто-нибудь? Мне только книжку сдать."
        "Вокруг стоит тишина, не слышно шагов, голосов, стука клавиатуры… не видно ни души."
        character "Так… ладно, пройдем-ка на абонемент…. Уж там-то кто-то должен быть…"
        hide m1 with dissolve
    elif gender == "G":
        show g1:
            zoom 1.0 xalign -0.3 yalign -0.35
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Странно, никого нет, может быть все-таки санитарный день? Ни охраны, ни библиотекарей."
        hide g1 with dissolve
        "[player_name] осмотрелась по сторонам."
        show g1:
            zoom 1.0 xalign -0.3 yalign -0.35
            alpha 0.0
            easein 0.3 alpha 1.0
        character "ЭЙ! Здравствуйте! Есть кто-нибудь? Мне только книжку сдать."
        "Вокруг стоит тишина, не слышно шагов, голосов, стука клавиатуры… не видно ни души."
        character "Так… ладно, пройдем-ка на абонемент…. Уж там-то кто-то должен быть…"
        hide g1 with dissolve
        jump scene7

label scene7:
    scene back8 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        show m1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Пусто..."
        hide m1 with dissolve
        show m2:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Хм… Да что вообще происходит? Алло? Куда все делись?! Я хочу просто сдать книгу!"
        hide m2 with dissolve
        "[player_name] попробовал постучаться в служебное помещение, дернул ручку, но та не открывалась, словно была заперта. Увидев еще одну дверь в конце зала, [player_name] решил заглянуть туда, кажется, это зал, где хранятся книги про Санкт-Петербург."
        jump scene8
    elif gender == "G":
        show g1:
            zoom 1.0 xalign -0.3 yalign -0.35
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Пусто..."
        hide g1 with dissolve
        show g2:
            zoom 1.0 xalign -0.3 yalign -0.35
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Хм… Да что вообще происходит? Алло? Куда все делись?! Я хочу просто сдать книгу!"
        hide g2 with dissolve
        "[player_name] попробовала постучаться в служебное помещение, дернула ручку, но та не открывалась, словно была заперта. Увидев еще одну дверь в конце зала, [player_name] решила заглянуть туда, кажется, это зал, где хранятся книги про Санкт-Петербург."
        jump scene8
    return

label scene8:
    scene back9 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        "Зал оказался небольшим, в углу стоял компьютер с открытой вкладкой интернета, слева от него расположилась огромная стопка книг, рядом валялась открытая тетрадь с какими-то записями."
        show m3:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Как-будто здесь недавно кто-то работал и перед моим приходом исчез, даже экран еще не погас."
        hide m3 with dissolve
        "[player_name] осторожно приблизился к компьютеру и прочитал:"
        show m3:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        "Везенбергская улица… Звучит знакомо. Словно откуда-то из сказки. Кажется, какой-то сотрудник искал о ней информацию."
        hide m3 with dissolve
        "Почему-то любопытство пересиливало все правила приличия, и [player_name], не задумываясь, открыл первый попавшийся документ архива."
        "«Название Везенбергская ул. присвоено 18 ноября 1907 г. по г. Везенбергу (нем. Wesenberg, ныне эст. Rakvere – Раквере, Эстония) в ряду проездов Нарвской части, наименованных по городам прибалтийских губерний Российской империи."
        "Переименована 6 октября 1923 г. в честь Георгия Михайловича Шкапина (1877–1915), большевика, рабочего Путиловского завода, члена Петербургского комитета РСДРП»."
        show m3:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ясненько, просто кто-то делает доклад про нашу улицу. Любопытно. Я и не знал, что раньше она называлась Везенбергской…"
        character "Все это очень здорово, конечно… Но кто-нибудь уже спишет долг с моего читательского билета?"
        hide m3 with dissolve
        "Вообще обычно в каждом зале находится как минимум по одному библиотекарю. Во всяком случае, кто-нибудь всегда отдыхает в читальном зале, но сегодня все словно провалились сквозь землю."
        show m3:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        menu:
            character "Точно! Читальный зал! Если уж там никого не будет, то…"
            "Оставлю книгу себе":
                $ ghost += 1
                "+1 Призрак"
            "Положу книгу на стол библиотекарю с запиской":
                $ reality += 1
                "+1 Явь"
            "Поищу еще":
                pass
            "Вызову полицию!":
                "Вы злите призраков своим дерзким характером, будьте аккуратнее."
        hide m3 with dissolve
        show m1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Это все начинает меня знатно напрягать…"
        hide m1 with dissolve
        jump scene9
    elif gender == "G":
        "Зал оказался небольшим, в углу стоял компьютер с открытой вкладкой интернета, слева от него расположилась огромная стопка книг, рядом валялась открытая тетрадь с какими-то записями."
        show g3:
            zoom 1.0 xalign -0.3 yalign -0.35
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Как-будто здесь недавно кто-то работал и перед моим приходом исчез, даже экран еще не погас."
        hide g3 with dissolve
        "[player_name] осторожно приблизилась к компьютеру и прочитала:"
        show g3:
            zoom 1.0 xalign -0.3 yalign -0.35
            alpha 0.0
            easein 0.3 alpha 1.0
        "Везенбергская улица… Звучит знакомо. Словно откуда-то из сказки. Кажется, какой-то сотрудник искал о ней информацию."
        hide g3 with dissolve
        "Почему-то любопытство пересиливало все правила приличия, и [player_name], не задумываясь, открыла первый попавшийся документ архива."
        "«Название Везенбергская ул. присвоено 18 ноября 1907 г. по г. Везенбергу (нем. Wesenberg, ныне эст. Rakvere – Раквере, Эстония) в ряду проездов Нарвской части, наименованных по городам прибалтийских губерний Российской империи."
        "Переименована 6 октября 1923 г. в честь Георгия Михайловича Шкапина (1877–1915), большевика, рабочего Путиловского завода, члена Петербургского комитета РСДРП»."
        show g3:
            zoom 1.0 xalign -0.3 yalign -0.35
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ясненько, просто кто-то делает доклад про нашу улицу. Любопытно. Я и не знала, что раньше она называлась Везенбергской…"
        character "Все это очень здорово, конечно… Но кто-нибудь уже спишет долг с моего читательского билета?"
        hide g3 with dissolve
        "Вообще обычно в каждом зале находится как минимум по одному библиотекарю. Во всяком случае, кто-нибудь всегда отдыхает в читальном зале, но сегодня все словно провалились сквозь землю."
        show g3:
            zoom 1.0 xalign -0.3 yalign -0.35
            alpha 0.0
            easein 0.3 alpha 1.0
        menu:
            character "Точно! Читальный зал! Если уж там никого не будет, то…"
            "Оставлю книгу себе":
                $ ghost += 1
                "+1 Призрак"
            "Положу книгу на стол библиотекарю с запиской":
                $ reality += 1
                "+1 Явь"    
            "Поищу еще":
                pass
            "Вызову полицию!":
                "Вы злите призраков своим дерзким характером, будьте аккуратнее."
        hide g3 with dissolve
        show g1:
            zoom 1.0 xalign -0.3 yalign -0.35
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Это все начинает меня знатно напрягать…"
        hide g1 with dissolve
        jump scene9

label scene9:
    scene back10 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        show m4:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Чуда не случилось… Никого нет!"
        hide m4 with dissolve
        "[player_name] достал из сумки листок и, одолжив ручку со стола библиотекаря, оставил записку: «Сдаю книгу, мой номер читательского билета…»."
        "Оставив на видном месте томик, он решил, что его совесть чиста и можно уходить. Мало ли что случилось, все-таки это не его дело."
        "[player_name] уже почти было ушел, но внезапно услышал звук печати принтера из кабинета заведующей."
        show m1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ну неужели! Конечно, как сразу в голову не пришло, что заведующая точно должна быть на месте, это же начальство! Загляну, чтобы предупредить, что оставил книгу. А она уже разберется, что делать дальше."
        hide m1 with dissolve
        jump scene10
    elif gender == "G":
        show g4:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Чуда не случилось… Никого нет!"
        hide g4 with dissolve
        "[player_name] достала из сумки листок и, одолжив ручку со стола библиотекаря, оставила записку: «Сдаю книгу, мой номер читательского билета…»."
        "Оставив на видном месте томик, она решила, что ее совесть чиста и можно уходить. Мало ли что случилось, все-таки это не ее дело."
        "[player_name] уже почти было ушла, но внезапно услышала звук печати принтера из кабинета заведующей."
        show g1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ну неужели! Конечно, как сразу в голову не пришло, что заведующая точно должна быть на месте, это же начальство! Загляну, чтобы предупредить, что оставила книгу. А она уже разберется, что делать дальше."
        hide g1 with dissolve
        jump scene10

label scene10:
    scene back11 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music ghostWorld fadein 2.0 loop if_changed
    if gender == "M":
        character "Ну это даже не смешно!"
        "Лампа ярко горела, на столе лежали документы, экран рабочего компьютера светился так же, как и в архиве, словно человек пару секунд назад был здесь."
        "Принтер упорно печатал листы, которые без присмотра хозяина грустно падали на пол и собрались в уже довольно хорошенькую такую кучку."
        show m2:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Да ну вас к черту!!!"
        hide m2 with dissolve
        "[player_name] уже собирался уйти, как его внимание внезапно привлекло нечто на подоконнике."
        show m5:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "..."
        hide m5 with dissolve
        jump scene11
    elif gender == "G":
        character "Ну это даже не смешно!"
        "Лампа ярко горела,  на столе лежали документы, экран рабочего компьютера светился так же, как и в архиве, словно человек пару секунд назад был здесь."
        "Принтер упорно печатал листы, которые без присмотра хозяина грустно падали на пол и собрались в уже довольно хорошенькую такую кучку."
        show g2:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Да ну вас к черту!!!"
        hide g2 with dissolve
        "[player_name] уже собиралась уйти, как ее внимание внезапно привлекло нечто на подоконнике."
        show g5:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "..."
        hide g5 with dissolve
        jump scene11

label scene11:
    scene back12 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        "Книга выглядела старинной, с такой добротной зеленой обложкой, которую украшали цветы."
        "Это было похоже на гипноз."   # Посмотреть можно ли как то селать так что бы имя склонялось
        if botanist == 1:
            "Вы выбрали учиться на ботаника, поэтому знакомы с именем К. А. Тимирязева и этим трудом."
            show m3:
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Кажется, это труд знаменитого Тимирязева, в честь которого названа эта библиотека, книга из десяти лекций, посвященных анатомии и физиологии растений. Определенно мне это пригодится…"
            hide m3 with dissolve
        elif archaeologist == 1:
            "Вы выбрали учиться на археолога и не знакомы с трудами К.А. Тимирязева." 
        elif journalist == 1:
            "Вы выбрали учиться на журналиста и не знакомы с трудами К.А. Тимирязева."
        elif architect == 1:
            "Вы выбрали учиться на архитектора и не знакомы с трудами К.А. Тимирязева."
        show m1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Книга выглядит старинной, почему-то мне кажется, что я просто обязан взять ее в руки… Словно в ней есть что-то важное для меня."
        hide m1 with dissolve
        "[player_name] приблизился к ней, но в последний момент замер."
        show m1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Хм… Это всего лишь книга, что может случиться?"
        hide m1 with dissolve
        scene back12_2:
            size (1280, 720)
            fit "fill"
        "Рука сама потянулась к книге, ощущалось тепло, постепенно превращающееся в жар, свечение вокруг книги начало разрастаться."
        "Сначала оно вызывало нежное чувство спокойствия, а затем нарастающее чувство паники, но [player_name] не успел отреагировать и почувствовал, как темнеет в глазах."
        scene anim1 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=9.0, hard=True)
        jump scene12
    elif gender == "G":
        "Книга выглядела старинной, с такой добротной зеленой обложкой, которую украшали цветы."
        "Это было похоже на гипноз."
        if botanist == 1:
            "Вы выбрали учиться на ботаника, поэтому знакомы с именем К. А. Тимирязева и этим трудом."
            show g3:
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Кажется, это труд знаменитого Тимирязева, в честь которого названа эта библиотека, книга из десяти лекций, посвященных анатомии и физиологии растений. Определенно мне это пригодится…"
            hide g3 with dissolve
        elif archaeologist == 1:
            "Вы выбрали учиться на археолога и не знакомы с трудами К.А. Тимирязева." 
        elif journalist == 1:
            "Вы выбрали учиться на журналиста и не знакомы с трудами К.А. Тимирязева."
        elif architect == 1:
            "Вы выбрали учиться на архитектора и не знакомы с трудами К.А. Тимирязева."
        show g1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Книга выглядит старинной, почему-то мне кажется, что я просто обязана взять ее в руки… Словно в ней есть что-то важное для меня."
        hide g1 with dissolve
        "[player_name] приблизилась к ней, но в последний момент замерла."
        show g1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Хм… Это всего лишь книга, что может случиться?"
        hide g1 with dissolve
        scene back12_1:
            size (1280, 720)
            fit "fill"
        "Рука сама потянулась к книге, ощущалось тепло, постепенно превращающееся в жар, свечение вокруг книги начало разрастаться."
        "Сначала оно вызывало нежное чувство спокойствия, а затем нарастающее чувство паники, но [player_name] не успела отреагировать и почувствовала, как темнеет в глазах."
        scene anim1 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=9.0, hard=True)
        jump scene12

label scene12:
    scene back13:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music office fadein 2.0 loop if_changed
    if gender == "M":
        "Неизвестно, сколько времени прошло, прежде чем [player_name] очнулся. Голова казалась мутной, в кабинете стало темнее, словно день уже закончился, и начались сумерки. Было прохладно и от чего-то очень тоскливо."
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Не понимаю, что произошло, резко закружилась голова…"
        hide m6 with dissolve
        "На ватных ногах [player_name] отправился к выходу."
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Мне лучше все же пойти домой…занесу книгу в другой день."
        hide m6 with dissolve
        "Идти получалось с трудом. Но [player_name] спустился по лестнице вниз и толкнул дверь на улицу. Пространство встретило отрезвляющим ветерком. Однако [player_name] замер на месте."
        scene back14 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=3.0, hard=True)
        show m7:   
            zoom 1.0 xalign 0.2 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Это… что такое?"
        character "Этого не было…"
        character "Откуда здесь взялись эти дома?"
        hide m7 with dissolve
        "Улица изменилась, здесь выросли мрачные, незнакомые дома. Они нависли над уходящей в даль дорогой, как суровые воины, и с вызовом смотрели в ответ."
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я что… схожу с ума? Где мой дом?"
        hide m7 with dissolve
        "Голос: Здравствуй, дорогой друг."
        "[player_name] подпрыгнул от испуга и обернулся."
        jump scene13
    elif gender == "G":
        "Неизвестно, сколько времени прошло, прежде чем [player_name] очнулась. Голова казалась мутной, в кабинете стало темнее, словно день уже закончился, и начались сумерки. Было прохладно и от чего-то очень тоскливо."
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Не понимаю, что произошло, резко закружилась голова…"
        hide g6 with dissolve
        "На ватных ногах [player_name] отправилась к выходу."
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Мне лучше все же пойти домой… занесу книгу в другой день."
        hide g6 with dissolve
        "Идти получалось с трудом. Но [player_name] спустилась по лестнице вниз и толкнула дверь на улицу. Пространство встретило отрезвляющим ветерком. Однако [player_name] замерла на месте."
        scene back14 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=3.0, hard=True)
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Это… что такое?"
        character "Этого не было…"
        character "Откуда здесь взялись эти дома?"
        hide g7 with dissolve
        "Улица изменилась, здесь выросли мрачные, незнакомые дома. Они нависли над уходящей в даль дорогой, как суровые воины, и с вызовом смотрели в ответ."
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я что… схожу с ума? Где мой дом?"
        hide g7 with dissolve
        "Голос: Здравствуй, дорогой друг."
        "[player_name] подпрыгнула от испуга и обернулась."
        jump scene13

label scene13:
    scene back15 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "..."
        hide m7 with dissolve
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Я напугал тебя? Прости. Меня бояться точно не следует. Я постараюсь тебе помочь."
        character "Вы кто?"
        tmrz "Меня зовут Климент Аркадьевич."
        $ t_name = "Тимирязев"
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Вы библиотекарь?"
        tmrz "Я бы так не сказал…"
        hide m1 with dissolve
        hide t1 with dissolve
        "[player_name] насторожился, все казалось странным. Мужчина в старомодном костюме очень пугал, пугало даже его подозрительное дружелюбие. Взгляд упал на портрет, который располагался на почетном месте в библиотеке."
        jump scene14
    elif gender == "G":
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "..."
        hide g7 with dissolve
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Я напугал тебя? Прости. Меня бояться точно не следует. Я постараюсь тебе помочь."
        character "Вы кто?"
        tmrz "Меня зовут Климент Аркадьевич."
        $ t_name = "Тимирязев"
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Вы библиотекарь?"
        tmrz "Я бы так не сказал…"
        hide g1 with dissolve
        hide t1 with dissolve
        "[player_name] насторожилась, все казалось странным. Мужчина в старомодном костюме очень пугал, пугало даже его подозрительное дружелюбие. Взгляд упал на портрет, который располагался на почетном месте в библиотеке."
        jump scene14

label scene14:
    scene back16 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Поразительное сходство… Может быть, мне просто кажется, и я сильно ударился головой…"
        character "Я не понимаю…"
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Давай ты сейчас успокоишься, мы пройдем в библиотеку, сядем и все хорошенечко обсудим. Не хочу, чтобы ты лишился чувств раньше времени."
        hide t1 with dissolve
        hide m1 with dissolve
        jump scene15
    elif gender == "G":
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Поразительное сходство… Может быть, мне просто кажется, и я сильно ударилась головой…"
        character "Я не понимаю…"
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Давай ты сейчас успокоишься, мы пройдем в библиотеку, сядем и все хорошенечко обсудим. Не хочу, чтобы ты лишилась чувств раньше времени."
        hide t1 with dissolve
        hide g1 with dissolve
        jump scene15

label scene15:
    scene back17 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music untitledMaster fadein 2.0 loop if_changed
    if gender == "M":
        "Климент Аркадьевич отправился вглубь библиотеки, и [player_name] двинулся вслед за ним, по дороге отмечая, что атмосфера вокруг изменилась…"
        "Кажется,  что даже интерьеры вокруг преобразились, и в их чертах с трудом можно было уловить прежнее приветливое и теплое пространство."
        "Устроившись в кресле, Климент Аркадьевич с добродушной улыбкой кивнул, приглашая тоже садиться за небольшой журнальный столик."
        "Немного повременив, [player_name] все же решил сдаться. Все казалось каким-то странным сном, было непонятно, то ли действительно в библиотеку проник туман, то ли это темнеет у него в глазах. Ощущение нереальности происходящего затормаживало сознание."
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Я сочувствую, мой друг, и в тоже время горжусь тобой."
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "«Отличное» начало! Давайте сразу к делу."
        tmrz "Не торопись, сейчас время замерло, но как только ты выйдешь из библиотеки, оно перемешается и станет бежать в разном направлении, будет «играть» не на твоей стороне."
        character "Ничего не понимаю…"
        tmrz "Скажи, какую книгу ты прочитал?"
        hide m2 with dissolve
        hide t1 with dissolve
        if archaeologist == 1:
            "Вы археолог и интересуетесь соответствующей литературой."
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Малиничев Г. Д. «Археология по следам легенд и мифов»."
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Хммм, значит, интересуешься археологией? Пожалуй, занятие по твоему профилю. Археологам приходится много расследований проводить, хорошо ориентироваться в истории… Эти знания пригодятся тебе в будущем."
            hide t1 with dissolve
            hide m1 with dissolve
            jump scene16
        elif architect == 1:
            "Вы архитектор и интересуетесь соответствующей литературой."
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Исаченко В. Г. «Архитектурные ансамбли Петербурга»."
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Хммм, значит, тебе нравится разгадывать секреты, скрывающиеся за фасадами домов? Пожалуй, это приключение тебе может даже понравиться."
            hide t1 with dissolve
            hide m1 with dissolve
            jump scene16
        elif journalist == 1:
            "Вы журналист и интересуетесь соответствующей литературой."
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "«История русской журналистики XVIII - XIX веков»."
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Журналисты должны быть всесторонне осведомленными людьми. Уверен, что ты быстро освоишься в этом приключении."
            hide t1 with dissolve
            hide m1 with dissolve
            jump scene16
        elif botanist == 1:
            "Вы выбрали учиться на ботаника и интересуетесь соответствующей литературой."
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Монтгомери  Б. «Растения разумные, или Чему можно научиться у природы»."
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Интересуешься ботаникой…"
            hide t1 with dissolve
            hide m1 with dissolve
            "Климент Аркадьевич загадочно улыбнулся."
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Это сейчас важно?"
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Ответь мне на один вопрос, какой цветок называют «Живым светофором»?"
            character "Зачем? Что за глупость? Я же…"
            "Климент Аркадьевич продолжал по-доброму улыбаться."
            tmrz "А все-таки?"
            hide m2 with dissolve
            hide t1 with dissolve
            show m3:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            show t2:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            menu:
                character "Это…"
                "Понятия не имею":
                    $ ghost += 1
                    "+1 Призрак"
                    "Вы огорчили Климента Аркадьевича."
                    tmrz "Медуница. В процессе цветения ее цветки меняют окрас: от розового на начальной стадии до фиолетово-синего на поздних стадиях."
                "Медуница":
                    $ reality += 1
                    "+1 Явь"    
                    tmrz "Верно! В процессе цветения ее цветки меняют окрас: от розового на начальной стадии до фиолетово-синего на поздних стадиях."
                "Пролеска":
                    tmrz "Медуница. В процессе цветения ее цветки меняют окрас: от розового на начальной стадии до фиолетово-синего на поздних стадиях."
                "Дельфиниум":
                    tmrz "Медуница. В процессе цветения ее цветки меняют окрас: от розового на начальной стадии до фиолетово-синего на поздних стадиях."
                    character "Какой же он странный… Что это значит? Почему он не видел светофоры лично? Может он слепой? Да вроде нет…"
            hide m3 with dissolve
        jump scene16
    elif gender == "G":
        "Климент Аркадьевич отправился вглубь библиотеки, и [player_name] двинулась вслед за ним, по дороге отмечая, что атмосфера вокруг изменилась…"
        "Кажется, что даже интерьеры вокруг преобразились, и в их чертах с трудом можно было уловить прежнее приветливое и теплое пространство."
        "Устроившись в кресле, Климент Аркадьевич с добродушной улыбкой кивнул, приглашая тоже садиться за небольшой журнальный столик."
        "Немного повременив, [player_name] все же решила сдаться. Все казалось каким-то странным сном, было непонятно, то ли действительно в библиотеку проник туман, то ли это темнеет у нее в глазах. Ощущение нереальности происходящего затормаживало сознание."
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Я сочувствую, мой друг, и в тоже время горжусь тобой."
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "«Отличное» начало! Давайте сразу к делу."
        tmrz "Не торопись, сейчас время замерло, но как только ты выйдешь из библиотеки, оно перемешается и станет бежать в разном направлении, будет «играть» не на твоей стороне."
        character "Ничего не понимаю…"
        tmrz "Скажи, какую книгу ты прочитала?"
        hide g2 with dissolve
        hide t1 with dissolve
        if archaeologist == 1:
            "Вы археолог и интересуетесь соответствующей литературой."
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Малиничев Г. Д. «Археология по следам легенд и мифов»."
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Хммм, значит, интересуешься археологией? Пожалуй, занятие по твоему профилю. Археологам приходится много расследований проводить, хорошо ориентироваться в истории… Эти знания пригодятся тебе в будущем."
            hide t1 with dissolve
            hide g1 with dissolve
            jump scene16
        elif architect == 1:
            "Вы архитектор и интересуетесь соответствующей литературой."
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Исаченко В. Г. «Архитектурные ансамбли Петербурга»."
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Хммм, значит, тебе нравится разгадывать секреты, скрывающиеся за фасадами домов? Пожалуй, это приключение тебе может даже понравиться."
            hide t1 with dissolve
            hide g1 with dissolve
            jump scene16
        elif journalist == 1:
            "Вы журналист и интересуетесь соответствующей литературой."
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "«История русской журналистики XVIII - XIX веков»."
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Журналисты должны быть всесторонне осведомленными людьми. Уверен, что ты быстро освоишься в этом приключении."
            hide t1 with dissolve
            hide g1 with dissolve
            jump scene16
        elif botanist == 1:
            "Вы выбрали учиться на ботаника и интересуетесь соответствующей литературой."
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Монтгомери  Б. «Растения разумные, или Чему можно научиться у природы»."
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Интересуешься ботаникой…"
            hide t1 with dissolve
            hide g1 with dissolve
            "Климент Аркадьевич загадочно улыбнулся."
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Это сейчас важно?"
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Ответь мне на один вопрос, какой цветок называют «Живым светофором»?"
            character "Зачем? Что за глупость? Я же…"
            "Климент Аркадьевич продолжал по-доброму улыбаться."
            tmrz "А все-таки?"
            hide g2 with dissolve
            hide t1 with dissolve
            show g3:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            show t2:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            menu:
                character "Это…"
                "Понятия не имею":
                    $ ghost += 1
                    "+1 Призрак"
                    "Вы огорчили Климента Аркадьевича."
                    tmrz "Медуница. В процессе цветения ее цветки меняют окрас: от розового на начальной стадии до фиолетово-синего на поздних стадиях."
                "Медуница":
                    $ reality += 1
                    "+1 Явь"    
                    tmrz "Верно! В процессе цветения ее цветки меняют окрас: от розового на начальной стадии до фиолетово-синего на поздних стадиях."
                "Пролеска":
                    tmrz "Медуница. В процессе цветения ее цветки меняют окрас: от розового на начальной стадии до фиолетово-синего на поздних стадиях."
                "Дельфиниум":
                    tmrz "Медуница. В процессе цветения ее цветки меняют окрас: от розового на начальной стадии до фиолетово-синего на поздних стадиях."
                    character "Какой же он странный… Что это значит? Почему он не видел светофоры лично? Может он слепой? Да вроде нет…"
            hide g3 with dissolve
        jump scene16

label scene16:
    if gender == "M":
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        show t2:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич, давайте вернемся к нашей теме разговора. Что происходит? Откуда дома? Почему все такое странное? Я помню только, как дотронулся до книги, а затем все исчезло."
        tmrz "Дорогой друг. Ты попал в призрачное междумирье Везенбергского квартала. Ты, наверно, знаешь, что когда-то на улицах Шкапина и Розенштейна было множество домов, кипела жизнь. Квартал по старому имени улицы называли Везенбергским."
        tmrz "К сожалению, со временем эту территорию забыли. За кварталом перестали ухаживать, дома ветшали, здесь стали селиться призраки, некоторые добрые, а другие коварные и недружелюбные к живым людям."
        tmrz "Окончательно они потеряли терпение после сноса исторических домов – их родной обители."
        character "Я не понимаю, о чем вы…"
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Долгие годы они ждали возможности отомстить за такое халатное отношение. И вот… библиотекари, изучая местность вокруг для краеведческих мероприятий и экскурсий, случайно обнаружили портал."
        tmrz "Сражаясь с призраками, эти люди смогли остановить их проникновение в ваш мир, но ненадолго…"
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Запечатав портал в моей книге «Жизнь растения», они было решили, что бой окончен. Однако коварные духи утащили библиотекарей в свое пространство и время. И осталась надежда только на того, кто найдет книгу."
        tmrz "Мне очень жаль, мой друг, но у тебя нет выбора. Тебе предстоит разгадать загадки и вернуть то, что похитили призраки. На все это у тебя всего лишь 24 часа."
        tmrz "Отсчет начнется в то время, как ты покинешь библиотеку – место, где два мира, твой и наш, встречаются. Я постараюсь тебе помочь в этом пути… Но выбор ты должен делать сам. Удачи!"
        hide t2 with dissolve
        hide m1 with dissolve
        jump scene17
    elif gender == "G":
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        show t2:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич, давайте вернемся к нашей теме разговора. Что происходит? Откуда дома? Почему все такое странное? Я помню только, как дотронулась до книги, а затем все исчезло."
        tmrz "Дорогой друг. Ты попала в призрачное междумирье Везенбергского квартала. Ты, наверно, знаешь, что когда-то на улицах Шкапина и Розенштейна было множество домов, кипела жизнь. Квартал по старому имени улицы называли Везенбергским."
        tmrz "К сожалению, со временем эту территорию забыли. За кварталом перестали ухаживать, дома ветшали, здесь стали селиться призраки, некоторые добрые, а другие коварные и недружелюбные к живым людям."
        tmrz "Окончательно они потеряли терпение после сноса исторических домов – их родной обители."
        character "Я не понимаю, о чем вы…"
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Долгие годы они ждали возможности отомстить за такое халатное отношение. И вот… библиотекари, изучая местность вокруг для краеведческих мероприятий и экскурсий, случайно обнаружили портал."
        tmrz "Сражаясь с призраками, эти люди смогли остановить их проникновение в ваш мир, но ненадолго…"
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Запечатав портал в моей книге «Жизнь растения», они было решили, что бой окончен. Однако коварные духи утащили библиотекарей в свое пространство и время. И осталась надежда только на того, кто найдет книгу."
        tmrz "Мне очень жаль, мой друг, но у тебя нет выбора. Тебе предстоит разгадать загадки и вернуть то, что похитили призраки. На все это у тебя всего лишь 24 часа."
        tmrz "Отсчет начнется в то время, как ты покинешь библиотеку – место, где два мира, твой и наш, встречаются. Я постараюсь тебе помочь в этом пути… Но выбор ты должна делать сама. Удачи!"
        hide t2 with dissolve
        hide g1 with dissolve
        jump scene17

# 2 серия
label scene17:
    window hide
    with None
    # кат - сцена
    scene seria2 with fade:
        size (1280, 720)
        fit "fill"
    $ renpy.pause(delay=4.0, hard=True)
    scene 1back1 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music untitledMaster fadein 2.0 loop if_changed
    if gender == "M":
        "[player_name] не знал как реагировать."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Знаете, я, пожалуй, пойду…" 
        hide m1 with dissolve
        "Климент Аркадьевич вздохнул и грустно кивнул в ответ."
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Я понимаю, мой друг. Сложно это принять и поверить мне, но тебе нужно как можно быстрее осознать все это и отправиться в путь. Помни, как только ты выйдешь за порог, время перемешается, а потом и вовсе начнет исчезать…"
        show m3:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        "Ммм… Ясненько."
        hide m3 with dissolve
        hide t1 with dissolve
        "[player_name], с опаской поглядывая на Климента Аркадьевича, отправился к выходу. Как минимум, необходимо было подышать свежим воздухом, чтобы прийти в себя."
        jump scene18
    elif gender == "G":
        "[player_name] не знала как реагировать."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Знаете, я, пожалуй, пойду…" 
        hide g1 with dissolve
        "Климент Аркадьевич вздохнул и грустно кивнул в ответ."
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Я понимаю, мой друг. Сложно это принять и поверить мне, но тебе нужно как можно быстрее осознать все это и отправиться в путь. Помни, как только ты выйдешь за порог, время перемешается, а потом и вовсе начнет исчезать…"
        show g3:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        "Ммм… Ясненько."
        hide g3 with dissolve
        hide t1 with dissolve
        "[player_name], с опаской поглядывая на Климента Аркадьевича, отправилась к выходу. Как минимум, необходимо было подышать свежим воздухом, чтобы прийти в себя."
        jump scene18

label scene18:
    scene 1back2 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        "[player_name] не торопился выходить наружу. То, что он увидел за дверью в прошлый раз, показалось сном, и не хотелось бы, чтобы все это и правда было реальностью."
        "Сейчас бы вернуться домой и отдохнуть, ужасно кружится голова и, похоже, что мозг выдумывает какие-то потусторонние картинки."
        "Но, не смотря ни на что, все равно казалось, что библиотека – это единственное безопасное место. "
        "[player_name] в последний раз озадаченно обернулся и посмотрел вокруг."
        "Оставленные кем-то книги, табличка, рассказывающая о том, что здесь можно сделать распечатку, стопка буклетов с расписанием лекций и мастер-классов… Все похоже на ту библиотеку, которая была раньше, но что-то неуловимое изменилось в ней."
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        menu:
            "Все хватит! Я хочу…"
            "Домой!":
                $ ghost += 1
                "+1 Призрак"
            "Разобраться со всем этим!":
                $ reality += 1
                "+1 Явь"    
            "Остаться здесь…":
                $ ghost += 1
                "+1 Призрак"
        hide m2 with dissolve
        "Выбора нет – оставалось только идти вперед, навстречу неизвестному. [player_name], громко вздохнув, толкнул дверь."
        jump scene19
    elif gender == "G":
        "[player_name] не торопилась выходить наружу. То, что она увидела за дверью в прошлый раз, показалось сном, и не хотелось бы, чтобы все это и правда было реальностью."
        "Сейчас бы вернуться домой и отдохнуть, ужасно кружится голова и, похоже, что мозг выдумывает какие-то потусторонние картинки."
        "Но, не смотря ни на что, все равно казалось, что библиотека – это единственное безопасное место. "
        "[player_name] в последний раз озадаченно обернулась и посмотрела вокруг."
        "Оставленные кем-то книги, табличка, рассказывающая о том, что здесь можно сделать распечатку, стопка буклетов с расписанием лекций и мастер-классов… Все похоже на ту библиотеку, которая была раньше, но что-то неуловимое изменилось в ней."
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        menu:
            "Все хватит! Я хочу…"
            "Домой!":
                $ ghost += 1
                "+1 Призрак"
            "Разобраться со всем этим!":
                $ reality += 1
                "+1 Явь"    
            "Остаться здесь…":
                $ ghost += 1
                "+1 Призрак"
        hide g2 with dissolve
        "Выбора нет – оставалось только идти вперед, навстречу неизвестному. [player_name], громко вздохнув, толкнула дверь."
        jump scene19
# кат сцена с dевочкой и часами
label scene19:
    scene 1back3 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Нет… Нет…. Пожалуйста! Я не хочу!"
        character "Ну почему я?! Есть столько умных, смелых и сильных людей. Но «повезло» почему-то мне. Я просто хочу домой!"
        hide m6 with dissolve
        "[player_name] постарался успокоиться, но волнение все равно вызывало дрожь в руках."
        "Он, не веря собственным глазам, шагнул навстречу."
        scene timemen with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=3.0, hard=True)
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Время сходит с ума…"
        hide m7 with dissolve
        jump scene20
    elif gender == "G":
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Нет… Нет…. Пожалуйста! Я не хочу!"
        character "Ну почему я?! Есть столько умных, смелых и сильных людей. Но «повезло» почему-то мне. Я просто хочу домой!"
        hide g6 with dissolve
        "[player_name] постаралась успокоиться, но волнение все равно вызывало дрожь в руках."
        "Она, не веря собственным глазам, шагнула навстречу."
        window hide
        show 1backtime1 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)
        show 1backtime2 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)
        show 1backtime3 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)
        show 1backtime4 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)
        show 1backtime5 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)
        window show
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Время сходит с ума…"
        hide g7 with dissolve
        jump scene20

label scene20:
    scene 1back3 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ладно, нужно мыслить здраво. Библиотека на том же месте, что и была, баня стоит там же… На пустырь вернулись дома, которые стояли здесь 20 лет назад… Как это возможно?"
        stop music fadeout 2.0
        play music office fadein 2.0 loop if_changed
        hide m1 with dissolve
        "[player_name] почувствовал, как его плеча что-то коснулось."
        label scene20_1_m:
            $ return_label = "scene20_1_timeout_m"  # Куда перейти при тайм-ауте
            show screen choice_timer(20)             # Таймер на 4 секунды
            menu:
                "Что делать?"
                "Бежать":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ reality += 1
                        $ rightornot += 1
                        "+1 Явь"
                    "Вам не удалось убежать."
                    jump scene20_1_m
                "Ударить":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ ghost += 1
                        "+1 Призрак"
                    "Вы злите призраков."
                    hide screen choice_timer
                    show ghost_ht1:   
                        zoom 1.0 xalign 1.3 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht1 "Ты ответишь за это!"
                    hide ghost_ht1 with dissolve
                    "На вас напал призрак, попробуйте еще раз!"
                    $ rightornot += 1
                    jump scene20_1_m
                "Отступить и развернуться":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ reality += 1
                        "+1 Явь"
                    $ rightornot = 0
                    jump scene20_0
                "Повернуться":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ ghost += 1
                        "+1 Призрак"
                        $ rightornot += 1
                    "Не стоит так легко доверять призракам, не все они добрые. Этот оказался не так прост и напал на вас."
                    jump scene20_1_m
    
        label scene20_1_timeout_m:
            if rightornot == 0:
                $ ghost += 1
                "+1 Призрак"
                $ rightornot += 1
            "На вас напал призрак, попробуйте еще раз…"
            jump scene20_1_m
        jump scene21
    elif gender == "G":
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ладно, нужно мыслить здраво. Библиотека на том же месте, что и была, баня стоит там же… На пустырь вернулись дома, которые стояли здесь 20 лет назад… Как это возможно?"
        stop music fadeout 2.0
        play music office fadein 2.0 loop if_changed
        hide g1 with dissolve
        "[player_name] почувствовала, как ее плеча что-то коснулось."

        label scene20_1_g:
            $ return_label = "scene20_1_timeout_g"
            show screen choice_timer(20)
            menu:
                "Что делать?"
                "Бежать":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ reality += 1
                        $ rightornot += 1
                        "+1 Явь"
                    "Вам не удалось убежать."
                    jump scene20_1_g
                "Ударить":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ ghost += 1
                        "+1 Призрак"
                    "Вы злите призраков."
                    hide screen choice_timer
                    show ghost_ht1:   
                        zoom 1.0 xalign 1.3 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht1 "Ты ответишь за это!"
                    hide ghost_ht1 with dissolve
                    "На вас напал призрак, попробуйте еще раз!"
                    $ rightornot += 1
                    jump scene20_1_g
                "Отступить и развернуться":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ reality += 1
                        "+1 Явь"
                    $ rightornot = 0
                    jump scene20_0
                "Повернуться":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ ghost += 1
                        "+1 Призрак"
                        $ rightornot += 1
                    "Не стоит так легко доверять призракам, не все они добрые. Этот оказался не так прост и напал на вас."
                    jump scene20_1_g

        label scene20_1_timeout_g:
            if rightornot == 0:
                $ ghost += 1
                "+1 Призрак"
                $ rightornot += 1
            "На вас напал призрак, попробуйте еще раз…"
            jump scene20_1_g
        jump scene21

# Сценраий если "Отступить и развернуться"
label scene20_0:
    scene 1back3 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        "[player_name] отскочил в сторону и обернулся. Перед ним стоял то ли человек, то ли существо… Длинная фигура неизвестного просвечивала, и сквозь нее можно было увидеть улицу. "
        show ghost_ht1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterht1 "..."
        show m7:   
            zoom 1.0 xalign 1.4 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "..."
        hide m7 with dissolve
        hide ghost_ht1 with dissolve
        "Призрак не шевелился и только, загадочно улыбаясь, смотрел в ответ. По телу пробежали мурашки, горло пересохло, и неясно, что нужно было сказать, ведь сущность напротив не задавала никаких вопросов."
        "Одно было очевидно – подходить ближе не стоило."
        menu:
            "Нужно что-то сказать"
            "Здравствуйте…":
                pass
            "Простите, вы что-то хотите?":
                pass
            "Кто вы?":
                pass
            "Простите, я не местный":
                pass
        show ghost_ht1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterht1 "..."
        hide ghost_ht1 with dissolve
        "Призрак издал протяжный хрип и стал медленно подходить."
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "..."
        hide m7 with dissolve
        "[player_name] почувствовал, словно он окаменел. Невозможно было пошевелиться и казалось, что вот-вот случится что-то непоправимое."
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "А ну стой! Не сегодня, токсичный, злобный Борщевик!  А ну исчезни!"
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич забавно ругается. Неужели из этого выйдет какой-то толк?"
        hide m5 with dissolve
        hide t1 with dissolve
        stop music fadeout 2.0
        play music calmness fadein 2.0 loop if_changed
        "Неожиданно призрак подчинился возникшему внезапно Тимирязеву. [player_name], не смотря ни на что, был благодарен, что он оказался рядом."
        "Хотя понять, откуда он появился, не представлялось возможным."
        "Призрак недовольно оскалился, в последний раз злобно сверкнул глазами и, недовольно фыркнув на Тимирязева, исчез."
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Послушай, дружок. Я не всегда буду рядом. Тебе нужно научиться защищаться от призраков. Многие из них очень коварны, а какие-то, к сожалению, и вовсе безумны и опасны."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "И как же я могу защититься?"
        hide m1 with dissolve
        hide t1 with dissolve
        "Тимирязев добродушно улыбнулся и пожал плечами."
        show t2:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Ты должен понять сам. Но, для начала, смирись с фактом: все, что здесь происходит, – реально."
        hide t2 with dissolve
        show m3:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ну…"
        hide m3 with dissolve
        menu:
            "Пожалуй, нет… Я еще не  совсем выжил из ума":
                $ ghost += 1
                "Вы легкая добыча для призраков, раз отказываетесь верить своим глазам. +1 Призрак"
            "Допустим":
                $ reality += 1
                "Вы сделали первый шаг на пути к приключениям и разгадке задачи. +1 Явь"
            "Мне нужно еще время…":
                $ reality += 1
                $ ghost += 1
                "Вы допускаете, что все это не сон, но пока что не можете с этим смириться, постарайтесь адаптироваться быстрее, иначе этот мир поглотит вас. +1 Явь +1 Призрак"
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Что ж, так или иначе, будь внимательнее на этом пути. И чаще смотри на подсказки, которые дает тебе жизнь."
        hide t1 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        menu:
            character "..."
            "Я все еще не понимаю, чего вы от меня хотите":
                $ ghost += 1
                "Вам нужно быть внимательнее, это поможет справиться с призрачным миром.\n+1 Призрак"
                hide m1 with dissolve
                jump scene21
            "Посмотреть под ноги":
                "[player_name] опустил взгляд на землю и обнаружил, что там лежит книга. Видимо ее обронил призрак."
                show t1:   
                    zoom 1.0 xalign 1.25 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Вот тебе и первая подсказка! Это книга из библиотеки им. К.А. Тимирязева… Ее и другие несчастные издания разворовали призраки, когда вырвались из этого мира. Нужно вернуть все книги на место."
                hide t1 with dissolve
                hide m1 with dissolve
                show lermnt with fade:
                    zoom 1.0 xalign 0 yalign 0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                $ reality += 1
                $ book_lermnt += 1
                "Вы нашли первую книгу! Она же является подсказкой, куда отправляться дальше. Книгу действительно можно взять в библиотеке им. К. А. Тимирязева. +1 Явь"
                hide lermnt with dissolve
                show t1:   
                    zoom 1.0 xalign 1.25 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Ну что? Догадываешься, куда стоит держать путь?"
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                menu:
                    character "Я думаю, что:"
                    "Николаевское кавалерийское училище":
                        $ reality += 1
                        "Верно. На Лермонтовском проспекте находится один из его корпусов. Следующая подсказка там. +Явь"
                    "ДК им. Цюрупы":
                        $ ghost += 1
                        "Не верно. +1 Призрак"
                    "Прогуляться вдоль Обводного":
                        $ ghost += 1
                        "Не верно. У нас другая цель. +1 Призрак"  
                hide m2 with dissolve
                hide t1 with dissolve
                show t2:   
                    zoom 1.0 xalign 1.25 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Мы отправляемся в Николаевское кавалерийское училище. Там есть кое-кто, кто убедит тебя в реальности этого мира."
                hide t2 with dissolve
                jump scene21
            "Понятно…(ничего не понятно)":
                $ ghost += 1
                "Вам нужно быть внимательнее, это поможет справиться с призрачным миром.\n+1 Призрак"
                hide m1 with dissolve
                jump scene21
        jump scene21
    elif gender == "G":
        "[player_name] отскочила в сторону и обернулась. Перед ней стоял то ли человек, то ли существо… Длинная фигура неизвестного просвечивала, и сквозь нее можно было увидеть улицу."
        show ghost_ht1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterht1 "..."
        show g7:   
            zoom 1.0 xalign 1.4 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "..."
        hide g7 with dissolve
        hide ghost_ht1 with dissolve
        "Призрак не шевелился и только, загадочно улыбаясь, смотрел в ответ. По телу пробежали мурашки, горло пересохло, и неясно, что нужно было сказать, ведь сущность напротив не задавала никаких вопросов."
        "Одно было очевидно – подходить ближе не стоило."
        menu:
            "Нужно что-то сказать"
            "Здравствуйте…":
                pass
            "Простите, вы что-то хотите?":
                pass
            "Кто вы?":
                pass
            "Простите, я не местная":
                pass
        show ghost_ht1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterht1 "..."
        hide ghost_ht1 with dissolve
        "Призрак издал протяжный хрип и стал медленно подходить."
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "..."
        hide g7 with dissolve
        "[player_name] почувствовала, словно она окаменела. Невозможно было пошевелиться и казалось, что вот-вот случится что-то непоправимое."
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "А ну стой! Не сегодня, токсичный, злобный Борщевик!  А ну исчезни!"
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич забавно ругается. Неужели из этого выйдет какой-то толк?"
        hide g5 with dissolve
        hide t1 with dissolve
        stop music fadeout 2.0
        play music calmness fadein 2.0 loop if_changed
        "Неожиданно призрак подчинился возникшему внезапно Тимирязеву. [player_name], не смотря ни на что, была благодарна, что он оказался рядом."
        "Хотя понять, откуда он появился, не представлялось возможным."
        "Призрак недовольно оскалился, в последний раз злобно сверкнул глазами и, недовольно фыркнув на Тимирязева, исчез."
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Послушай, дружок. Я не всегда буду рядом. Тебе нужно научиться защищаться от призраков. Многие из них очень коварны, а какие-то, к сожалению, и вовсе безумны и опасны."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "И как же я могу защититься?"
        hide g1 with dissolve
        hide t1 with dissolve
        "Тимирязев добродушно улыбнулся и пожал плечами."
        show t2:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Ты должна понять сама. Но, для начала, смирись с фактом: все, что здесь происходит, – реально."
        hide t2 with dissolve
        show g3:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ну…"
        hide g3 with dissolve
        menu:
            "Пожалуй, нет… Я еще не совсем выжила из ума":
                $ ghost += 1
                "Вы легкая добыча для призраков, раз отказываетесь верить своим глазам. +1 Призрак"
            "Допустим":
                $ reality += 1
                "Вы сделали первый шаг на пути к приключениям и разгадке задачи. +1 Явь"
            "Мне нужно еще время…":
                $ reality += 1
                $ ghost += 1
                "Вы допускаете, что все это не сон, но пока что не можете с этим смириться, постарайтесь адаптироваться быстрее, иначе этот мир поглотит вас. +1 Явь +1 Призрак"
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Что ж, так или иначе, будь внимательнее на этом пути. И чаще смотри на подсказки, которые дает тебе жизнь."
        hide t1 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        menu:
            character "..."
            "Я все еще не понимаю, чего вы от меня хотите":
                $ ghost += 1
                "Вам нужно быть внимательнее, это поможет справиться с призрачным миром.\n+1 Призрак"
                hide g1 with dissolve
                jump scene21
            "Посмотреть под ноги":
                "[player_name] опустила взгляд на землю и обнаружила, что там лежит книга. Видимо ее обронил призрак."
                show t1:   
                    zoom 1.0 xalign 1.25 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Вот тебе и первая подсказка! Это книга из библиотеки им. К.А. Тимирязева… Ее и другие несчастные издания разворовали призраки, когда вырвались из этого мира. Нужно вернуть все книги на место."
                hide t1 with dissolve
                hide g1 with dissolve
                show lermnt with fade:
                    zoom 1.0 xalign 0 yalign 0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                $ reality += 1
                $ book_lermnt += 1
                "Вы нашли первую книгу! Она же является подсказкой, куда отправляться дальше. Книгу действительно можно взять в библиотеке им. К. А. Тимирязева. +1 Явь"
                hide lermnt with dissolve  
                show t1:   
                    zoom 1.0 xalign 1.25 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Ну что? Догадываешься, куда стоит держать путь?"
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                menu:
                    character "Я думаю, что:"
                    "Николаевское кавалерийское училище":
                        $ reality += 1
                        "Верно. На Лермонтовском проспекте находится один из его корпусов. Следующая подсказка там. +Явь"
                    "ДК им. Цюрупы":
                        $ ghost += 1
                        "Не верно. +1 Призрак"
                    "Прогуляться вдоль Обводного":
                        $ ghost += 1
                        "Не верно. У нас другая цель. +1 Призрак"  
                hide g2 with dissolve
                hide t1 with dissolve
                show t2:   
                    zoom 1.0 xalign 1.25 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Мы отправляемся в Николаевское кавалерийское училище. Там есть кое-кто, кто убедит тебя в реальности этого мира."
                hide t2 with dissolve
                jump scene21
            "Понятно…(ничего не понятно)":
                $ ghost += 1
                "Вам нужно быть внимательнее, это поможет справиться с призрачным миром.\n+1 Призрак"
                hide g1 with dissolve
                jump scene21
        jump scene21

# Сценарий продолжается
label scene21:
    scene 1back4 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music factory fadein 2.0 loop if_changed
    if gender == "M":
        "Путь шел через рынок, здесь было жутко шумно, туда-сюда сновали странные, почти прозрачные люди, призрачные продавцы были заняты торговлей, то и дело пытаясь что-то им предложить."
        "Сначала это пугало, но постепенно [player_name] привыкал к сюрреализму происходящего."
        characterPrd "Покупайте-покупайте! Свежайшие фрукты! Попробуйте!"
        characterCir "Лучшие стрижки! Только у нас! Заходите к нам простым рабочим, выходите уже начальником цеха!  Наведем порядок на голове, как у порядочного советского гражданина!"
        characterPrd "Покупайте часы! Лучшие часы! Проработают века!"
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ну и шумно же тут… Здесь был рынок?"
        show t2:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "В 1913 году здесь открылся базар, затем в разные периоды был рынок, но, к сожалению, получив дурную славу, вызвал недовольства у граждан."
        character "Почему?"
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Торговля разбавленным спиртом… Слишком много стало собираться неприятных личностей…"
        hide m1 with dissolve
        show m4:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Жаль, сейчас здесь столько жизни, трудно поверить, что все это вскоре прекратится."
        tmrz "И самые прекрасные цветы, к сожалению, могут завянуть, если за ними не ухаживать и не поливать вовремя."
        character "Мне очень жаль и… даже немного стыдно, что так случилось."
        tmrz "Не стоит так переживать, мой друг, у всего есть начало и конец, это нормальное течение жизни. Все, что мы можем сделать, это сохранить светлую память о том, что было раньше и строить светлое будущее, обучаясь на ошибках прошлого."
        hide m4 with dissolve
        hide t1 with dissolve
        if archaeologist == 1:
            "Вы выбрали учиться на археолога."
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Нужно будет вернуться сюда в моем мире и изучить территорию лучше, возможно здесь остались следы рынка… "
            hide m1 with dissolve
            "Действительно, на месте бывшего рынка сейчас вы можете увидеть плиты – остатки снесенных павильонов."
        elif botanist == 1:
            "Вы выбрали учиться на ботаника."
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Во всем есть плюсы, сейчас на этом месте растут деревья и цветы. Весной все так красиво расцветает. У этого места новая жизнь."
            hide m1 with dissolve
        elif architect == 1:
            "Вы выбрали учиться на архитектора."
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Попробую найти в архивах чертежи старого базара. Интересно, как он здесь размещался."
            hide m1 with dissolve
        elif journalist == 1:
            "Вы выбрали учиться на журналиста."
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Хм, нужно будет поискать в интернете фотографии рынка, уверен где-то они должны были сохраниться."
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Уверен, мой друг, это интересная тема для исследования, но нам нужно двигаться дальше."
            hide t1 with dissolve
            hide m1 with dissolve
        jump scene22
    elif gender == "G":
        "Путь шел через рынок, здесь было жутко шумно, туда-сюда сновали странные, почти прозрачные люди, призрачные продавцы были заняты торговлей, то и дело пытаясь что-то им предложить."
        "Сначала это пугало, но постепенно [player_name] привыкала к сюрреализму происходящего."
        characterPrd "Покупайте-покупайте! Свежайшие фрукты! Попробуйте!"
        characterCir "Лучшие стрижки! Только у нас! Заходите к нам простым рабочим, выходите уже начальником цеха!  Наведем порядок на голове, как у порядочного советского гражданина!"
        characterPrd "Покупайте часы! Лучшие часы! Проработают века!"
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ну и шумно же тут… Здесь был рынок?"
        show t2:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "В 1913 году здесь открылся базар, затем в разные периоды был рынок, но, к сожалению, получив дурную славу, вызвал недовольства у граждан."
        character "Почему?"
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Торговля разбавленным спиртом… Слишком много стало собираться неприятных личностей…"
        hide g1 with dissolve
        show g4:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Жаль, сейчас здесь столько жизни, трудно поверить, что все это вскоре прекратится."
        tmrz "И самые прекрасные цветы, к сожалению, могут завянуть, если за ними не ухаживать и не поливать вовремя."
        character "Мне очень жаль и… даже немного стыдно, что так случилось."
        tmrz "Не стоит так переживать, мой друг, у всего есть начало и конец, это нормальное течение жизни. Все, что мы можем сделать, это сохранить светлую память о том, что было раньше и строить светлое будущее, обучаясь на ошибках прошлого."
        hide g4 with dissolve
        hide t1 with dissolve
        if archaeologist == 1:
            "Вы выбрали учиться на археолога."
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Нужно будет вернуться сюда в моем мире и изучить территорию лучше, возможно здесь остались следы рынка… "
            hide g1 with dissolve
            "Действительно, на месте бывшего рынка сейчас вы можете увидеть плиты – остатки снесенных павильонов."
        elif botanist == 1:
            "Вы выбрали учиться на ботаника."
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Во всем есть плюсы, сейчас на этом месте растут деревья и цветы. Весной все так красиво расцветает. У этого места новая жизнь."
            hide g1 with dissolve
        elif architect == 1:
            "Вы выбрали учиться на архитектора."
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Попробую найти в архивах чертежи старого базара. Интересно, как он здесь размещался."
            hide g1 with dissolve
        elif journalist == 1:
            "Вы выбрали учиться на журналиста."
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Хм, нужно будет поискать в интернете фотографии рынка, уверена где-то они должны были сохраниться."
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Уверен, мой друг, это интересная тема для исследования, но нам нужно двигаться дальше."
            hide t1 with dissolve
            hide g1 with dissolve
        jump scene22

label scene22:
    scene 1back5 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music untitledMaster fadein 2.0 loop if_changed
    if gender == "M":
        "[player_name] посмотрел на время, но часы словно сходили с ума, они не показывали что-то определенное и постоянно меняли ход времени то вперед, то назад."
        "По ощущению – вечерело. Можно было различить закат сквозь призрачный туман."
        "Обводный канал выглядел умиротворенно, вызывая обманчивое спокойствие в этом безумном мире. Захотелось посмотреть в водную гладь и немного выдохнуть, поразмыслив над происходящим."
        characterVois "Пойдем со мной…"
        "[player_name] удивленно вздрогнул."
        show m3:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что?"
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Я ничего не говорил, мой друг."
        character "Может, показалось…"
        characterVois "Иди ко мне…. Ты так устал, я обниму тебя, мой добрый путник…"
        hide m3 with dissolve
        "Голос обладал магической притягательностью, успокаивал и даже немного усыплял."
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич, вы слышите?"
        tmrz "О чем ты?"
        characterVois "Ты не должен разбираться со всем этим, на тебя взвалили тяжелую ношу. Этот мир чужд тебе. Иди ко мне, я помогу. Я расскажу все, что тебе нужно знать."
        hide m7 with dissolve
        show m4:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я не понимаю…"
        "Климент Аркадьевич выглядел обеспокоенным."
        characterVois "Не доверяй этому человеку, он только притворяется добрым, а сам ведет тебя в ловушку. Иди ко мне, я помогу…"
        "[player_name] посмотрел по сторонам, но никого кроме него и Климента Аркадьевича не было. Они шли по мосту и, казалось, что голос звучал прямо из Обводного канала."
        character "Странно…"
        hide m4 with dissolve
        hide t1 with dissolve
        jump scene23
    elif gender == "G":
        "[player_name] посмотрела на время, но часы словно сходили с ума, они не показывали что-то определенное и постоянно меняли ход времени то вперед, то назад."
        "По ощущению – вечерело. Можно было различить закат сквозь призрачный туман."
        "Обводный канал выглядел умиротворенно, вызывая обманчивое спокойствие в этом безумном мире. Захотелось посмотреть в водную гладь и немного выдохнуть, поразмыслив над происходящим."
        characterVois "Пойдем со мной…"
        "[player_name] удивленно вздрогнула."
        show g3:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что?"
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Я ничего не говорил, мой друг."
        character "Может, показалось…"
        characterVois "Иди ко мне…. Ты так устала, я обниму тебя, мой добрый путник…"
        hide g3 with dissolve
        "Голос обладал магической притягательностью, успокаивал и даже немного усыплял."
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич, вы слышите?"
        tmrz "О чем ты?"
        characterVois "Ты не должна разбираться со всем этим, на тебя взвалили тяжелую ношу. Этот мир чужд тебе. Иди ко мне, я помогу. Я расскажу все, что тебе нужно знать."
        hide g7 with dissolve
        show g4:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я не понимаю…"
        "Климент Аркадьевич выглядел обеспокоенным."
        characterVois "Не доверяй этому человеку, он только притворяется добрым, а сам ведет тебя в ловушку. Иди ко мне, я помогу…"
        "[player_name] посмотрела по сторонам, но никого кроме нее и Климента Аркадьевича не было. Они шли по мосту и, казалось, что голос звучал прямо из Обводного канала."
        character "Странно…"
        hide g4 with dissolve
        hide t1 with dissolve
        jump scene23

label scene23:
    scene 1back6 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music ball fadein 2.0 loop if_changed
    if gender == "M":
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Знаешь, в ваше время здесь тоже учебное заведение – лицей. Но пару веков назад оно было совсем другим…"
        hide t1 with dissolve
        if archaeologist == 1:
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Да,  с 1823 года здесь располагалась школа гвардейских подпрапорщиков или Николаевское кавалерийское училище для молодых дворян. Многие ученики были знаменитыми людьми – Мусоргский, Лермонтов, Семенов-Тян-Шанский… и другие…"
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Похвально, мой друг!"
            hide t1 with dissolve
            hide m2 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Хотите сказать, что мы сейчас отправимся в XIX век?"
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Кто знает, в какое время в этот раз откроется дверь."
        hide t1 with dissolve
        hide m1 with dissolve
        jump scene24
    elif gender == "G":
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Знаешь, в ваше время здесь тоже учебное заведение – лицей. Но пару веков назад оно было совсем другим…"
        hide t1 with dissolve
        if archaeologist == 1:
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Да,  с 1823 года здесь располагалась школа гвардейских подпрапорщиков или Николаевское кавалерийское училище для молодых дворян. Многие ученики были знаменитыми людьми – Мусоргский, Лермонтов, Семенов-Тян-Шанский… и другие…"
            show t1:   
                zoom 1.0 xalign 1.25 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Похвально, мой друг!"
            hide t1 with dissolve
            hide g2 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Хотите сказать, что мы сейчас отправимся в XIX век?"
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Кто знает, в какое время в этот раз откроется дверь."
        hide t1 with dissolve
        hide g1 with dissolve
        jump scene24

label scene24:
    scene 1back7 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        "В зале звучала музыка, в этих стенах проходил призрачный бал. Кругом мелькали тени, словно в диком танце. Но никого невозможно было разглядеть, словно память об этих людях почти стерлась…"
        "Пространство поражало красотой, и казалось удивительным, что такое очарование было здесь, буквально рядом с домом."
        "[player_name] был поражен, ведь ему столько раз приходилось проходить мимо желтого протяженного здания, и ни разу не закрадывалась в голову мысль, что от его взора прячется нечто такое волшебное."
        "Поражало, как много удивительных вещей было упущено. Внутри предательски закрадывалась мысль, что это все обман, такого быть не могло. Просто этот мир наводит какую-то дымку на сознание, и от этого мерещится что-то небывалое."
        show t2:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Друг мой, я хочу познакомить тебя кое с кем важным. Думаю, тебе будет любопытно."
        hide t2 with dissolve
        "Увлеченный антуражем, [player_name] не сразу услышал Климента Аркадьевича, поэтому, обернувшись к нему, пораженно застыл."
        show ghost_lerm:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Не может быть…"
        hide m7 with dissolve
        "Перед путниками гордо стоял человек невысокого роста с широкими плечами, бледным лицом и темными, как уголь, проницательными глазами. Его было сложно не узнать. [player_name] сотню раз видел его в школьных учебниках по литературе."
        characterlerm "Ну, здравствуй, человек из будущего!"
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Михаил Юрьевич, рад вам представить человека, который отважился сразиться с призраками. Наш дорогой друг попал в беду, нужна ваша помощь."
        if archaeologist == 1:
            "Вы выбрали учиться на археолога."
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Поэт Михаил Юрьевич Лермонтов в 18 лет поступил в школу гвардейских прапорщиков и кавалерийских юнкеров…. Это 1832 год… "
            hide m2 with dissolve
        if journalist == 1:
            "Вы выбрали учиться на журналиста."
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Библиотека им. К.А. Тимирязева принадлежит МЦБС им. М.Ю. Лермонтова. Возможно, именно поэтому мы обратились за помощью к поэту."
            character "Если я правильно понимаю логику этого мира… Все началось с библиотеки, видимо разгадка прячется в событиях или личностях, связанных с ней."
            hide m2 with dissolve
        tmrz "Наш друг все еще не совсем верит в реальность происходящего…"
        characterlerm "А что он как в рот воды набрал? Говорить можешь?"
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Пытаюсь… Но мне кажется, я просто схожу с ума, и мое безумное подсознание выдает какие-то странные вещи."
        characterlerm "И что ты думаешь с этим делать?"
        menu:
            character "Я..."
            "Понятия не имею":
                "Тимирязев разочарованно посмотрел, но ничего не сказал."
            "Просто хочу домой":
                tmrz "Мой друг, не веди себя как маленький. Для того чтобы попасть домой, нужно потрудиться."
            "Постараюсь со всем разобраться":
                $ reality += 2
                "Михаил Юрьевич одобрительно улыбнулся."
                characterlerm "Хороший настрой. Одобряю."
            "Не ваше дело!":
                $ ghost += 2
                "Тимирязев и Лермонтов переглянулись. В их глазах читалось сомнение в том, что [player_name] способен вынести то, что легло на его плечи."
        characterlerm "Не буду томить. Вот карта квартала."
        "Вы получили карту путешествия. Теперь вам будет легче строить путь."
        characterlerm "Ты должен вернуть все библиотечные книги на места, тогда и время встанет на место, а ты сможешь вернуться домой. Но придется разгадать загадки призраков. Просто так тебе никто ничего не вернет."
        character "Что за загадки?"
        characterlerm "У каждого - своя. Вот, держи первую от меня. Так сказать, тренировочную."
        characterlerm "У лестницы тебя ждет призрак. Пройди первое испытание, и мы поймем, готов ли ты."
        hide m1 with dissolve
        show m3:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "То есть… Я пойду туда один? Климент Аркадьевич?"
        tmrz "Боюсь, что так, мой друг. Я подожду здесь."
        hide m3 with dissolve
        hide t1 with dissolve
        hide ghost_lerm with dissolve
        jump scene25
    elif gender == "G":
        "В зале звучала музыка, в этих стенах проходил призрачный бал. Кругом мелькали тени, словно в диком танце. Но никого невозможно было разглядеть, словно память об этих людях почти стерлась…"
        "Пространство поражало красотой, и казалось удивительным, что такое очарование было здесь, буквально рядом с домом."
        "[player_name] была поражена, ведь ей столько раз приходилось проходить мимо желтого протяженного здания, и ни разу не закрадывалась в голову мысль, что от ее взора прячется нечто такое волшебное."
        "Поражало, как много удивительных вещей было упущено. Внутри предательски закрадывалась мысль, что это все обман, такого быть не могло. Просто этот мир наводит какую-то дымку на сознание, и от этого мерещится что-то небывалое."
        show t2:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Друг мой, я хочу познакомить тебя кое с кем важным. Думаю, тебе будет любопытно."
        hide t2 with dissolve
        "Увлеченная антуражем, [player_name] не сразу услышала Климента Аркадьевича, поэтому, обернувшись к нему, пораженно застыла."
        show ghost_lerm:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Не может быть…"
        hide g7 with dissolve
        "Перед путниками гордо стоял человек невысокого роста с широкими плечами, бледным лицом и темными, как уголь, проницательными глазами. Его было сложно не узнать. [player_name] сотню раз видела его в школьных учебниках по литературе."
        characterlerm "Ну, здравствуй, человек из будущего!"
        show t1:   
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Михаил Юрьевич, рад вам представить человека, который отважился сразиться с призраками. Наш дорогой друг попал в беду, нужна ваша помощь."
        if archaeologist == 1:
            "Вы выбрали учиться на археолога."
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Поэт Михаил Юрьевич Лермонтов в 18 лет поступил в школу гвардейских прапорщиков и кавалерийских юнкеров…. Это 1832 год…"
            hide g2 with dissolve
        if journalist == 1:
            "Вы выбрали учиться на журналиста."
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Библиотека им. К.А. Тимирязева принадлежит МЦБС им. М.Ю. Лермонтова. Возможно, именно поэтому мы обратились за помощью к поэту."
            character "Если я правильно понимаю логику этого мира… Все началось с библиотеки, видимо разгадка прячется в событиях или личностях, связанных с ней."
            hide g2 with dissolve
        tmrz "Наш друг все еще не совсем верит в реальность происходящего…"
        characterlerm "А что она как в рот воды набрала? Говорить можешь?"
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Пытаюсь… Но мне кажется, я просто схожу с ума, и мое безумное подсознание выдает какие-то странные вещи."
        characterlerm "И что ты думаешь с этим делать?"
        menu:
            character "Я..."
            "Понятия не имею":
                "Тимирязев разочарованно посмотрел, но ничего не сказал."
            "Просто хочу домой":
                tmrz "Мой друг, не веди себя как маленькая. Для того чтобы попасть домой, нужно потрудиться."
            "Постараюсь со всем разобраться":
                $ reality += 2
                "Михаил Юрьевич одобрительно улыбнулся."
                characterlerm "Хороший настрой. Одобряю."
            "Не ваше дело!":
                $ ghost += 2
                "Тимирязев и Лермонтов переглянулись. В их глазах читалось сомнение в том, что [player_name] способна вынести то, что легло на ее плечи."
        characterlerm "Не буду томить. Вот карта квартала."
        "Вы получили карту путешествия. Теперь вам будет легче строить путь."
        characterlerm "Ты должна вернуть все библиотечные книги на места, тогда и время встанет на место, а ты сможешь вернуться домой. Но придется разгадать загадки призраков. Просто так тебе никто ничего не вернет."
        character "Что за загадки?"
        characterlerm "У каждого - своя. Вот, держи первую от меня. Так сказать, тренировочную."
        characterlerm "У лестницы тебя ждет призрак. Пройди первое испытание, и мы поймем, готова ли ты."
        hide g1 with dissolve
        show g3:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "То есть… Я пойду туда одна? Климент Аркадьевич?"
        tmrz "Боюсь, что так, мой друг. Я подожду здесь."
        hide g3 with dissolve
        hide t1 with dissolve
        hide ghost_lerm with dissolve
        jump scene25

label scene25:
    scene 1back8 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music ghost fadein 2.0 loop if_changed
    if gender == "M":
        "[player_name] осторожно шел навстречу неизвестному. Было немного неприятно, что Тимирязев бросил его в такой ответственный момент. Вспомнился голос на Обводном канале. "
        "Вдруг он был прав? С чего вообще [player_name] взял, что это добрый призрак, который будет помогать? Может быть, он пытается еще больше запутать, чтобы [player_name] окончательно здесь потерялся и остался навсегда."
        "Рассуждениям помешала тень, которая скользнула совсем рядом."
        "[player_name] замер и медленно повернулся."
        show ghost_ht2:
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Кто ты?"
        characterht2 "Ты нанес нам оскорбление, человек. Я вызываю тебя на дуэль! Выбирай оружие!"
        hide m1 with dissolve
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что? Оружие? Я думал, это будет какая-нибудь задача на логику. Я не хочу драться."
        characterht2 "Защищай свою честь! Или погибни как трус!"
        hide m7 with dissolve
        hide ghost_ht2 with dissolve
        jump scene26
    elif gender == "G":
        "[player_name] осторожно шла навстречу неизвестному. Было немного неприятно, что Тимирязев бросил ее в такой ответственный момент. Вспомнился голос на Обводном канале."
        "Вдруг он был прав? С чего вообще [player_name] взяла, что это добрый призрак, который будет помогать? Может быть, он пытается еще больше запутать, чтобы [player_name] окончательно здесь потерялась и осталась навсегда."
        "Рассуждениям помешала тень, которая скользнула совсем рядом."
        "[player_name] замерла и медленно повернулась."
        show ghost_ht2:
            zoom 1.0 xalign 1.25 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Кто ты?"
        characterht2 "Ты нанес нам оскорбление, человек. Я вызываю тебя на дуэль! Выбирай оружие!"
        hide g1 with dissolve
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что? Оружие? Я думала, это будет какая-нибудь задача на логику. Я не хочу драться."
        characterht2 "Защищай свою честь! Или погибни как трус!"
        hide g7 with dissolve
        hide ghost_ht2 with dissolve
        jump scene26

# 3 серия
label scene26:
    window hide
    with None
    # кат - сцена
    scene seria3 with fade:
        size (1280, 720)
        fit "fill"
    $ renpy.pause(delay=4.0, hard=True)
    window show
    scene 2back1 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music ghostWorld fadein 2.0 loop if_changed
    if gender == "M":
        "[player_name] не знал, что ему делать, как себя вести. В глубине души ютилась надежда, что все это было шуткой. Внезапно Тимирязев и Лермонтов выйдут в центр зала и объявят, что все это было для того, чтобы [player_name] и правда поверил в существование призраков."
        "Но ничего подобного не происходило. Нужно было смириться с фактом, что [player_name] примет на себя весь груз ответственности. А еще необходимо было что-то ответить…"
        show ghost_ht2:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterht2 "Отвечай, чужак. Ты готов сразиться?"
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Одну секундочку…"
        "Пришлось медлить, чтобы сообразить, как выйти из этой ситуации. Ну не сражаться же в самом деле."
        characterht2 "Так и думал, что струсишь!"
        hide m5 with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я не боюсь тебя и принимаю бой! Но мы не можем его начать!"
        if journalist == 1:
            "Вы выбрали учиться на журналиста. На занятиях по литературе вы касались темы дуэли. Нужно вспомнить, без чего или без кого она не может состояться."
        characterht2 "Начнем сию секунду!"
        hide m2 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Нет, нам нужно выбрать…"
        hide m1 with dissolve
        hide ghost_ht2 with dissolve
        label scene26_0_m:
            menu:
                "Оружие":
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вряд ли вы нащупали правильный выход из ситуации. +1 Призрак"
                    else:
                        "Вряд ли вы нащупали правильный выход из ситуации."
                    show ghost_ht2:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht2 "Я предоставляю этот выбор тебе! Пистолеты или шпага?"
                    show m1:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Эм… Ну, пусть будет шпага. Пистолеты же опаснее."
                    "[player_name] осознал, что в руках появилось острое оружие. Начался бой. Однако, вы не владеете навыком фехтования. Призрак довольно быстро вас одолел. Выберете заново."
                    hide m1 with dissolve
                    hide ghost_ht2 with dissolve
                    jump scene26_0_m
                "Секундантов":
                    if rightornot == 0:
                        $ reality += 1
                        "Вы мыслите в верном направлении. +1 Явь"
                    else:
                        "Вы мыслите в верном направлении."
                    $ rightornot = 0
                    jump scene27
                "Место":
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вряд ли вы нащупали правильный выход из ситуации. +1 Призрак"
                    else:
                        "Вряд ли вы нащупали правильный выход из ситуации."
                    show ghost_ht2:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht2 "Будем сражаться прямо здесь!"
                    "[player_name] почувствовал, как в руках из ниоткуда появился пистолет, такой же сверкал у приготовившегося к бою призрака."
                    show m6:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Похоже, я ошибся…"
                    "Раздался выстрел. [player_name] ранен. Попробуйте выбрать еще раз."
                    hide m6 with dissolve
                    hide ghost_ht2 with dissolve
                    jump scene26_0_m
                "Время":
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вряд ли вы нащупали правильный выход из ситуации. +1 Призрак"
                    else:
                        "Вряд ли вы нащупали правильный выход из ситуации."
                    show ghost_ht2:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht2 "Ты за дурака меня держишь? Где твоя честь? Сражайся сейчас!"
                    "[player_name] почувствовал, как в руках из ниоткуда появился пистолет, такой же сверкал у приготовившегося к бою призрака."
                    "[player_name] помедлил, не зная как действовать. Да и держать в руках оружие прежде не приходилось."
                    characterht2 "Как ты жалок. Ты не достоин ни этого мира, ни своего собственного!"
                    "Раньше, чем [player_name] успел что-то понять, раздался выстрел. [player_name] ранен. Попробуйте выбрать еще раз."
                    hide ghost_ht2 with dissolve
                    jump scene26_0_m
        jump scene27
    elif gender == "G":
        "[player_name] не знала, что ей делать, как себя вести. В глубине души ютилась надежда, что все это было шуткой. Внезапно Тимирязев и Лермонтов выйдут в центр зала и объявят, что все это было для того, чтобы [player_name] и правда поверила в существование призраков."
        "Но ничего подобного не происходило. Нужно было смириться с фактом, что [player_name] примет на себя весь груз ответственности. А еще необходимо было что-то ответить…"
        show ghost_ht2:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterht2 "Отвечай, чужак. Ты готов сразиться?"
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Одну секундочку…"
        "Пришлось медлить, чтобы сообразить, как выйти из этой ситуации. Ну не сражаться же в самом деле."
        characterht2 "Так и думал, что струсишь!"
        hide g5 with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я не боюсь тебя и принимаю бой! Но мы не можем его начать!"
        if journalist == 1:
            "Вы выбрали учиться на журналиста. На занятиях по литературе вы касались темы дуэли. Нужно вспомнить, без чего или без кого она не может состояться."
        characterht2 "Начнем сию секунду!"
        hide g2 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Нет, нам нужно выбрать…"
        hide g1 with dissolve
        hide ghost_ht2 with dissolve
        label scene26_0_g:
            menu:
                "Оружие":
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вряд ли вы нащупали правильный выход из ситуации. +1 Призрак"
                    else:
                        "Вряд ли вы нащупали правильный выход из ситуации."
                    show ghost_ht2:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht2 "Я предоставляю этот выбор тебе! Пистолеты или шпага?"
                    show g1:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Эм… Ну, пусть будет шпага. Пистолеты же опаснее."
                    "[player_name] осознала, что в руках появилось острое оружие. Начался бой. Однако, вы не владеете навыком фехтования. Призрак довольно быстро вас одолел. Выберете заново."
                    hide g1 with dissolve
                    hide ghost_ht2 with dissolve
                    jump scene26_0_g
                "Секундантов":
                    if rightornot == 0:
                        $ reality += 1
                        "Вы мыслите в верном направлении. +1 Явь"
                    else:
                        "Вы мыслите в верном направлении."
                    $ rightornot = 0
                    jump scene27
                "Место":
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вряд ли вы нащупали правильный выход из ситуации. +1 Призрак"
                    else:
                        "Вряд ли вы нащупали правильный выход из ситуации."
                    show ghost_ht2:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht2 "Будем сражаться прямо здесь!"
                    "[player_name] почувствовала, как в руках из ниоткуда появился пистолет, такой же сверкал у приготовившегося к бою призрака."
                    show g6:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Похоже, я ошиблась…"
                    "Раздался выстрел. [player_name] ранена. Попробуйте выбрать еще раз."
                    hide g6 with dissolve
                    hide ghost_ht2 with dissolve
                    jump scene26_0_g
                "Время":
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вряд ли вы нащупали правильный выход из ситуации. +1 Призрак"
                    else:
                        "Вряд ли вы нащупали правильный выход из ситуации."
                    show ghost_ht2:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht2 "Ты за дурака меня держишь? Где твоя честь? Сражайся сейчас!"
                    "[player_name] почувствовала, как в руках из ниоткуда появился пистолет, такой же сверкал у приготовившегося к бою призрака."
                    "[player_name] помедлила, не зная, как действовать. Да и держать в руках оружие прежде не приходилось."
                    characterht2 "Ты такая жалкая. Ты не достойна ни этого мира, ни своего собственного!"
                    "Раньше, чем [player_name] успела что-то понять, раздался выстрел. [player_name] ранена. Попробуйте выбрать еще раз."
                    hide ghost_ht2 with dissolve
                    jump scene26_0_g
        jump scene27

label scene27:
    scene 2back1 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music ghostWorld fadein 2.0 loop if_changed
    if gender == "M":
        show ghost_ht2:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterht2 "Нам никто не нужен, мы будем сражаться один на один."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Хитрец. Именно секунданты определяют место, время и другие условия дуэли. Именно они следят за соблюдением правил поединка. Если не будет секундантов, то это не бой, а просто-напросто убийство."
        "Призрак нахмурился и задумался."
        characterht2 "Скажи сразу, что испугался защищать свою честь!"
        hide m1 with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Как бы не так! Я наоборот слежу, чтобы дуэль была честной. Участвовать в глупой перестрелке – постыдное занятие, низкое для любого уважающего себя человека."
        "Привидение словно задумалось над словами чужака. Дуэлянт на несколько секунд затих."
        characterht2 "А ты не глуп. Что ж, может быть, ты и достоин пройти этот путь."
        hide m2 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Благодарю."
        characterht2 "Но просто отпустить тебя я не смогу. Как призрак, я желаю, чтобы этот мир поглотил вашу реальность. Но из уважения дам тебе фору, если отгадаешь загадку."
        characterht2 "А проиграешь – останешься здесь навсегда, превратившись в призрака, и будешь целую вечность снова и снова стреляться со мной на дуэли. Согласен?"
        character "А у меня есть выбор?"
        "Послышался хриплый, пугающий смех."
        characterht2 "Правда твоя. Выбора нет."
        hide m1 with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что за загадка?"
        label scene27_0_m_0:
        characterht2 "Попросили как-то мудреца решить одну дилемму. После дуэли оба дуэлянта были ранены, но один из участников погиб спустя некоторое время от инфекции, попавшей в рану."
        characterht2 "А другой, не дождавшись гибели от потери крови, прыгнул с обрыва. Кто из этих двух виновен в том, что оппонент погиб?"
        hide m2 with dissolve
        hide ghost_ht2 with dissolve
        label scene27_0_m:
        menu:
            "Оба виноваты":
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Нечего было стреляться, оба виноваты."
                show ghost_ht2:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                if rightornot == 0:
                    $ ghost += 1
                    "Ты ошибся и остаешься здесь со мной и навсегда. +1 Призрак"
                else:
                    "Ты ошибся и остаешься здесь со мной и навсегда."
                hide ghost_ht2 with dissolve
                hide m2 with dissolve
                $ rightornot += 1
                jump scene27_0_m
            "Первый":
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Первый погиб, потому что рану неправильно лечили. А второй из-за выстрела и последующей потери крови в любом случае бы погиб. Так что мой выбор – первый."
                show ghost_ht2:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterht2 "Что ж, и врага можно уважать. Ступай. Удачи тебе не желаю, но с интересом понаблюдаю, как ты будешь двигаться дальше. Очень жаль, что со мной не остался."
                if rightornot == 0:
                    $ reality += 1
                    "Вы справились! +1 Явь"
                else:
                    "Вы справились!"
                hide ghost_ht2 with dissolve
                $ rightornot = 0
                jump scene28
            "Второй":
                show m5:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Не знаю, ну, пусть будет второй!"
                show ghost_ht2:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                if rightornot == 0:
                    $ ghost += 1
                    characterht2 "Что значит «пусть будет второй»? За свою несерьезность ты остаешься с призраками навсегда! Ответ неверный! +1 Призрак"
                else:
                    "Что значит «пусть будет второй»? За свою несерьезность ты остаешься с призраками навсегда! Ответ неверный!" 
                hide ghost_ht2 with dissolve
                hide m5 with dissolve
                $ rightornot += 1
                jump scene27_0_m
            "Никто не виноват":
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Они же договорились о дуэли. Никто не виноват, знали на что шли."
                show ghost_ht2:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                if rightornot == 0:
                    $ ghost += 1
                    characterht2 "Так не бывает, чтоб никто не был виноват.  За свою безответственность ты остаешься с призраками навсегда! Ответ неверный! +1 Призрак"
                else:
                    "Так не бывает, чтоб никто не был виноват.  За свою безответственность ты остаешься с призраками навсегда! Ответ неверный!" 
                hide ghost_ht2 with dissolve
                hide m2 with dissolve
                $ rightornot += 1
                jump scene27_0_m
            "Прочитать загадку еще раз":
                jump scene27_0_m_0
        jump scene28
    elif gender == "G":
        show ghost_ht2:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterht2 "Нам никто не нужен, мы будем сражаться один на один."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Хитрец. Именно секунданты определяют место, время и другие условия дуэли. Именно они следят за соблюдением правил поединка. Если не будет секундантов, то это не бой, а просто-напросто убийство."
        "Призрак нахмурился и задумался."
        characterht2 "Скажи сразу, что испугалась защищать свою честь!"
        hide g1 with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Как бы не так! Я наоборот слежу, чтобы дуэль была честной. Участвовать в глупой перестрелке – постыдное занятие, низкое для любого уважающего себя человека."
        "Привидение словно задумалось над словами чужака. Дуэлянт на несколько секунд затих."
        characterht2 "А ты не глупа. Что ж, может быть, ты и достойна пройти этот путь."
        hide g2 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Благодарю."
        characterht2 "Но просто отпустить тебя я не смогу. Как призрак, я желаю, чтобы этот мир поглотил вашу реальность. Но из уважения дам тебе фору, если отгадаешь загадку."
        characterht2 "А проиграешь – останешься здесь навсегда, превратившись в призрака, и будешь целую вечность снова и снова стреляться со мной на дуэли. Согласна?"
        character "А у меня есть выбор?"
        "Послышался хриплый, пугающий смех."
        characterht2 "Правда твоя. Выбора нет."
        hide g1 with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что за загадка?"
        label scene27_0_g_0:
        characterht2 "Попросили как-то мудреца решить одну дилемму. После дуэли оба дуэлянта были ранены, но один из участников погиб спустя некоторое время от инфекции, попавшей в рану."
        characterht2 "А другой, не дождавшись гибели от потери крови, прыгнул с обрыва. Кто из этих двух виновен в том, что оппонент погиб?"
        hide g2 with dissolve
        hide ghost_ht2 with dissolve
        label scene27_0_g:
        menu:
            "Оба виноваты":
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Нечего было стреляться, оба виноваты."
                show ghost_ht2:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                if rightornot == 0:
                    $ ghost += 1
                    "Ты ошиблась и остаешься здесь со мной и навсегда. +1 Призрак"
                else:
                    "Ты ошиблась и остаешься здесь со мной и навсегда."
                hide ghost_ht2 with dissolve
                hide g2 with dissolve
                $ rightornot += 1
                jump scene27_0_g
            "Первый":
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Первый погиб, потому что рану неправильно лечили. А второй из-за выстрела и последующей потери крови в любом случае бы погиб. Так что мой выбор – первый."
                show ghost_ht2:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterht2 "Что ж, и врага можно уважать. Ступай. Удачи тебе не желаю, но с интересом понаблюдаю, как ты будешь двигаться дальше. Очень жаль, что со мной не осталась."
                if rightornot == 0:
                    $ reality += 1
                    "Вы справились! +1 Явь"
                else:
                    "Вы справились!"
                hide ghost_ht2 with dissolve
                $ rightornot = 0
                jump scene28
            "Второй":
                show g5:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Не знаю, ну, пусть будет второй!"
                show ghost_ht2:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                if rightornot == 0:
                    $ ghost += 1
                    characterht2 "Что значит «пусть будет второй»? За свою несерьезность ты остаешься с призраками навсегда! Ответ неверный! +1 Призрак"
                else:
                    "Что значит «пусть будет второй»? За свою несерьезность ты остаешься с призраками навсегда! Ответ неверный!" 
                hide ghost_ht2 with dissolve
                hide g5 with dissolve
                $ rightornot += 1
                jump scene27_0_g
            "Никто не виноват":
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Они же договорились о дуэли. Никто не виноват, знали на что шли."
                show ghost_ht2:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                if rightornot == 0:
                    $ ghost += 1
                    characterht2 "Так не бывает, чтоб никто не был виноват.  За свою безответственность ты остаешься с призраками навсегда! Ответ неверный! +1 Призрак"
                else:
                    "Так не бывает, чтоб никто не был виноват.  За свою безответственность ты остаешься с призраками навсегда! Ответ неверный!" 
                hide ghost_ht2 with dissolve
                hide g2 with dissolve
                $ rightornot += 1
                jump scene27_0_g
            "Прочитать загадку еще раз":
                jump scene27_0_g_0
        jump scene28

label scene28:
    scene 2back1 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music ball fadein 2.0 loop if_changed
    if gender == "M":
        "Призрак растворился, словно его здесь и не было. [player_name] зачарованно смотрел на то место, где он только что был."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Молодец, мой друг! Все лавры достаются тебе!"
        "[player_name] подпрыгнул от неожиданности на месте."
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич! Нельзя так подкрадываться. И эти ваши вечные ботанические ассоциации… Какие тут лавры, если я понятия не имею, что буду делать дальше."
        tmrz "Начало положено!"
        hide m7 with dissolve
        hide t1 with dissolve
        jump scene29
    elif gender == "G":
        "Призрак растворился, словно его здесь и не было. [player_name] зачарованно смотрела на то место, где он только что был."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Молодец, мой друг! Все лавры достаются тебе!"
        "[player_name] подпрыгнула от неожиданности на месте."
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич! Нельзя так подкрадываться. И эти ваши вечные ботанические ассоциации… Какие тут лавры, если я понятия не имею, что буду делать дальше."
        tmrz "Начало положено!"
        hide g7 with dissolve
        hide t1 with dissolve
        jump scene29


label scene29:
    scene 2back1 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        if book_lermnt == 1:
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Посмотри внимательно по сторонам. В прошлый раз ты нашел одну из утерянных книг, может быть и в этот раз удача от тебя не отвернется!"
            hide t1 with dissolve
        else:
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Но не зазнавайся, [player_name]. В прошлый раз после встречи с призраком ты не заметил книгу. Не забывай осматриваться по сторонам. Может, в этот раз получится?"
            hide t1 with dissolve  
        menu:
            "За дальней колонной":
                "Пусто."
            "Под лестницей":
                $ reality += 1
                $ verno += 1
                $ book_coi += 1
                "Верно! Вы нашли книгу «Цой» + Явь"
            "За ближней колонной":
                "Пусто."
        if verno == 0:
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Не расстраивайся, мой друг. Повезет в следующий раз. А пока нам нужно торопиться дальше. Открой карту и скажи, куда пойдем?"
            hide t1 with dissolve
        else:
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            show coi with fade:
                zoom 1.0 xalign 0 yalign 0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Отличная работа! А вот и подсказка…. Нам нужно отправиться туда, где могли бывать участники Ленинградского рок-клуба. Как ты думаешь, куда?"
            hide t1 with dissolve
            hide coi with dissolve
        $ verno = 0
        label scene29_0_m:
            menu:
                "ДК им. А. Д. Цюрупы":
                    if rightornot == 0:
                        $ reality += 1
                        "Верно, у вас хорошая интуиция. +Явь"
                    else:
                        "Верно, у вас хорошая интуиция."
                    tmrz  "Познакомимся с бывшим Домом Просветительных учреждений или Домом Культуры им. А.Д. Цюрупы."
                    $ rightornot = 0
                    jump scene30
                "Рынок":
                    if rightornot == 0:
                        $ ghost += 1
                        "Не верно. Попробуйте еще раз. + Призрак"
                        $ rightornot += 1
                    else:
                        "Не верно. Попробуйте еще раз."
                    jump scene29_0_m
                "Вокзал":
                    if rightornot == 0:
                        $ ghost += 1
                        "Не верно. Попробуйте еще раз. + Призрак"
                        $ rightornot += 1
                    else:
                        "Не верно. Попробуйте еще раз."
                    jump scene29_0_m
        jump scene30
    elif gender == "G":
        if book_lermnt == 1:
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Посмотри внимательно по сторонам. В прошлый раз ты нашла одну из утерянных книг, может быть, и в этот раз удача от тебя не отвернется!"
            hide t1 with dissolve
        else:
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Но не зазнавайся, [player_name]. В прошлый раз после встречи с призраком ты не заметила книгу. Не забывай осматриваться по сторонам. Может в этот раз получится?"
            hide t1 with dissolve  
        menu:
            "За дальней колонной":
                "Пусто."
            "Под лестницей":
                $ reality += 1
                $ verno += 1
                $ book_coi += 1
                "Верно! Вы нашли книгу «Цой» + Явь"
            "За ближней колонной":
                "Пусто."
        if verno == 0:
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Не расстраивайся, мой друг. Повезет в следующий раз. А пока нам нужно торопиться дальше. Открой карту и скажи, куда пойдем?"
            hide t1 with dissolve
        else:
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            show coi with fade:
                zoom 1.0 xalign 0 yalign 0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Отличная работа! А вот и подсказка…. Нам нужно отправиться туда, где могли бывать участники Ленинградского рок-клуба. Как ты думаешь, куда?"
            hide t1 with dissolve
            hide coi with dissolve
        $ verno = 0
        label scene29_0_g:
            menu:
                "ДК им. А. Д. Цюрупы":
                    if rightornot == 0:
                        $ reality += 1
                        "Верно, у вас хорошая интуиция. +Явь"
                    else:
                        "Верно, у вас хорошая интуиция."
                    tmrz  "Познакомимся с бывшим Домом Просветительных учреждений или Домом Культуры им. А.Д. Цюрупы."
                    $ rightornot = 0
                    jump scene30
                "Рынок":
                    if rightornot == 0:
                        $ ghost += 1
                        "Не верно. Попробуйте еще раз. + Призрак"
                        $ rightornot += 1
                    else:
                        "Не верно. Попробуйте еще раз."
                    jump scene29_0_g
                "Вокзал":
                    if rightornot == 0:
                        $ ghost += 1
                        "Не верно. Попробуйте еще раз. + Призрак"
                        $ rightornot += 1
                    else:
                        "Не верно. Попробуйте еще раз."
                    jump scene29_0_g
        jump scene30

label scene30:
    scene 2back2 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music dktsoy fadein 2.0 loop if_changed
    if gender == "M":
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Добро пожаловать, [player_name]. Ты не знаешь, наверно, но с 1913 года  это был главный культурный центр Везенбергского квартала."
        hide t2 with dissolve
        if archaeologist == 1:
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Я знаком с его историей. Он открылся в результате деятельности Общества народных университетов, которые ставили перед собой цель помогать работающим людям в получении образования, ликвидируя неграмотность."
            hide m1 with dissolve
        elif architect == 1:
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Здание в стиле модерн. Стиль был популярен на рубеже XIX—XX веков. Знаю, что здание построил Николай Всеволодович Дмитриев для деятельности Общества народных университетов."
            hide m1 with dissolve
        elif journalist == 1:
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Я слышал, что здесь когда-то была школа и множество различных кружков. В наше время его совсем недавно отреставрировали и снова открыли учебное заведение."
            hide m1 with dissolve
        elif botanist == 1:
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Здесь работали, так называемые, вечерние школы, которые посещали рабочие этого района."
            hide m1 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Молодец, мой друг! Все верно. А также здесь располагалась читальня им. Н. В. Гоголя. Сейчас ты знаешь ее как библиотеку им. К. А. Тимирязева."
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Тогда понятно, почему нам нужно сюда. Возможно, призраки решили вернуть книги на прежнее место, где когда-то был дом библиотеки."
        tmrz "Не будем загадывать. Вряд ли нам так повезет, что все издания, которые были похищены, окажутся только здесь. Нам предстоит еще многое пройти. Ты стал немного увереннее в себе и немного освоился в битве с призраками. Готов к следующему шагу?"
        hide m5 with dissolve
        hide t1 with dissolve
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        menu:
            character "Я..."
            "Готов":
                $ reality += 1
                "+Явь"
            "Постараюсь сделать все, что от меня зависит":
                $ ghost += 1
                $ reality += 1
                "+Явь +Призрак"
            "Не готов":
                $ ghost += 1
                "+Призрак"
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "В любом случае, времени на раздумья у нас нет.  Вперед!"
        hide t2 with dissolve
        hide m6 with dissolve
        jump scene31
    elif gender == "G":
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Добро пожаловать, [player_name]. Ты не знаешь, наверно, но с 1913 года  это был главный культурный центр Везенбергского квартала."
        hide t2 with dissolve
        if archaeologist == 1:
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Я знакома с его историей. Он открылся в результате деятельности Общества народных университетов, которые ставили перед собой цель помогать работающим людям в получении образования, ликвидируя неграмотность."
            hide g1 with dissolve
        elif architect == 1:
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Здание в стиле модерн. Стиль был популярен на рубеже XIX—XX веков. Знаю, что здание построил Николай Всеволодович Дмитриев для деятельности Общества народных университетов."
            hide g1 with dissolve
        elif journalist == 1:
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Я слышала, что здесь когда-то была школа и множество различных кружков. В наше время его совсем недавно отреставрировали и снова открыли учебное заведение."
            hide g1 with dissolve
        elif botanist == 1:
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Здесь работали, так называемые, вечерние школы, которые посещали рабочие этого района."
            hide g1 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Молодец, мой друг! Все верно. А также здесь располагалась читальня им. Н. В. Гоголя. Сейчас ты знаешь ее как библиотеку им. К. А. Тимирязева."
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Тогда понятно, почему нам нужно сюда. Возможно, призраки решили вернуть книги на прежнее место, где когда-то был дом библиотеки."
        tmrz "Не будем загадывать. Вряд ли нам так повезет, что все издания, которые были похищены, окажутся только здесь. Нам предстоит еще многое пройти. Ты стала немного увереннее в себе и немного освоилась в битве с призраками. Готова к следующему шагу?"
        hide g5 with dissolve
        hide t1 with dissolve
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        menu:
            character "Я..."
            "Готова":
                $ reality += 1
                "+Явь"
            "Постараюсь сделать все, что от меня зависит":
                $ ghost += 1
                $ reality += 1
                "+Явь +Призрак"
            "Не готова":
                $ ghost += 1
                "+Призрак"
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "В любом случае, времени на раздумья у нас нет.  Вперед!"
        hide t2 with dissolve
        hide g6 with dissolve
        jump scene31

label scene31:
    scene 2back3 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        "[player_name] и Климент Аркадьевич направлялись сразу в библиотеку, однако внезапно их остановила музыка, доносящаяся из-за двери."
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Знакомый стиль…"
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Ты уверен, что нам стоит здесь задерживаться?"
        character "Но… Вы, кажется, говорили, что здесь репетировал кто-то из рок-клуба? Вдруг, это моя любимая группа, а я пройду мимо?"
        tmrz "Пока это еще не твоя любимая группа, а просто какие-то бездельники в глазах окружающих людей."
        hide m5 with dissolve
        show m8:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Это точно они! Я хочу посмотреть!"
        tmrz "Да стой ты! Все равно это призраки, они растворятся, как только ты зайдешь сюда."
        hide m8 with dissolve
        hide t1 with dissolve
        jump scene32
    elif gender == "G":
        "[player_name] и Климент Аркадьевич направлялись сразу в библиотеку, однако внезапно их остановила музыка, доносящаяся из-за двери."
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Знакомый стиль…"
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Ты уверена, что нам стоит здесь задерживаться?"
        character "Но… Вы, кажется, говорили, что здесь репетировал кто-то из рок-клуба? Вдруг, это моя любимая группа, а я пройду мимо?"
        tmrz "Пока это еще не твоя любимая группа, а просто какие-то бездельники в глазах окружающих людей."
        hide g5 with dissolve
        show g8:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Это точно они! Я хочу посмотреть!"
        tmrz "Да стой ты! Все равно это призраки, они растворятся, как только ты зайдешь сюда."
        hide g8 with dissolve
        hide t1 with dissolve
        jump scene32

label scene32:
    scene 2back4 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        "[player_name] уже не слушал Климента Аркадьевича. Резко открыв дверь, он ворвался в большой зал, напоминающий концертный. Здесь была сцена, множество кресел, не хватало только собравшихся зрителей."
        "К сожалению, как и сказал Тимирязев, призраков уже не было в зале. Но все еще была слышна музыка, словно они продолжали репетировать, правда [player_name] это уже никогда не увидит. "
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я должен был попытаться. Не упускать же такой шанс."
        hide m7 with dissolve
        "Климент Аркадьевич пожал плечами, словно бы ожидал такой развязки, но ничего не сказал."
        "[player_name] хотел уже разочарованно уйти, но задумался."
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Не просто же меня словно завлекли в этот зал…"
        hide m5 with dissolve
        menu:
            "Мне стоит"
            "Осмотреть сцену":
                "Здесь, похоже, проходили не только репетиции и концерты, но и театральные постановки."
                "Вы, к сожалению, не нашли ничего полезного, [player_name] отправился дальше."
            "Проверить кресла":
                "[player_name] прошелся вдоль кресел и сел на одно из них. Фантазия нарисовала картину прежних лет. Большой зал со зрителями, на сцене выступают артисты. Шумная толпа народа набивается в зал, желая посмотреть, какое мероприятие в этот раз подготовили в Доме Культуры."
                show m1:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Может, я сошел с ума…"
                character "Но почему бы не проверить…"
                "[player_name] нагнулся, чтобы посмотреть под кресло."
                show canal with fade:
                    zoom 1.0 xalign 0 yalign 0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                $ book_canal += 1
                $ reality += 1
                "Вы нашли новую книгу! + Явь"
                character "Книги обычно предсказывают, что будет дальше… Видимо, в следующий раз стоит искать подсказку на Обводном канале."
                hide canal with dissolve
                hide m1 with dissolve
            "Посмотреть на люстру":
                show m3:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Красивая… Правда, в мире призраков не стоит стоять прямо под ней. Вдруг кто-то из недоброжелателей решит воспользоваться ситуацией  и расправиться со мной."
                hide m3 with dissolve
                "Вы, к сожалению, не нашли ничего полезного."
        stop music fadeout 2.0
        play music untitledMaster fadein 2.0 loop if_changed
        "[player_name] рассматривал зал, желая здесь ненадолго задержаться. Он и не заметил, как Климент Аркадьевич куда-то пропал. Поэтому, когда услышал странные звуки за спиной, решил, что это Тимирязев, и обернулся."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич, я…"
        hide m1 with dissolve
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "…"
        show ghost_pevica:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterpevica "Ты пришел послушать мое пение?"
        character "Я…"
        "Не дослушав [player_name], призрак разомкнула пугающую челюсть и закричала. Было похоже, что она пытается петь, но звук был невыносим для ушей обычного человека."
        character "Прекрати!!!"
        "Певица на мгновение остановилась, и ее взгляд стал злее."
        characterpevica "Тебе не нравится, как я пою? Как ты смеешь!"
        "Она злобно оскалилась и выдвинулась в атаку."
        hide ghost_pevica with dissolve
        hide m7 with dissolve
        label scene32_0_m:
            $ return_label = "scene32_1_timeout_m"  # Куда перейти при тайм-ауте
            show screen choice_timer(5)             # Таймер на 5 секунды
            menu:
                "Спрятаться":
                    hide screen choice_timer
                    "[player_name] заметался в поисках укрытия. Выбор пал на пространство за сценой. Резво взобравшись по ступенькам, [player_name] скользнул в проем, но почувствовал, как кто-то схватил его за шиворот."
                    show ghost_pevica:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpevica "Попался! Теперь  будешь слушать мои концерты вечность!"
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вам не удалось справиться, попробуйте еще раз! +1 Призрак"
                    else:
                        "Вам не удалось справиться, попробуйте еще раз!"
                    hide ghost_pevica with dissolve
                    jump scene32_0_m
                "Атаковать":
                    hide screen choice_timer
                    "Собрав последние силы, [player_name] с диким криком бросился на призрака, но прошел сквозь него. Певица на несколько секунд растерялась, но затем снова оскалилась. "
                    show ghost_pevica:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpevica "Ты ненормальный?"
                    show m7:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Я…"
                    "[player_name] тоже растерялся, испуганно замерев. Воспользовавшись этим, призрачная женщина схватила его за шиворот."
                    characterpevica "Попался! Теперь  будешь слушать мои концерты вечность!"
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вам не удалось справиться, попробуйте еще раз! +1 Призрак"
                    else:
                        "Вам не удалось справиться, попробуйте еще раз!"
                    hide m7 with dissolve
                    hide ghost_pevica with dissolve
                    jump scene32_0_m
                "Бежать":
                    hide screen choice_timer
                    "[player_name], недолго думая, бросился к выходу."
                    if rightornot == 0:
                        $ reality += 1
                        "+1 Явь"
                    $ rightornot = 0
                    jump scene33
                "Закричать":
                    hide screen choice_timer
                    "[player_name] замер, а затем громко закричал, пародируя призрака."
                    "Певица вздрогнула и на долю секунды растерялась."
                    show ghost_pevica:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpevica  "Ты что это…"
                    characterpevica "Передразнивать меня вздумал?"
                    "Призрак озлобился еще сильнее прежнего и кинулся вперед. [player_name] почувствовал, как его схватили за шиворот."
                    characterpevica "Попался! Теперь  будешь слушать мои концерты вечность!"
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вам не удалось справиться, попробуйте еще раз! +1 Призрак"
                    else:
                        "Вам не удалось справиться, попробуйте еще раз!"
                    hide ghost_pevica with dissolve
                    jump scene32_0_m
            label scene32_1_timeout_m:
                hide screen choice_timer
                "[player_name] заметался в поисках укрытия. Выбор пал на пространство за сценой. Резво взобравшись по ступенькам, [player_name] скользнул в проем, но почувствовал, как кто-то схватил его за шиворот."
                show ghost_pevica:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpevica "Попался! Теперь  будешь слушать мои концерты вечность!"
                if rightornot == 0:
                    $ ghost += 1
                    $ rightornot += 1
                    "Вам не удалось справиться, попробуйте еще раз! +1 Призрак"
                else:
                    "Вам не удалось справиться, попробуйте еще раз!"
                hide ghost_pevica with dissolve
                jump scene32_0_m
        jump scene33
    elif gender == "G":
        "[player_name] уже не слушала Климента Аркадьевича. Резко открыв дверь, она ворвалась в большой зал, напоминающий концертный. Здесь была сцена, множество кресел, не хватало только собравшихся зрителей."
        "К сожалению, как и сказал Тимирязев, призраков уже не было в зале. Но все еще была слышна музыка, словно они продолжали репетировать, правда [player_name] это уже никогда не увидит. "
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я должна была попытаться. Не упускать же такой шанс."
        hide g7 with dissolve
        "Климент Аркадьевич пожал плечами, словно бы ожидал такой развязки, но ничего не сказал."
        "[player_name] хотела уже разочарованно уйти, но задумалась."
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Не просто же меня словно завлекли в этот зал…"
        hide g5 with dissolve
        menu:
            "Мне стоит"
            "Осмотреть сцену":
                "Здесь, похоже, проходили не только репетиции и концерты, но и театральные постановки."
                "Вы, к сожалению, не нашли ничего полезного, [player_name] отправилась дальше."
            "Проверить кресла":
                "[player_name] прошлась вдоль кресел и села на одно из них. Фантазия нарисовала картину прежних лет. Большой зал со зрителями, на сцене выступают артисты. Шумная толпа народа набивается в зал, желая посмотреть, какое мероприятие в этот раз подготовили в Доме Культуры."
                show g1:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Может, я сошла с ума…"
                character "Но почему бы не проверить…"
                "[player_name] нагнулась, чтобы посмотреть под кресло."
                show canal with fade:
                    zoom 1.0 xalign 0 yalign 0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                $ book_canal += 1
                $ reality += 1
                "Вы нашли новую книгу! + Явь"
                character "Книги обычно предсказывают, что будет дальше… Видимо, в следующий раз стоит искать подсказку на Обводном канале."
                hide canal with dissolve
                hide g1 with dissolve
            "Посмотреть на люстру":
                show g3:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Красивая… Правда, в мире призраков не стоит стоять прямо под ней. Вдруг кто-то из недоброжелателей решит воспользоваться ситуацией  и расправиться со мной."
                hide g3 with dissolve
                "Вы, к сожалению, не нашли ничего полезного."
        stop music fadeout 2.0
        play music untitledMaster fadein 2.0 loop if_changed
        "[player_name] рассматривала зал, желая здесь ненадолго задержаться. Она и не заметила, как Климент Аркадьевич куда-то пропал. Поэтому, когда услышала странные звуки за спиной, решила, что это Тимирязев, и обернулась."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич, я…"
        hide g1 with dissolve
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "…"
        show ghost_pevica:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterpevica "Ты пришла послушать мое пение?"
        character "Я…"
        "Не дослушав [player_name], призрак разомкнула пугающую челюсть и закричала. Было похоже, что она пытается петь, но звук был невыносим для ушей обычного человека."
        character "Прекрати!!!"
        "Певица на мгновение остановилась, и ее взгляд стал злее."
        characterpevica "Тебе не нравится, как я пою? Как ты смеешь!"
        "Она злобно оскалилась и выдвинулась в атаку."
        hide ghost_pevica with dissolve
        hide g7 with dissolve
        label scene32_0_g:
            $ return_label = "scene32_1_timeout_g"  # Куда перейти при тайм-ауте
            show screen choice_timer(5)             # Таймер на 5 секунды
            menu:
                "Спрятаться":
                    hide screen choice_timer
                    "[player_name] заметалась в поисках укрытия. Выбор пал на пространство за сценой. Резво взобравшись по ступенькам, [player_name] скользнула в проем, но почувствовала, как кто-то схватил ее за шиворот."
                    show ghost_pevica:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpevica "Попалась! Теперь  будешь слушать мои концерты вечность!"
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вам не удалось справиться, попробуйте еще раз! +1 Призрак"
                    else:
                        "Вам не удалось справиться, попробуйте еще раз!"
                    hide ghost_pevica with dissolve
                    jump scene32_0_g
                "Атаковать":
                    hide screen choice_timer
                    "Собрав последние силы, [player_name] с диким криком бросилась на призрака, но прошла сквозь него. Певица на несколько секунд растерялась, но затем снова оскалилась."
                    show ghost_pevica:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpevica "Ты ненормальная?"
                    show g7:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Я…"
                    "[player_name] тоже растерялась, испуганно замерев. Воспользовавшись этим, призрачная женщина схватила ее за шиворот."
                    characterpevica "Попалась! Теперь  будешь слушать мои концерты вечность!"
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вам не удалось справиться, попробуйте еще раз! +1 Призрак"
                    else:
                        "Вам не удалось справиться, попробуйте еще раз!"
                    hide g7 with dissolve
                    hide ghost_pevica with dissolve
                    jump scene32_0_g
                "Бежать":
                    hide screen choice_timer
                    "[player_name], недолго думая, бросилась к выходу."
                    if rightornot == 0:
                        $ reality += 1
                        "+1 Явь"
                    $ rightornot = 0
                    jump scene33
                "Закричать":
                    hide screen choice_timer
                    "[player_name] замерла, а затем громко закричала, пародируя призрака."
                    "Певица вздрогнула и на долю секунды растерялась."
                    show ghost_pevica:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpevica  "Ты что это…"
                    characterpevica "Передразнивать меня вздумала?"
                    "Призрак озлобился еще сильнее прежнего и кинулся вперед. [player_name] почувствовала, как ее схватили за шиворот."
                    characterpevica "Попалась! Теперь  будешь слушать мои концерты вечность!"
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вам не удалось справиться, попробуйте еще раз! +1 Призрак"
                    else:
                        "Вам не удалось справиться, попробуйте еще раз!"
                    hide ghost_pevica with dissolve
                    jump scene32_0_g
            label scene32_1_timeout_g:
                hide screen choice_timer
                "[player_name] заметалась в поисках укрытия. Выбор пал на пространство за сценой. Резво взобравшись по ступенькам, [player_name] скользнула в проем, но почувствовала, как кто-то схватил ее за шиворот."
                show ghost_pevica:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpevica "Попалась! Теперь  будешь слушать мои концерты вечность!"
                if rightornot == 0:
                    $ ghost += 1
                    $ rightornot += 1
                    "Вам не удалось справиться, попробуйте еще раз! +1 Призрак"
                else:
                    "Вам не удалось справиться, попробуйте еще раз!"
                hide ghost_pevica with dissolve
                jump scene32_0_g
        jump scene33

label scene33:
    scene 2back5 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music office fadein 2.0 loop if_changed
    if gender == "M":
        "[player_name] забежал в учебный класс и быстро спрятался под парту."
        "Призрак певицы медленно вплыл в помещение и посмотрел по сторонам."
        show ghost_pevica:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterpevica "…"
        show m4:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "…"
        characterpevica "Где же ты?"
        "[player_name] старался не шевелиться."
        characterpevica "Я знаю, как тебя выманить…"
        "Певица снова взывала нечеловеческим голосом."
        hide m4 with dissolve
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Нет, пожалуйста… Это невозможно выдержать."
        hide m7 with dissolve
        hide ghost_pevica with dissolve
        label scene33_0_m:
            $ return_label = "scene33_1_timeout_m"  # Куда перейти при тайм-ауте
            show screen choice_timer(5)             # Таймер на 5 секунды
            menu:
                "Выбежать":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вас поймали, попробуйте еще раз. +1 Призрак"
                    else:
                        "Вас поймали, попробуйте еще раз."
                    jump scene33_0_m
                "Выбежать":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вас поймали, попробуйте еще раз. +1 Призрак"
                    else:
                        "Вас поймали, попробуйте еще раз."
                    jump scene33_0_m
                "Терпеть":
                    hide screen choice_timer
                    "Было тяжело, но [player_name], заткнув уши и зажмурившись, старался не шевелиться. Казалось, прошла целая вечность, пока призрак не замолчал."
                    $ rightornot = 0
                    show ghost_pevica:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpevica "Хммм…"
                    "В последний раз певица посмотрела по сторонам и, помедлив, двинулась прочь."
                    hide ghost_pevica with dissolve
                    show m4:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Нужно искать Климента Аркадьевича и уходить отсюда."
                    hide m4 with dissolve
                    jump scene34
                "Выбежать":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вас поймали, попробуйте еще раз. +1 Призрак"
                    else:
                        "Вас поймали, попробуйте еще раз."
                    jump scene33_0_m
            label scene33_1_timeout_m:
                    hide screen choice_timer
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вас поймали, попробуйте еще раз. +1 Призрак"
                    else:
                        "Вас поймали, попробуйте еще раз."
                    jump scene33_0_m
        jump scene34
    elif gender == "G":
        "[player_name] забежала в учебный класс и быстро спряталась под парту."
        "Призрак певицы медленно вплыл в помещение и посмотрел по сторонам."
        show ghost_pevica:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterpevica "…"
        show g4:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "…"
        characterpevica "Где же ты?"
        "[player_name] старалась не шевелиться."
        characterpevica "Я знаю, как тебя выманить…"
        "Певица снова взывала нечеловеческим голосом."
        hide g4 with dissolve
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Нет, пожалуйста… Это невозможно выдержать."
        hide g7 with dissolve
        hide ghost_pevica with dissolve
        label scene33_0_g:
            $ return_label = "scene33_1_timeout_g"  # Куда перейти при тайм-ауте
            show screen choice_timer(5)             # Таймер на 5 секунды
            menu:
                "Выбежать":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вас поймали, попробуйте еще раз. +1 Призрак"
                    else:
                        "Вас поймали, попробуйте еще раз."
                    jump scene33_0_g
                "Выбежать":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вас поймали, попробуйте еще раз. +1 Призрак"
                    else:
                        "Вас поймали, попробуйте еще раз."
                    jump scene33_0_g
                "Терпеть":
                    hide screen choice_timer
                    "Было тяжело, но [player_name], заткнув уши и зажмурившись, старалась не шевелиться. Казалось, прошла целая вечность, пока призрак не замолчал."
                    $ rightornot = 0
                    show ghost_pevica:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpevica "Хммм…"
                    "В последний раз певица посмотрела по сторонам и, помедлив, двинулась прочь."
                    hide ghost_pevica with dissolve
                    show g4:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Нужно искать Климента Аркадьевича и уходить отсюда."
                    hide g4 with dissolve
                    jump scene34
                "Выбежать":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вас поймали, попробуйте еще раз. +1 Призрак"
                    else:
                        "Вас поймали, попробуйте еще раз."
                    jump scene33_0_g
            label scene33_1_timeout_g:
                hide screen choice_timer
                if rightornot == 0:
                    $ ghost += 1
                    $ rightornot += 1
                    "Вас поймали, попробуйте еще раз. +1 Призрак"
                else:
                    "Вас поймали, попробуйте еще раз."
                jump scene33_0_g
        jump scene34

label scene34:
    scene 2back6 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music calmness fadein 2.0 loop if_changed
    if gender == "M":
        "[player_name] сломя голову бегал по коридору в поисках Тимирязева. Повезло, что Певица куда-то запропастилась и больше не являлась. [player_name] был не уверен, что ему удастся выдержать ужасающую песню еще раз."
        "Тимирязев нашелся в библиотеке. Он задумчиво листал книги."
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич, что за шутки! Где вы были?"
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Прости, мой друг. Предавался ностальгии."
        character "Вы серьезно? Я чуть не погиб!"
        "Климент Аркадьевич сочувствующе посмотрел в ответ."
        tmrz "Прости меня, но ты должен понять, что это только твой путь. Я стараюсь тебе помочь, на сколько способен. Но сделать все за тебя, я, к сожалению, не смогу."
        "[player_name] хотел резко ответить то, что крутилось у него в голове, но вовремя остановился."
        "Уже стало ясно, что никуда от своей внезапной миссии не деться. Придется принимать правила игры."
        "Тимирязев выглядел немного опечаленным. [player_name] задумался."
        hide m2 with dissolve
        menu:
            "Подбодрить Климента Аркадьевича":
                show m1:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Вы чем-то расстроены?"
                tmrz "Просто подумал, что здесь раньше была наша библиотека, все меняется, и мир меняется. Не знаю, хорошо ли это или плохо."
                character "Вы сами говорили, что это нормальное течение жизни. Да и теперь у библиотеки есть ваше Имя, большое пространство и море возможностей."
                "Тимирязев снова добродушно улыбнулся. Ему приятно, что вам не безразлична его задумчивость."
                tmrz "Ты прав, мой друг."
                hide m1 with dissolve
            "Сделать вид, что не замечаешь":
                "Вы огорчаете своим равнодушием Климента Аркадьевича."         
        "[player_name] заметил книгу в его руках."
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А что вы читаете?"
        "[player_name] посмотрел на страницы, но они были пусты."
        tmrz "Это книжка о магических свойствах растений. Забавная литература."
        character "Но здесь же ничего нет."
        "Тимирязев по-доброму рассмеялся."
        tmrz "Прости, совсем забыл, так как этих книг уже нет, прочитать то, что здесь написано, могут только призраки. Давай я расскажу тебе несколько фактов-шуток, описанных здесь."
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Например, полынь издавна почитают как растение-оберег, она защищает от злых духов. А с помощью лаврового листа в древности усиливали способность к прорицанию и вызывали видения. А вот лаванда исцеляет и дает жизненную силу."
        "Эта информация вам скоро пригодится."
        hide m5 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        if book_canal == 1:
            character "Ммм… Я запомню. Пойдем, Климент Аркадьевич. Я получил следующую подсказку, и нам нужно отправляться дальше. Думаю, что приключения нас ждут где-то у Обводного канала."
        else:
            character "Ммм... Я запомню. Пойдем, Климент Аркадьевич."
        hide m1 with dissolve
        hide t2 with dissolve
        jump scene35
    elif gender == "G":
        "[player_name] сломя голову бегала по коридору в поисках Тимирязева. Повезло, что Певица куда-то запропастилась и больше не являлась. [player_name] была не уверена, что ей удастся выдержать ужасающую песню еще хоть раз."
        "Тимирязев нашелся в библиотеке. Он задумчиво листал книги."
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич, что за шутки! Где вы были?"
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Прости, мой друг. Предавался ностальгии."
        character "Вы серьезно? Я чуть не погибла!"
        "Климент Аркадьевич сочувствующе посмотрел в ответ."
        tmrz "Прости меня, но ты должна понять, что это только твой путь. Я стараюсь тебе помочь, насколько способен. Но сделать все за тебя, я, к сожалению, не смогу."
        "[player_name] хотела резко ответить то, что крутилось у нее в голове, но вовремя остановилась."
        "Уже стало ясно, что никуда от своей внезапной миссии не деться. Придется принимать правила игры."
        "Тимирязев выглядел немного опечаленным. [player_name] задумалась."
        hide g2 with dissolve
        menu:
            character ""
            "Подбодрить Климента Аркадьевича":
                show g1:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Просто подумал, что здесь раньше была наша библиотека, все меняется, и мир меняется. Не знаю, хорошо ли это или плохо."
                character "Вы сами говорили, что это нормальное течение жизни. Да и теперь у библиотеки есть ваше Имя, большое пространство и море возможностей."
                "Тимирязев снова добродушно улыбнулся. Ему приятно, что вам не безразлична его задумчивость."
                tmrz "Ты прав, мой друг."
                hide g1 with dissolve
            "Сделать вид, что не замечаешь":
                "Вы огорчаете своим равнодушием Климента Аркадьевича."  
        "[player_name] заметила книгу в его руках."
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А что вы читаете?"
        "[player_name] посмотрела на страницы, но они были пусты."
        tmrz "Это книжка о магических свойствах растений. Забавная литература."
        character "Но здесь же ничего нет."
        "Тимирязев по-доброму рассмеялся."
        tmrz "Прости, совсем забыл, так как этих книг уже нет, прочитать то, что здесь написано, могут только призраки. Давай я расскажу тебе несколько фактов-шуток, описанных здесь."
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Например, полынь издавна почитают как растение-оберег, она защищает от злых духов. А с помощью лаврового листа в древности усиливали способность к прорицанию и вызывали видения. А вот лаванда исцеляет и дает жизненную силу."
        "Эта информация вам скоро пригодится."
        hide g5 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        if book_canal == 1:
            character "Ммм… Я запомню. Пойдем, Климент Аркадьевич. Я получила следующую подсказку, и нам нужно отправляться дальше. Думаю, что приключения нас ждут где-то у Обводного канала."
        else:
            character "Ммм… Я запомню. Пойдем, Климент Аркадьевич."
        hide g1 with dissolve
        hide t2 with dissolve
        jump scene35

label scene35:
    scene 2back7 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music mermaiddone fadein 2.0 loop if_changed
    if gender == "M":
        "[player_name] стоял на Ново-Петергофском мосту и вглядывался в канал. Пока было спокойно, и даже ветер не создавал рябь на водной глади. Климент Аркадьевич оставил пока его одного и стоял неподалеку, изучая растения, которые прорастали рядом с этим местом."
        "Появилось время подумать о том, что происходит, проанализировать то, что никак не поддавалось осмыслению."
        "Пропавшие библиотекари, призрачный квартал, безумное течение времени – не хотелось признавать, но все это было действительно реально. В голове предательски возникали мысли о том, что этот путь – большая ответственность."
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "…"
        hide m6 with dissolve
        "[player_name] сомневался, что справится. Конечно, ему хотелось помочь и вернуть все на места. Но нет никакой инструкции, как победить призраков."
        "Он дал себе обещание, что если все вернется на свои места, то обязательно изучит судьбу тех, кто когда-то пребывал в Везенбергском квартале. Не смотря на все козни, что устраивали призраки, их было очень жаль."
        "История не должна забываться, иначе мы рискуем потерять что-то важное и начать ошибаться снова и снова, ничему так и не научившись."
        characterVois "Тебе не обязательно бороться с этим миром."
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Снова этот голос!"
        characterVois "Ты же можешь остаться здесь…"
        hide m7 with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ну уж нет! Спасибо. Не настолько я проникся атмосферой."
        characterVois "Ты устал и совсем не понимаешь, где находишься. А между тем, время бежит, и его осталось совсем мало. Тревога в твоем сердце нарастает все больше и больше, ты боишься, что тебе не удастся все разрешить."
        characterVois "Так, может быть, лучше начать привыкать ко всему, что тебя окружает. Так, на всякий случай…"
        hide m2 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я надеюсь, что смогу…"
        characterVois "Ты совсем юн для такой тяжелой ноши. Как ты можешь бороться с силой, которая копилась на этой территории веками?"
        hide m1 with dissolve
        "Неизвестный голос проник в самые потаенные мысли. Он словно обволакивал сознание. [player_name] против воли стал прислушиваться к нему."
        characterVois "Подойди поближе, не бойся. Я помогу тебе справиться."
        "Ноги сами шагали вперед, ближе к ограде моста. Водная гладь гипнотизировала, ее хотелось коснуться."
        characterVois "Я буду твоим другом на этом пути."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "У меня уже есть друг."
        characterVois "Климент Аркадьевич очень умный… и хитрый. Он же тоже призрак, откуда ты знаешь, что он дает тебе правильные советы, а не делает так, чтобы твой мир скорее превратился в старый квартал?"
        hide m1 with dissolve
        "[player_name] посмотрел на Тимирязева, который с увлечением делал какие-то заметки в записной книжке, рассматривая заинтересовавшее его растение."
        "[player_name] ведь на самом деле не может быть уверен, что Климент Аркадьевич на его стороне. А с другой стороны, если не доверять никому, то как не сойти с ума в этом мире?"
        characterVois "Я расскажу тебе всю правду. От тебя скрыли все самое важное. Твои возможности!"
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Возможности?"
        characterVois "Придет время, и призраки охватят весь мир, это сейчас мы проживаем только в квартале. Скоро туман охватит город и будет распространяться дальше. Если ты будешь с нами – сможешь возглавить нас. Получишь безграничную власть…"
        "Голос играл на струнках потаенных желаний. Всегда хотелось стать кем-то значимым, а тут предоставляется такой шанс. Призраки, так или иначе, завоюют мир, выбор только такой – сражаться и проиграть или присоединиться и возглавить."
        "Растворяясь в грезах, [player_name] тянулся к воде…"
        hide m5 with dissolve
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Может…лучше сдаться?"
        characterVois "Конечно. Сразу можно будет расслабиться, тяжкое бремя спадет с плеч. В конце концов, это так несправедливо, что, не спросив, они втянули тебя в эту пугающую игру. Я обниму тебя и успокою. Мы вместе придумаем, что делать дальше…"
        hide m6 with dissolve
        stop music fadeout 2.0
        play music office fadein 2.0 loop if_changed
        "[player_name] почти забрался на ограду, чтобы прыгнуть вниз, в воду, как внезапно его схватили за руку."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Мой друг! Что ты делаешь!"
        "[player_name] очнулся от гипноза и удивленно посмотрел по сторонам."
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что происходит?"
        tmrz "Я, кажется, понял!"
        tmrz "Выходи!!!"
        "[player_name] замер в ожидании. Голос пропал, и никто не спешил показываться. Но Климент Аркадьевич стоял на своем."
        tmrz "А ну выйди, покажись!"
        "Туман стелился по Обводному каналу, становился плотнее. Внезапно клубы поднялись до самого моста, и в самой гуще показался силуэт. Из тумана на мост вышла русалка."
        show ghost_fish:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterfish "Хитрый вредный ученый! Почти ведь заманила к себе. Надо же было тебе влезть!"
        tmrz "Еще чего!"
        characterfish "Ну, теперь вы оба уйдете со мной под воду!!!"
        "Русалка направилась на чужаков."
        tmrz "[player_name]! Там, рядом с мостом небольшой зеленый участок! Ты должен найти правильное растение, чтобы справиться с русалкой! Вспомни то, о чем мы говорили в библиотеке! Беги скорее, я ее задержу!"
        "[player_name] немедленно побежал искать."
        hide ghost_fish with dissolve
        hide m7 with dissolve
        hide t1 with dissolve
        label scene35_0_m:
            $ return_label = "scene35_1_timeout_m"  # Куда перейти при тайм-ауте
            show screen choice_timer(5)             # Таймер на 5 секунды
            menu:
                "Лаванда":
                    hide screen choice_timer
                    show m7:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Да как она выглядит?! Тут полно синих цветов! Лаванда вообще синяя или сиреневая?!"
                    "[player_name] быстро сорвал цветок похожий на лаванду и вернулся к Клименту Аркадьевичу."
                    show t1:   
                        zoom 1.0 xalign 1.3 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    tmrz "Что это? Мой друг, это не то!!!"
                    show ghost_fish:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterfish  "Вот вы и попались!!!!!!!!"
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Попробуйте еще раз! +1 Призрак"
                    else:
                        "Попробуйте еще раз!"
                    hide ghost_fish with dissolve
                    hide t1 with dissolve
                    hide m7 with dissolve
                    jump scene35_0_m
                "Лавровый лист":
                    hide screen choice_timer
                    show m7:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Да как он выглядит?!"
                    "[player_name] быстро сорвал листы растения похожие на лавр и вернулся к Клименту Аркадьевичу."
                    show t1:   
                        zoom 1.0 xalign 1.3 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    tmrz "Что это? Мой друг, это не то!!!"
                    show ghost_fish:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterfish "Вот вы и попались!!!!!!!!"
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Попробуйте еще раз! +1 Призрак"
                    else:
                        "Попробуйте еще раз!"
                    hide ghost_fish with dissolve
                    hide t1 with dissolve
                    hide m7 with dissolve
                    jump scene35_0_m
                "Полынь":
                    hide screen choice_timer
                    show m5:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "У полыни специфический запах! Вроде бы это похоже на нее."
                    "[player_name] быстро сорвал растение похожее на полынь и вернулся к Клименту Аркадьевичу."
                    hide m5 with dissolve
                    show m7:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Что с этим делать?"
                    tmrz "У тебя есть спички? "
                    "[player_name] покопался в кармане и нашел коробку спичек."
                    tmrz "Быстро поджигай!"
                    "Руки тряслись от напряжения и быстроты действий, [player_name] поджег полынь и направил в сторону русалки, которая, недовольно шипя, пыталась напасть на ловко уворачивающегося от нее Тимирязева."
                    "Почувствовав запах, русалка резко замерла, перестав шипеть."
                    if rightornot == 0:
                        $ reality += 1
                        "Вы выбрали верно! Полынь помогает справиться со злыми духами. +1 Явь"
                    else:
                        "Вы выбрали верно! Полынь помогает справиться со злыми духами."
                    $ rightornot = 0
                    "Девушку снова окутал туман, она несколько раз попыталась лениво пошевелиться, но дым от полыни заставил ее окончательно сдаться. Когда туман рассеялся, призрак уже исчез."
                    hide m7 with dissolve
                    jump scene36
            label scene35_1_timeout_m:
                hide screen choice_timer
                show m7:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Да как она выглядит?! Тут полно синих цветов! Лаванда вообще синяя или сиреневая?!"
                "[player_name] быстро сорвал цветок похожий на лаванду и вернулся к Клименту Аркадьевичу."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Что это? Мой друг, это не то!!!"
                show ghost_fish:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterfish  "Вот вы и попались!!!!!!!!"
                if rightornot == 0:
                    $ ghost += 1
                    $ rightornot += 1
                    "Попробуйте еще раз! +1 Призрак"
                else:
                    "Попробуйте еще раз!"
                hide ghost_fish with dissolve
                hide t1 with dissolve
                hide m7 with dissolve
                jump scene35_0_m
        jump scene36
    elif gender == "G":
        "[player_name] стояла на Ново-Петергофском мосту и вглядывалась в канал. Пока было спокойно, и даже ветер не создавал рябь на водной глади. Климент Аркадьевич оставил пока её одну и стоял неподалеку, изучая растения, которые прорастали рядом с этим местом."
        "Появилось время подумать о том, что происходит, проанализировать то, что никак не поддавалось осмыслению."
        "Пропавшие библиотекари, призрачный квартал, безумное течение времени – не хотелось признавать, но все это было действительно реально. В голове предательски возникали мысли о том, что этот путь – большая ответственность."
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "…"
        hide g6 with dissolve
        "[player_name] сомневалась, что справится. Конечно, ей хотелось помочь и вернуть все на места. Но нет никакой инструкции, как победить призраков."
        "Она дала себе обещание, что если все вернется на свои места, то обязательно изучит судьбу тех, кто когда-то пребывал в Везенбергском квартале. Не смотря на все козни, что устраивали призраки, их было очень жаль."
        "История не должна забываться, иначе мы рискуем потерять что-то важное и начать ошибаться снова и снова, ничему так и не научившись."
        characterVois "Тебе не обязательно бороться с этим миром."
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Снова этот голос!"
        characterVois "Ты же можешь остаться здесь…"
        hide g7 with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ну уж нет! Спасибо. Не настолько я прониклась атмосферой."
        characterVois "Ты устала и совсем не понимаешь, где находишься. А между тем, время бежит, и его осталось совсем мало. Тревога в твоем сердце нарастает все больше и больше, ты боишься, что тебе не удастся все разрешить."
        characterVois "Так, может быть, лучше начать привыкать ко всему, что тебя окружает. Так, на всякий случай…"
        hide g2 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я надеюсь, что смогу…"
        characterVois "Ты совсем юна для такой тяжелой ноши. Как ты можешь бороться с силой, которая копилась на этой территории веками?"
        hide g1 with dissolve
        "Неизвестный голос проник в самые потаенные мысли. Он словно обволакивал сознание. [player_name] против воли стала прислушиваться к нему."
        characterVois "Подойди поближе, не бойся. Я помогу тебе справиться."
        "Ноги сами шагали вперед, ближе к ограде моста. Водная гладь гипнотизировала, ее хотелось коснуться."
        characterVois "Я буду твоим другом на этом пути."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "У меня уже есть друг."
        characterVois "Климент Аркадьевич очень умный… и хитрый. Он же тоже призрак, откуда ты знаешь, что он дает тебе правильные советы, а не делает так, чтобы твой мир скорее превратился в старый квартал?"
        hide g1 with dissolve
        "[player_name] посмотрела на Тимирязева, который с увлечением делал какие-то заметки в записной книжке, рассматривая заинтересовавшее его растение."
        "[player_name] ведь на самом деле не может быть уверена, что Климент Аркадьевич на ее стороне. А с другой стороны, если не доверять никому, то как не сойти с ума в этом мире?"
        characterVois "Я расскажу тебе всю правду. От тебя скрыли все самое важное. Твои возможности!"
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Возможности?"
        characterVois "Придет время, и призраки охватят весь мир, это сейчас мы проживаем только в квартале. Скоро туман охватит город и будет распространяться дальше. Если ты будешь с нами – сможешь возглавить нас. Получишь безграничную власть…"
        "Голос играл на струнках потаенных желаний. Всегда хотелось стать кем-то значимым, а тут предоставляется такой шанс. Призраки, так или иначе, завоюют мир, выбор только такой – сражаться и проиграть или присоединиться и возглавить."
        "Растворяясь в грезах, [player_name] тянулась к воде…"
        hide g5 with dissolve
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Может…лучше сдаться?"
        characterVois "Конечно. Сразу можно будет расслабиться, тяжкое бремя спадет с плеч. В конце концов, это так несправедливо, что, не спросив, они втянули тебя в эту пугающую игру. Я обниму тебя и успокою. Мы вместе придумаем, что делать дальше…"
        hide g6 with dissolve
        stop music fadeout 2.0
        play music office fadein 2.0 loop if_changed
        "[player_name] почти забралась на ограду, чтобы прыгнуть вниз, в воду, как внезапно ее схватили за руку."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Мой друг! Что ты делаешь!"
        "[player_name] очнулась от гипноза и удивленно посмотрела по сторонам."
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что происходит?"
        tmrz "Я, кажется, понял!"
        tmrz "Выходи!!!"
        "[player_name] замерла в ожидании. Голос пропал, и никто не спешил показываться. Но Климент Аркадьевич стоял на своем."
        tmrz "А ну выйди, покажись!"
        "Туман стелился по Обводному каналу, становился плотнее. Внезапно клубы поднялись до самого моста, и в самой гуще показался силуэт. Из тумана на мост вышла русалка."
        show ghost_fish:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterfish "Хитрый вредный ученый! Почти ведь заманила к себе. Надо же было тебе влезть!"
        tmrz "Еще чего!"
        characterfish "Ну, теперь вы оба уйдете со мной под воду!!!"
        "Русалка направилась на чужаков."
        tmrz "[player_name]! Там, рядом с мостом небольшой зеленый участок! Ты должна найти правильное растение, чтобы справиться с русалкой! Вспомни, то о чем мы говорили в библиотеке! Беги скорее, я ее задержу!"
        "[player_name] немедленно побежала искать."
        hide ghost_fish with dissolve
        hide g7 with dissolve
        hide t1 with dissolve
        label scene35_0_g:
            $ return_label = "scene35_1_timeout_g"  # Куда перейти при тайм-ауте
            show screen choice_timer(5)             # Таймер на 5 секунды
            menu:
                "Лаванда":
                    hide screen choice_timer
                    show g7:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Да как она выглядит?! Тут полно синих цветов! Лаванда вообще синяя или сиреневая?!"
                    "[player_name] быстро сорвала цветок похожий на лаванду и вернулась к Клименту Аркадьевичу."
                    show t1:   
                        zoom 1.0 xalign 1.3 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    tmrz "Что это? Мой друг, это не то!!!"
                    show ghost_fish:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterfish  "Вот вы и попались!!!!!!!!"
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Попробуйте еще раз! +1 Призрак"
                    else:
                        "Попробуйте еще раз!"
                    hide ghost_fish with dissolve
                    hide t1 with dissolve
                    hide g7 with dissolve
                    jump scene35_0_g
                "Лавровый лист":
                    hide screen choice_timer
                    show g7:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Да как он выглядит?!"
                    "[player_name] быстро сорвала листы растения похожие на лавр и вернулась к Клименту Аркадьевичу."
                    show t1:   
                        zoom 1.0 xalign 1.3 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    tmrz "Что это? Мой друг, это не то!!!"
                    show ghost_fish:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterfish "Вот вы и попались!!!!!!!!"
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Попробуйте еще раз! +1 Призрак"
                    else:
                        "Попробуйте еще раз!"
                    hide ghost_fish with dissolve
                    hide t1 with dissolve
                    hide g7 with dissolve
                    jump scene35_0_g
                "Полынь":
                    hide screen choice_timer
                    show g5:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "У полыни специфический запах! Вроде бы это похоже на нее."
                    "[player_name] быстро сорвала растение похожее на полынь и вернулась к Клименту Аркадьевичу."
                    hide g5 with dissolve
                    show g7:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Что с этим делать?"
                    tmrz "У тебя есть спички? "
                    "[player_name] покопалась в кармане и нашла коробку спичек."
                    tmrz "Быстро поджигай!"
                    "Руки тряслись от напряжения и быстроты действий, [player_name] подожгла полынь и направила в сторону русалки, которая, недовольно шипя, пыталась напасть на ловко уворачивающегося от нее Тимирязева."
                    "Почувствовав запах, русалка резко замерла, перестав шипеть."
                    if rightornot == 0:
                        $ reality += 1
                        "Вы выбрали верно! Полынь помогает справиться со злыми духами. +1 Явь"
                    else:
                        "Вы выбрали верно! Полынь помогает справиться со злыми духами."
                    $ rightornot = 0
                    "Девушку снова окутал туман, она несколько раз попыталась лениво пошевелиться, но дым от полыни заставил ее окончательно сдаться. Когда туман рассеялся, призрак уже исчез."
                    hide g7 with dissolve
                    jump scene36
            label scene35_1_timeout_g:
                hide screen choice_timer
                show g7:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Да как она выглядит?! Тут полно синих цветов! Лаванда вообще синяя или сиреневая?!"
                "[player_name] быстро сорвала цветок похожий на лаванду и вернулась к Клименту Аркадьевичу."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Что это? Мой друг, это не то!!!"
                show ghost_fish:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterfish  "Вот вы и попались!!!!!!!!"
                if rightornot == 0:
                    $ ghost += 1
                    $ rightornot += 1
                    "Попробуйте еще раз! +1 Призрак"
                else:
                    "Попробуйте еще раз!"
                hide ghost_fish with dissolve
                hide t1 with dissolve
                hide g7 with dissolve
                jump scene35_0_g
        jump scene36

label scene36:
    scene 2back10 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music mermaiddone fadein 2.0 loop if_changed
    if gender == "M":
        "Ненадолго Обводный канал словно опять приобрел краски, а призрачный сумрак затих."
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что это было?"
        "Тимирязев недовольно отряхивал костюм."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Есть два типа призраков. Одни – реально существовавшие когда-то люди, а другие – существа из городских легенд. Так вот, последние – самые опасные!"
        hide m2 with dissolve
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Почему?"
        tmrz "Никогда не знаешь, какими свойствами их наделят люди. Повезло, что это просто русалка. А вот встретился бы нам кто-то более ловкий, кто знает, чем бы закончилось это противостояние."
        hide m5 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А что за легенда о русалке?"
        tmrz "А легенда и не совсем про нее."
        hide m1 with dissolve
        hide t1 with dissolve
        scene 2back8 with fade:
            size (1280, 720)
            fit "fill"
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "По преданию, еще задолго до того, как проложили Обводный канал, в 1300 году на этих территориях находились поселения. Сюда прибыли шведы, которые пытались искоренить языческую веру среди местного населения. Они разрушали святилища и казнили всех, кто был непокорен."
        show ghost_magic:
            zoom 1.0 xalign 0.2 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        charactermagic "Будьте вы прокляты!"
        tmrz "Колдун наслал на шведские войска страшные проклятия. В их рядах появились раздоры, ужасные болезни, которые приводили к гибели. Среди людей поселился страх."
        tmrz "Один из местных смилостивился над сходящими с ума чужаками. И рассказал, как снять проклятие. Нужно было похоронить погибших вместе с колдуном и запечатать их захоронение круглой плитой с магическими письменами."
        hide ghost_magic with dissolve
        hide t2 with dissolve
        scene 2back9 with fade:
            size (1280, 720)
            fit "fill"
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Так и поступили."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Проклятие не исчезло, но было остановлено на очень долгое время."
        hide t1 with dissolve
        scene 2back10 with fade:
            size (1280, 720)
            fit "fill"
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Но это же было слишком давно."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "У этой истории есть продолжение. В 1923 году, когда вдоль Обводного канала прокладывали теплотрассу, захоронение снова было обнаружено. К сожалению, рабочие отнеслись к нему халатно, разбив плиту на части."
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Заклинание, сдерживающее проклятие колдуна, было разрушено и снова вырвалось на свободу. И с тех пор Обводный канал притягивает к себе всех, кто решил по нему прогуляться. Как-то поймали одного из тех, кто прислушался к манящему голосу и упал в воду."
        tmrz "Товарища опросили, уточнили, почему он прыгнул в Обводный."
        character "И что же он ответил?"
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "«Не знаю что нашло. Русалки к себе позвали»"
        tmrz "С тех пор и говорят о колдуне и русалках, которые витают над водами Обводного канала."
        hide m2 with dissolve
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Какая… пугающая легенда."
        tmrz "Будь осторожен. Призраки становятся сильнее, так как времени остается все меньше. Придется снова пройти через рынок, он уже успел поменяться, оказавшись в новой точке временной петли."
        "[player_name] посмотрел в сторону рынка."
        hide m5 with dissolve
        hide t1 with dissolve
        # кат - сцена
        scene 2back11 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=5.0, hard=True)
        scene 2back10 with fade:
            size (1280, 720)
            fit "fill"
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Да, больше нет палаток и лавочек…. Выглядит современнее."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Нужно спешить, пока мы не попали в худший период его существования."
        character "Тогда вперед! Я уже хочу скорее расправиться со всеми этими призракам!"
        tmrz "Отличный настрой, мой друг!"
        hide t1 with dissolve
        hide m1 with dissolve
        jump scene37
    elif gender == "G":
        "Ненадолго Обводный канал словно опять приобрел краски, а призрачный сумрак затих."
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что это было?"
        "Тимирязев недовольно отряхивал костюм."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Есть два типа призраков. Одни – реально существовавшие когда-то люди, а другие – существа из городских легенд. Так вот, последние – самые опасные!"
        hide g2 with dissolve
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Почему?"
        tmrz "Никогда не знаешь, какими свойствами их наделят люди. Повезло, что это просто русалка. А вот встретился бы нам кто-то более ловкий, кто знает, чем бы закончилось это противостояние."
        hide g5 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А что за легенда о русалке?"
        tmrz "А легенда и не совсем про нее."
        hide g1 with dissolve
        hide t1 with dissolve
        scene 2back8 with fade:
            size (1280, 720)
            fit "fill"
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "По преданию, еще задолго до того, как проложили Обводный канал, в 1300 году на этих территориях находились поселения. Сюда прибыли шведы, которые пытались искоренить языческую веру среди местного населения. Они разрушали святилища и казнили всех, кто был непокорен."
        show ghost_magic:
            zoom 1.0 xalign 0.2 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        charactermagic "Будьте вы прокляты!"
        tmrz "Колдун наслал на шведские войска страшные проклятия. В их рядах появились раздоры, ужасные болезни, которые приводили к гибели. Среди людей поселился страх."
        tmrz "Один из местных смилостивился над сходящими с ума чужаками. И рассказал, как снять проклятие. Нужно было похоронить погибших вместе с колдуном и запечатать их захоронение круглой плитой с магическими письменами."
        hide ghost_magic with dissolve
        hide t2 with dissolve
        scene 2back9 with fade:
            size (1280, 720)
            fit "fill"
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Так и поступили."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Проклятие не исчезло, но было остановлено на очень долгое время."
        hide t1 with dissolve
        scene 2back10 with fade:
            size (1280, 720)
            fit "fill"
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Но это же было слишком давно."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "У этой истории есть продолжение. В 1923 году, когда вдоль Обводного канала прокладывали теплотрассу, захоронение снова было обнаружено. К сожалению, рабочие отнеслись к нему халатно, разбив плиту на части."
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Заклинание, сдерживающее проклятие колдуна, было разрушено и снова вырвалось на свободу. И с тех пор Обводный канал притягивает к себе всех, кто решил по нему прогуляться. Как-то поймали одного из тех, кто прислушался к манящему голосу и упал в воду."
        tmrz "Товарища опросили, уточнили, почему он прыгнул в Обводный."
        character "И что же он ответил?"
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "«Не знаю что нашло. Русалки к себе позвали»"
        tmrz "С тех пор и говорят о колдуне и русалках, которые витают над водами Обводного канала."
        hide g2 with dissolve
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Какая… пугающая легенда."
        tmrz "Будь осторожна. Призраки становятся сильнее, так как времени остается все меньше. Придется снова пройти через рынок, он уже успел поменяться, оказавшись в новой точке временной петли."
        "[player_name] посмотрела в сторону рынка."
        hide g5 with dissolve
        hide t1 with dissolve
        # кат - сцена
        scene 2back11 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=5.0, hard=True)
        scene 2back10 with fade:
            size (1280, 720)
            fit "fill"
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Да, больше нет палаток и лавочек…. Выглядит современнее."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Нужно спешить, пока мы не попали в худший период его существования."
        character "Тогда вперед! Я уже хочу скорее расправиться со всеми этими призракам!"
        tmrz "Отличный настрой, мой друг!"
        hide t1 with dissolve
        hide g1 with dissolve
        jump scene37

# 4 серия
label scene37:
    window hide
    with None
    # кат - сцена
    scene seria4 with fade:
        size (1280, 720)
        fit "fill"
    $ renpy.pause(delay=4.0, hard=True)
    scene 3back1 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music calmness fadein 2.0 loop if_changed
    if gender == "M":
        "Снова вокруг Обводного собирался туман. Словно и не было этих ярких красок заката после победы над русалкой."
        "Чем ближе [player_name] и Климент Аркадьевич подходили к рынку, тем сильнее их окутывал густой и безжалостный морок."
        "С разных сторон раздавались голоса.  Сложно было понять, о чем идет речь, но где-то словно кто-то плакал и звал на помощь, где-то кто-то  очень злобно ругался. К голосам добавлялись тени, которые мелькали то тут, то там."
        "В какой-то момент все заволокло туманом так, что казалось, будто путники потерялись. Однако, вскоре [player_name] смог увидеть перед собой то, что осталось от рынка."
        scene 3back2 with fade:
            size (1280, 720)
            fit "fill"
        "Строение было разрушено, и кое-где вокруг обломков росла крапива и колючка. Новенький рынок сменился развалинами."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Мы же не так долго шли…  Прошло всего лишь около пяти минут, как мы видели крытые, вполне ухоженные постройки. Как такое возможно?"
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Время…"
        character "Знаю-знаю! Время здесь течет нелинейно и быстро."
        "На самом деле, быстро меняющиеся эпохи пугали даже больше, чем местные призраки."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Не щетинься, как кактус. Пора бы уже принять действительность."
        hide m1 with dissolve
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Принять-то я принял, но я даже не успеваю понять, в какой временной промежуток, эпоху попадаю."
        tmrz "Это не важно, мой друг, у нас есть проблемы серьезнее."
        hide m6 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А?"
        "Проследив за взглядом Тимирязева, [player_name] обернулся назад."
        show ghost_piyanica:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterpiyanica "..."
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Если справишься, расскажу тебе про полезные свойства крапивы!"
        hide m1 with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ну, спасибо! Ради этого стоит бороться! Вы бы могли стать отличным спортивным тренером с такими мотивациями!"
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Сосредоточься!"
        stop music fadeout 2.0
        play music ghostWorld fadein 2.0 loop if_changed
        "Призрак выглядел не так пугающе, как те, что [player_name] встречал раньше. Однако от него исходила странная дымка, которая превращалась в щупальца."
        "Пьяница выглядел неустойчивым, покачивался из стороны в сторону, а его костюм был испачкан в грязи. Не было похоже на то, что он собирался нападать первым."
        hide m2 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Может быть, он нас просто пропустит?"
        tmrz "Даже если и так, то возможно мы упустим что-то важное…"
        hide m1 with dissolve
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Нам все равно нужно спешить."
        tmrz "Решать тебе…"
        hide m5 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я…"
        hide m1 with dissolve
        hide t1 with dissolve
        hide ghost_piyanica with dissolve
        menu:
            "Предлагаю обойти призрака и не связываться с ним":
                "+ Призрак"
                $ ghost += 1
                show m1:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Я все же обойду его…"
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Дело твое."
                "+ Призрак. Вы не стали сражаться с призраком, это будет иметь последствия."
                $ ghost += 1
                hide t1 with dissolve
                hide m1 with dissolve
                "Осторожно, стараясь не привлекать внимания, [player_name] держался ближе к зарослям, которые позволяли оставаться незамеченным."
                "Хотя такой меры безопасности было более чем достаточно, ведь призрак был слишком пьян, чтобы заметить [player_name]."
                "[player_name] остановился посреди улицы Лейхтенбергской и с ужасом осознал, что не знает, куда идти дальше, ведь подсказки у него нет."
                if reality > 0:
                    $ reality -= 1
                    "Благодаря прошлому выбору вы упустили кусочек мозаики и не знаете, куда стоит идти дальше.  – Явь"
                else:
                    "Благодаря прошлому выбору вы упустили кусочек мозаики и не знаете, куда стоит идти дальше."
                show t2:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Зря, мой друг, ты испугался, мы потеряли важную подсказку. Я попробую тебе помочь сам, но в качестве аванса. Если пообещаешь, что больше не струсишь."
                show m6:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Обещаю, Климент Аркадьевич."
                "В следующем выборе вы можете выбрать любую локацию, неправильного варианта нет."
                hide m6 with dissolve
                hide t2 with dissolve
                label scene37_2_m_1: 
                    menu:
                        tmrz "Предлагаю отправиться…"
                        "К заводу «Красный треугольник»" if scenered == 0:
                            jump scene_red
                        "В дом владельца плиточного завода Ивана Карловича Бредаля" if scenehuse == 0:
                            jump scene_huse
                    
            "Попробую узнать, что ему нужно":
                $ attack += 1
                $ reality += 1
                "+Явь"
                show m5:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Я уже понял, что бежать от проблемы – это не решение."
                hide m5 with dissolve
                show m1:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Кто ты и что ты хочешь, призрак?"
                "Мрачная фигура шелохнулась. Пьяница глуповато улыбнулся в ответ."
                show ghost_piyanica:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpiyanica  "Добро пожаловать в Везенбергский квартал…  Эх, рыночек-рыночек… Здесь я помню… Ох… Раньше-то как жил, как мечтал. А теперь  – только тени и тоска."
                "[player_name] ничего не понимал в сбивчивой речи этого призрака."
                character "Так… попробую к этому диалогу подойти конкретнее. У тебя есть книга из библиотеки? Ты вернешь мне ее?"
                characterpiyanica "Кто ты, нарушитель моего покоя? А ну пшёл вон!"
                hide m1 with dissolve
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Я ищу выход из этого мира. Я не хотел тебя беспокоить…"
                "Что-то подсказывало, что диалог совсем не клеился, и [player_name] даже пожалел, что решил поговорить с этим чудаком. Но назад уже дороги не было."
                characterpiyanica "Я ищу выход… Звучит как какая-то песня."
                character "Ты либо помоги, либо пропусти. Я пойду дальше."
                characterpiyanica "Этот рынок был моим царством, здесь моя боль и моя сила... Ты хочешь пройти — борись со мной!"
                "Не дождавшись ответа, пьяница встал в нелепую боевую стойку. Пошатываясь, он направился вперед."
                hide m2 with dissolve
                hide ghost_piyanica with dissolve
                label scene37_0_m:
                    $ return_label = "scene37_0_timeout_m"  # Куда перейти при тайм-ауте
                    show screen choice_timer(5)             # Таймер на 5 секунды
                    menu:
                        "Замах бутылкой"
                        "Замереть":
                            hide screen choice_timer
                            "Призрак замахнулся бутылкой, но его положение было на столько неустойчиво, что он упал вместе с ней вперед. [player_name] не успел среагировать, призрак свалился прямо на него."
                            if rightornot == 0:
                                $ ghost += 1
                                $ rightornot += 1
                                "+ Призрак, попробуйте еще раз."
                            else:
                                "Попробуйте еще раз."
                            jump scene37_0_m
                        "Присесть":
                            hide screen choice_timer
                            "Призрак замахнулся бутылкой, [player_name] присел, чтобы избежать столкновения, однако это только ухудшило ситуацию. Споткнувшись об него, призрак с грохотом упал сверху."
                            if rightornot == 0:
                                $ ghost += 1
                                $ rightornot += 1
                                "+ Призрак, попробуйте еще раз."
                            else:
                                "Попробуйте еще раз."
                            jump scene37_0_m
                        "Увернуться":
                            hide screen choice_timer
                            "[player_name] резко отошел в сторону и призрак пролетел мимо."
                            if rightornot == 0:
                                $ reality += 1
                                $ rightornot += 1
                                "+Явь!"
                            show ghost_piyanica:
                                zoom 1.0 xalign 0.7 yalign 1.0
                                alpha 0.0
                                easein 0.3 alpha 1.0
                            characterpiyanica "Ах ты!!!! Хитер! Но я знаю технику карате!"
                            "Призрак двинулся вперед, но его все время уносило в сторону. Он попробовал замахнуться рукой справа."
                            $ rightornot = 0
                            hide ghost_piyanica with dissolve
                            jump scene37_1_m

                label scene37_0_timeout_m:
                    hide screen choice_timer
                    "Призрак замахнулся бутылкой, но его положение было на столько неустойчиво, что он упал вместе с ней вперед. [player_name] не успел среагировать, призрак свалился прямо на него."
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "+ Призрак, попробуйте еще раз."
                    else:
                        "Попробуйте еще раз."
                    jump scene37_0_m
                label scene37_1_m:
                    $ return_label = "scene37_1_timeout_m"  # Куда перейти при тайм-ауте
                    show screen choice_timer(5)             # Таймер на 5 секунды
                    menu:
                        "Уклониться вправо":
                            hide screen choice_timer
                            if rightornot == 0:
                                $ reality += 1
                                $ rightornot += 1
                                "[player_name] резко отошел в сторону, и призрак пролетел мимо. +Явь"
                            else:
                                "[player_name] резко отошел в сторону, и призрак пролетел мимо."
                            $ rightornot = 0
                            jump scene37_1_m_1
                        "Присесть":
                            hide screen choice_timer
                            "[player_name] присел, чтобы избежать столкновения, однако это только ухудшило ситуацию. Споткнувшись об него, призрак с грохотом упал сверху."
                            if rightornot == 0:
                                $ ghost += 1
                                $ rightornot += 1
                                "+ Призрак, попробуйте еще раз."
                            else:
                                "Попробуйте еще раз."
                            jump scene37_1_m
                        "Уклониться влево":
                            hide screen choice_timer
                            "[player_name] попал прямо на летящий в него кулак."
                            if rightornot == 0:
                                $ ghost += 1
                                $ rightornot += 1
                                "+ Призрак, попробуйте еще раз."
                            else:
                                "Попробуйте еще раз."
                            jump scene37_1_m
                label scene37_1_timeout_m:
                    hide screen choice_timer
                    "[player_name] присел, чтобы избежать столкновения, однако это только ухудшило ситуацию. Споткнувшись об него, призрак с грохотом упал сверху."
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "+ Призрак, попробуйте еще раз."
                    else:
                        "Попробуйте еще раз."
                    jump scene37_1_m
                label scene37_1_m_1:
                show ghost_piyanica:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpiyanica "Ну все! Ты меня достал!!!"
                "Едва ли не завалившись на спину, призрак попытался разбежаться, а затем, наклонившись и направив свою голову вперед, побежал."
                "В момент, когда столкновения уже практически невозможно было бы избежать,  [player_name] отошел в сторону."
                "Призрак пьяницы пронесся мимо, оставалось только проводить беднягу взглядом."
                "Не рассчитав своих сил, бедняга побежал к Обводному каналу, следом послышался всплеск. Издалека донесся голос призрака «Ах ты хитрец»."
                hide ghost_piyanica with dissolve
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Молодец, мой друг. Славный бой."
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Вы смеетесь, Климент Аркадьевич? Я ничего не делал, этот сумасшедший призрак все сделал сам."
                tmrz "Иногда отсутствие действия – это тоже действие. Не принижай своих заслуг. Лучше посмотри, что этот призрак обронил."
                character "И правда!"
                "В траве лежала небрежно брошенная книга."
                show promish with fade:
                    zoom 1.0 xalign 0 yalign 0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                $ book_promish += 1
                "Вы нашли новую книгу."
                hide promish with dissolve
                hide m2 with dissolve
                show m5:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Так… Промышленная архитектура. Здесь довольно много зданий, которые подойдут."
                tmrz "Давай посмотрим в карту."
                "Благодаря прошлым выборам, ты сам отлично ориентируешься в Везенбергском квартале. + Явь"
                $ reality += 1
                hide m5 with dissolve
                show m1:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Так, можно отправиться на Завод «Красный треугольник» или в дом владельца плиточного завода."
                hide t1 with dissolve
                show t2:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "За твою смелость, я сделаю тебе подсказку и лично от меня."
                "Далее вы можете выбрать любую локацию, неправильного варианта нет. Так как вы нашли подсказку, вы можете посетить все локации по очереди."
                hide m1 with dissolve
                hide t2 with dissolve
                label scene37_2_m_2:
                    menu:
                        tmrz "Предлагаю отправиться…"
                        "К заводу «Красный треугольник»" if scenered == 0:
                            jump scene_red
                        "В дом владельца плиточного завода Ивана Карловича Бредаля" if scenehuse == 0:
                            jump scene_huse
                        "В филиал Обуховской больницы" if scenemedic == 0:
                            jump scene_medic
                        "В фотостудию Н.Ф. Агафонова" if scenepht == 0:
                            jump scene_pht
                        "Мы исследовали все, пора двигаться дальше" if sceneised == 0 and seria4vibr < 4:
                            jump scene_ised
        jump scene38
    elif gender == "G":
        "Снова вокруг Обводного собирался туман. Словно и не было этих ярких красок заката после победы над русалкой."
        "Чем ближе [player_name] и Климент Аркадьевич подходили к рынку, тем сильнее их окутывал густой и безжалостный морок."
        "С разных сторон раздавались голоса.  Сложно было понять, о чем идет речь, но где-то словно кто-то плакал и звал на помощь, где-то кто-то  очень злобно ругался. К голосам добавлялись тени, которые мелькали то тут, то там."
        "В какой-то момент все заволокло туманом так, что казалось, будто путники потерялись. Однако, вскоре [player_name] смогла увидеть перед собой то, что осталось от рынка."
        scene 3back2 with fade:
            size (1280, 720)
            fit "fill"
        "Строение было разрушено, и кое-где вокруг обломков росла крапива и колючка. Новенький рынок сменился развалинами."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Мы же не так долго шли…  Прошло всего лишь около пяти минут, как мы видели крытые, вполне ухоженные постройки. Как такое возможно?"
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Время…"
        character "Знаю-знаю! Время здесь течет нелинейно и быстро."
        "На самом деле, быстро меняющиеся эпохи пугали даже больше, чем местные призраки."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Не щетинься, как кактус. Пора бы уже принять действительность."
        hide g1 with dissolve
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Принять-то я приняла, но я даже не успеваю понять, в какой временной промежуток, эпоху попадаю."
        tmrz "Это не важно, мой друг, у нас есть проблемы серьезнее."
        hide g6 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А?"
        "Проследив за взглядом Тимирязева, [player_name] обернулась назад."
        show ghost_piyanica:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterpiyanica "..."
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Если справишься, расскажу тебе про полезные свойства крапивы!"
        hide g1 with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ну, спасибо! Ради этого стоит бороться! Вы бы могли стать отличным спортивным тренером с такими мотивациями!"
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Сосредоточься!"
        stop music fadeout 2.0
        play music ghostWorld fadein 2.0 loop if_changed
        "Призрак выглядел не так пугающе, как те, что [player_name] встречала раньше. Однако от него исходила странная дымка, которая превращалась в щупальца."
        "Пьяница выглядел неустойчивым, покачивался из стороны в сторону, а его костюм был испачкан в грязи. Не было похоже на то, что он собирался нападать первым."
        hide g2 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Может быть, он нас просто пропустит?"
        tmrz "Даже если и так, то возможно мы упустим что-то важное…"
        hide g1 with dissolve
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Нам все равно нужно спешить."
        tmrz "Решать тебе…"
        hide g5 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я…"
        hide g1 with dissolve
        hide t1 with dissolve
        hide ghost_piyanica with dissolve
        menu:
            "Предлагаю обойти призрака и не связываться с ним":
                "+ Призрак"
                $ ghost += 1
                show g1:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Я все же обойду его…"
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Дело твое."
                "+ Призрак. Вы не стали сражаться с призраком, это будет иметь последствия."
                $ ghost += 1
                hide t1 with dissolve
                hide g1 with dissolve
                "Осторожно, стараясь не привлекать внимания, [player_name] держалась ближе к зарослям, которые позволяли оставаться незамеченным."
                "Хотя, такой меры безопасности было более чем достаточно, ведь призрак был слишком пьян, чтобы заметить [player_name]."
                "[player_name] остановилась посреди улицы Лейхтенбергской и с ужасом осознала, что не знает, куда идти дальше, ведь подсказки у нее нет."
                if reality > 0:
                    $ reality -= 1
                    "Благодаря прошлому выбору вы упустили кусочек мозаики и не знаете, куда стоит идти дальше.  – Явь"
                else:
                    "Благодаря прошлому выбору вы упустили кусочек мозаики и не знаете, куда стоит идти дальше."
                $ reality -= 1
                show t2:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Зря, мой друг, ты испугалась, мы потеряли важную подсказку. Я попробую тебе помочь сам, но в качестве аванса. Если пообещаешь, что больше не струсишь."
                show g6:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Обещаю, Климент Аркадьевич."
                "В следующем выборе вы можете выбрать любую локацию, неправильного варианта нет."
                hide g6 with dissolve
                hide t2 with dissolve
                label scene37_2_g_1:
                    menu:
                        tmrz "Предлагаю отправиться…"
                        "К заводу «Красный треугольник»" if scenered == 0:
                            jump scene_red
                        "В дом владельца плиточного завода Ивана Карловича Бредаля" if scenehuse == 0:
                            jump scene_huse
            "Попробую узнать, что ему нужно":
                $ attack += 1
                $ reality += 1
                "+Явь"
                show g5:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Я уже поняла, что бежать от проблемы – это не решение."
                hide g5 with dissolve
                show g1:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Кто ты и что ты хочешь, призрак?"
                "Мрачная фигура шелохнулась. Пьяница глуповато улыбнулся в ответ."
                show ghost_piyanica:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpiyanica  "Добро пожаловать в Везенбергский квартал…  Эх, рыночек-рыночек… Здесь я помню… Ох… Раньше-то как жил, как мечтал. А теперь  – только тени и тоска."
                "[player_name] ничего не понимала в сбивчивой речи этого призрака."
                character "Так… попробую к этому диалогу подойти конкретнее. У тебя есть книга из библиотеки? Ты вернешь мне ее?"
                characterpiyanica "Кто ты, нарушитель моего покоя? А ну пшла вон!"
                hide g1 with dissolve
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Я ищу выход из этого мира. Я не хотела тебя беспокоить…"
                "Что-то подсказывало, что диалог совсем не клеился, и [player_name] даже пожалела, что решила поговорить с этим чудаком. Но назад уже дороги не было."
                characterpiyanica "Я ищу выход… Звучит как какая-то песня."
                character "Ты либо помоги, либо пропусти. Я пойду дальше."
                characterpiyanica "Этот рынок был моим царством, здесь моя боль и моя сила... Ты хочешь пройти — борись со мной!"
                "Не дождавшись ответа, пьяница встал в нелепую боевую стойку. Пошатываясь, он направился вперед."
                hide g2 with dissolve
                hide ghost_piyanica with dissolve
                label scene37_0_g:
                    $ return_label = "scene37_0_timeout_g"  # Куда перейти при тайм-ауте
                    show screen choice_timer(5)             # Таймер на 5 секунды
                    menu:
                        "Замах бутылкой"
                        "Замереть":
                            hide screen choice_timer
                            "Призрак замахнулся бутылкой, но его положение было настолько неустойчиво, что он упал вместе с ней вперед. [player_name] не успела среагировать, призрак свалился прямо на нее."
                            if rightornot == 0:
                                $ ghost += 1
                                $ rightornot += 1
                                "+ Призрак, попробуйте еще раз."
                            else:
                                "Попробуйте еще раз."
                            jump scene37_0_g
                        "Присесть":
                            hide screen choice_timer
                            "Призрак замахнулся бутылкой, [player_name] присела, чтобы избежать столкновения, однако это только ухудшило ситуацию. Споткнувшись об нее, призрак с грохотом упал сверху."
                            if rightornot == 0:
                                $ ghost += 1
                                $ rightornot += 1
                                "+ Призрак, попробуйте еще раз."
                            else:
                                "Попробуйте еще раз."
                            jump scene37_0_g
                        "Увернуться":
                            hide screen choice_timer
                            "[player_name] резко отошла в сторону, и призрак пролетел мимо."
                            if rightornot == 0:
                                $ reality += 1
                                $ rightornot += 1
                                "+Явь!"
                            show ghost_piyanica:
                                zoom 1.0 xalign 0.7 yalign 1.0
                                alpha 0.0
                                easein 0.3 alpha 1.0
                            characterpiyanica "Ах ты!!!! Хитра! Но я знаю технику карате!"
                            "Призрак двинулся вперед, но его все время уносило в сторону. Он попробовал замахнуться рукой справа."
                            $ rightornot = 0
                            hide ghost_piyanica with dissolve
                            jump scene37_1_g

                label scene37_0_timeout_g:
                    hide screen choice_timer
                    "Призрак замахнулся бутылкой, но его положение было настолько неустойчиво, что он упал вместе с ней вперед. [player_name] не успела среагировать, призрак свалился прямо на нее."
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "+ Призрак, попробуйте еще раз."
                    else:
                        "Попробуйте еще раз."
                    jump scene37_0_g
                label scene37_1_g:
                    $ return_label = "scene37_1_timeout_g"  # Куда перейти при тайм-ауте
                    show screen choice_timer(5)             # Таймер на 5 секунды
                    menu:
                        "Уклониться вправо":
                            hide screen choice_timer
                            if rightornot == 0:
                                $ reality += 1
                                $ rightornot += 1
                                "[player_name] резко отошла в сторону, и призрак пролетел мимо. +Явь"
                            else:
                                "[player_name] резко отошла в сторону, и призрак пролетел мимо."
                            $ rightornot = 0
                            jump scene37_1_g_1
                        "Присесть":
                            hide screen choice_timer
                            "[player_name] присела, чтобы избежать столкновения, однако это только ухудшило ситуацию. Споткнувшись об нее, призрак с грохотом упал сверху."
                            if rightornot == 0:
                                $ ghost += 1
                                $ rightornot += 1
                                "+ Призрак, попробуйте еще раз."
                            else:
                                "Попробуйте еще раз."
                            jump scene37_1_g
                        "Уклониться влево":
                            hide screen choice_timer
                            "[player_name] попала прямо на летящий в нее кулак."
                            if rightornot == 0:
                                $ ghost += 1
                                $ rightornot += 1
                                "+ Призрак, попробуйте еще раз."
                            else:
                                "Попробуйте еще раз."
                            jump scene37_1_g
                label scene37_1_timeout_g:
                    hide screen choice_timer
                    "[player_name] присела, чтобы избежать столкновения, однако это только ухудшило ситуацию. Споткнувшись об нее, призрак с грохотом упал сверху."
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "+ Призрак, попробуйте еще раз."
                    else:
                        "Попробуйте еще раз."
                    jump scene37_1_g
                label scene37_1_g_1:
                show ghost_piyanica:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpiyanica "Ну все! Ты меня достала!!!"
                "Едва ли не завалившись на спину, призрак попытался разбежаться, а затем, наклонившись и направив свою голову вперед, побежал."
                "В момент, когда столкновения уже практически не возможно было бы избежать,  [player_name] отошла в сторону. "
                "Призрак пьяницы пронесся мимо, оставалось только проводить беднягу взглядом."
                "Не рассчитав своих сил, бедняга побежал к Обводному каналу, следом послышался всплеск. Издалека донесся голос призрака «Ах ты хитрюга»."
                hide ghost_piyanica with dissolve
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Молодец, мой друг. Славный бой."
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Вы смеетесь, Климент Аркадьевич? Я ничего не делала, этот сумасшедший призрак все сделал сам."
                tmrz "Иногда отсутствие действия – это тоже действие. Не принижай своих заслуг. Лучше посмотри, что этот призрак обронил."
                character "И правда!"
                "В траве лежала небрежно брошенная книга."
                show promish with fade:
                    zoom 1.0 xalign 0 yalign 0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                $ book_promish += 1
                "Вы нашли новую книгу."
                hide promish with dissolve
                hide g2 with dissolve
                show g5:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Так… Промышленная архитектура. Здесь довольно много зданий, которые подойдут."
                tmrz "Давай посмотрим в карту."
                "Благодаря прошлым выборам, ты сама отлично ориентируешься в Везенбергском квартале. + Явь"
                $ reality += 1
                hide g5 with dissolve
                show g1:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Так, можно отправиться на Завод «Красный треугольник» или в дом владельца плиточного завода."
                hide t1 with dissolve
                show t2:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "За твою смелость, я сделаю тебе подсказку и лично от меня."
                "Далее вы можете выбрать любую локацию, неправильного варианта нет. Так как вы нашли подсказку, вы можете посетить все локации по очереди."
                hide g1 with dissolve
                hide t2 with dissolve
                label scene37_2_g_2:
                    menu:
                        tmrz "Предлагаю отправиться…"
                        "К заводу «Красный треугольник»" if scenered == 0:
                            jump scene_red
                        "В дом владельца плиточного завода Ивана Карловича Бредаля" if scenehuse == 0:
                            jump scene_huse
                        "В филиал Обуховской больницы" if scenemedic == 0:
                            jump scene_medic
                        "В фотостудию Н.Ф. Агафонова" if scenepht == 0:
                            jump scene_pht
                        "Мы исследовали все, пора двигаться дальше" if sceneised == 0 and seria4vibr < 4:
                            jump scene_ised
        jump scene38

# К заводу «Красный треугольник»
label scene_red:
    $ seria4vibr += 1
    $ scenered += 1
    $ vstret_rab += 1
    scene 3back3 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music factory fadein 2.0 loop if_changed

    $ seria4vibr += 1
    $ scenehuse += 1
    scene 3back7 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music ball fadein 2.0 loop if_changed
    if gender == "M":
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Мой друг, что ты знаешь о заводе «Красный Треугольник»?"
        if architect == 1:
            "Вы выбрали учиться на архитектора и расскажете про архитектуру «Красного треугольника»."
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Большая часть исторических построек завода выполнена в характерном для промышленной архитектуры конца XIX — начала XX века стиле из неоштукатуренного красного кирпича."
            character "Это практически небольшой заводской город с внутренними улицами, трубами, металлическими лестницами, переходами."
            hide m2 with dissolve
        elif archaeologist == 1:
            "Вы выбрали учиться на археолога и расскажете про историю «Красного треугольника»."
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Гамбургский предприниматель Фердинанд Краузкопф в середине XIX века  успешно занимался продажей галош в Европе. Затем, решил наладить производство резиновой обуви и в России."
            character "В 1859 году он и его компаньоны учредили «Товарищество российско-американской резиновой мануфактуры» и открыли «Фабрику галош и других резиновых и гуттаперчевых изделий в Санкт-Петербурге» на Обводном канале."
            hide m2 with dissolve
        elif journalist == 1:
            "Вы выбрали учиться на журналиста и расскажете про современную жизнь «Красного треугольника»."
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Это самая знаменитая и масштабная заброшка нашего города. 3 февраля 2023 года 50 корпусов и 11 галерей комплекса были признаны объектами культурного наследия регионального значения."
            hide m2 with dissolve
        elif botanist == 1:
            "Вы выбрали учиться на ботаника и знаете о «Красном треугольнике» пока совсем немного. Но Тимирязев вам, как коллеге, расскажет несколько фактов о нем."
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Знаю, что здесь производили резиновые галоши и шины."
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Верно. Большая часть этих  исторических построек завода выполнена из неоштукатуренного красного кирпича. Он был очень масштабным с большим количеством корпусов."
            tmrz "Гамбургский предприниматель Фердинанд Краузкопф увидел большой потенциал для резиновой обуви на российском рынке и открыл завод, который изначально назывался просто «Треугольник», а после революции он стал красным."
            hide t1 with dissolve
            hide m2 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что мы здесь ищем?"
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Приключения, мой друг!"
        menu:
            character ""
            "Ну уж нет, ими я уже сыт по горло":
                "+ Призрак"
                $ ghost += 1
            "Что ж, надеюсь, мы найдем следующие подсказки!":
                "+ Явь"
                $ reality += 1
        hide t2 with dissolve
        hide m1 with dissolve
        scene 3back4 with fade:
            size (1280, 720)
            fit "fill"
        "На удивление, на заводе было шумно, словно рабочая жизнь никогда не уходила из этих мест. Вокруг было очень много женщин, увлеченно занимающихся своим делом."
        "Если бы фигуры этих людей не были прозрачными, нельзя было бы догадаться, что это призраки. С таким увлечением и энтузиазмом эти туманные фигуры были заняты своим ремеслом."
        show ghost_wrkshe:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterwrkshe "Эй вы! Что вы здесь делаете!"
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А я…"
        "[player_name] растерялся. Что говорить? «Я пришел вас побеждать, чтоб книжечки искать» - подойдет?"
        "Климент Аркадьевич, как назло, тоже молчал. Видимо растерялся от напора этой женщины."
        characterwrkshe "А ну прочь, бездельники! Это закрытая территория! Нечего секреты производства разведывать!"
        characterVoiswrk "Галя! Да это ж путешественник во времени и Тимирязев. Они с призраками борются."
        "Галя тут же переменилась в лице, еще раз посмотрела на Тимирязева и схватилась за сердце."
        characterwrkshe "Батюшки! Климент Аркадьевич, не признала! Богатым будете."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Будет тебе, Галина. С каждым может случиться.  Лучше подскажи нам, не брал ли кто из ваших книги библиотечные? Не завалялись ли они тут?"
        characterwrkshe "Да что вы, Климент Аркадьевич. Нашим и читать-то некогда, но даже если б и взяли, то как порядочные советские люди вернули бы в срок. Хулиганов среди нас нет."
        tmrz "Неужели мы ошиблись и здесь нам делать нечего…"
        "[player_name] задумался. Похоже Галина не знала, что она и сама призрак, и все ее подруги-работницы. Все выглядело так, словно мы их невольно оторвали от работы."
        hide m7 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А есть ли у вас легенды о каких-нибудь призраках?"
        "Галина словно помрачнела, и ее и так грозный вид стал еще более суровым."
        characterwrkshe "Да есть тут один…. Ходит-бродит, людей пугает."
        tmrz "Галенька, дорогая наша орхидея в этом темном призрачном царстве, будьте так добры, подскажите, как его найти."
        "Галя слегка засмущалась, на секунду даже растеряв свою строгость. Но затем взяла себя в руки."
        characterwrkshe "А его и не надо искать специально. Нужно взять галошу и протереть ее тряпочкой до скрипа. Этот призрак жутко не любит этот звук. Сам на вас выйдет. Только разбирайтесь с ним сами. Я же пойду работать."
        "Тимирязев и [player_name] быстро поблагодарили Галину и подошли к стеллажу с галошами."
        hide m1 with dissolve
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Какую выбрать…"
        hide m5 with dissolve
        hide t1 with dissolve
        hide ghost_wrkshe with dissolve
        label scene_red_0_m:
            menu:
                "Синюю":
                    "Не верно, попробуйте еще раз."
                    $ rightornot += 1
                    jump scene_red_0_m
                "Зеленую":
                    "Не верно, попробуйте еще раз."
                    $ rightornot += 1
                    jump scene_red_0_m
                "Черную с красной подкладкой":
                    if rightornot == 0:
                        $ reality += 1
                        $ rightornot += 1
                        "Верно. + Явь "
                    else:
                        "Верно."
                    $ rightornot = 0
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Именно такими галошами известен «Красный треугольник»."
        "Взяв на столе тряпку, [player_name] стал протирать до блеска галошу."
        stop music fadeout 2.0
        play music office fadein 2.0 loop if_changed
        show ghost_wrker:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterwrker  "ОПЯТЬ ЭТОТ МЕРЗКИЙ ЗВУК! Ненавижу эту резину! И так все пропахло ей! Я сам весь пропах этой резиной! Неужели нельзя хотя бы соблюдать тишину!"
        hide m2 with dissolve
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "…"
        hide m7 with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А чужие книжки воровать, значит, хорошо? Никто никому бы не мешал, если бы вы не пытались уничтожить мой мир!"
        character "Я бы сейчас пошел бы домой, заварил бы чай, включил бы кино и отдыхал бы. А я тут вас отлавливаю то в Российской империи, то в Советском союзе, то в языческих племенах. Оно мне надо?"
        "Призрак удивленно замер и прислушался."
        character "Я просто книжку хотел сдать! А ну хватит меня запугивать!"
        "Призрак испуганно попятился назад. Климент Аркадьевич с удивлением смотрел за разворачивающимся действом."
        hide m2 with dissolve
        hide ghost_wrker with dissolve
        label scene_red_1_m:
            menu:
                character "Ты даже…"
                "Не мог здесь работать":
                    if rightornot == 0:
                        $ reality += 1
                        $ rightornot += 1
                        "Верный вариант. + Явь "
                    else:
                        "Верный вариант."
                    $ rightornot = 0
                "В дурацкой шляпе":
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Не верный вариант. + Призрак "
                    else:
                        "Не верный вариант."
                    show t1:   
                        zoom 1.0 xalign 1.3 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    tmrz "Зачем ты его так оскорбляешь?"
                    show m6:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Простите. Видимо это усталость."
                    "Попробуйте еще раз."
                    hide m6 with dissolve
                    hide t1 with dissolve
                    jump scene_red_1_m
                "Не гражданин":
                    show m6:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Что за бред? О чем я?"
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Не верный вариант. + Призрак "
                    else:
                        "Не верный вариант."
                    "Попробуйте еще раз."
                    hide m6 with dissolve
                    jump scene_red_1_m
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "На заводе использовали в основном женский труд, откуда здесь взялся рабочий? Кто ты такой?!"
        hide m2 with dissolve
        stop music fadeout 2.0
        play music factory fadein 2.0 loop if_changed
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что за пила у тебя в руках? Что ты вообще собрался здесь пилить? Галоши?!"
        show ghost_wrker:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterwrker "Да с чего ты вообще на меня так нападаешь? Я еще ничего плохого тебе не сделал!"
        hide m2 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Знаю я вас!"
        "Тимирязев добродушно усмехнулся."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Смотрю, мой друг, ты уже осваиваешься среди призраков.  Уже опережаешь их действия."
        character "Я быстро учусь."
        hide m1 with dissolve
        if seria4vibr > 1 and book_rest > 0:
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Тогда просто дайте нам пройти, а сами ступайте по своим делам."
            "Было сложно понять, какие эмоции испытывает призрак, но казалось, что он слегка обескуражен и сконфужен."
            characterwrker "Я не могу просто так вас отпустить. Меня все призраки квартала засмеют. Сначала ты должен угадать: Я действительно здесь существовал или я часть легенды, придуманной людьми."
            character "Опять загадки…"
            character "Я думаю, что…"
            hide m2
            hide t1
            hide ghost_wrker
            with dissolve
            menu:
                "Ты действительно был когда-то на «Красном треугольнике»":
                    $ ghost += 1
                    "+Призрак"
                    show ghost_wrker:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterwrker "А вот и нет! Не заслужил ты книгу, уж извини!"
                    "Вам стоит доверять себе и своим наблюдениям!"
                    hide ghost_wrker with dissolve
                "Легенду о тебе придумали люди":
                    show m1:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Слишком многое не сходится… Я думаю, что ты не отсюда."
                    show ghost_wrker:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterwrker "Что ж…"
                    characterwrker "Видимо тебя не так просто обмануть."
                    $ reality += 1
                    "+Явь" 
        elif seria4vibr == 1:
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "А теперь просто отдай нам с Климентом Аркадьевичем книгу и ступай по своим делам."
            "Было сложно понять, какие эмоции испытывает призрак, но казалось, что он слегка обескуражен и сконфужен."
            characterwrker "Я не могу просто так вам подарить книгу. Меня все призраки квартала засмеют. Сначала ты должен угадать: Я действительно существовал здесь или я часть легенды, придуманной людьми."
            character "Опять загадки…"
            character "Я думаю, что…"
            hide m2
            hide t1
            hide ghost_wrker
            with dissolve
            menu:
                "Ты действительно был когда-то на «Красном треугольнике»":
                    $ ghost += 1
                    "+Призрак"
                    show ghost_wrker:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterwrker "А вот и нет! Не заслужил ты книгу, уж извини!"
                    "Вам стоит доверять себе и своим наблюдениям!"
                    hide ghost_wrker with dissolve
                "Легенду о тебе придумали люди":
                    show m1:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Слишком многое не сходится… Я думаю, что ты не отсюда."
                    show ghost_wrker:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterwrker "Что ж…"
                    characterwrker "Видимо тебя не так просто обмануть."
                    $ reality += 1
                    "+Явь" 
                    $ book_rest += 1
                    $ reality += 1
                    hide ghost_wrker with dissolve
                    show rest with fade:
                        zoom 1.0 xalign 0 yalign 0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    $ sceneredbook += 1
                    "Вы нашли еще одну книгу! +Явь"
        hide rest
        hide m1
        with dissolve
        show ghost_wrker:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        "Призрака окутал туман, и [player_name] приготовился к нападению. Однако, когда дымка рассеялась, рабочий изменился."
        hide ghost_wrker with dissolve
        show ghost_wrkhe:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterwrkhe "Знаешь, уже долгое время я здесь пугаю ребятишек, которые залезают в заброшенные корпуса, чтобы неповадно было сюда заходить."
        characterwrkhe "Я вообще не злой на самом деле. Меня родители сорванцов придумали, чтобы их пугать, и они меньше ходили по заброшенным зданиям."
        characterwrkhe "Правда, эффект это имело обратный. Всем детям еще больше хотелось на призрака посмотреть."
        "[player_name] почувствовал себя неловко.  Призрак оказался совсем незлой, даже в некоторой степени благородный.  Не стоило на него так нападать."
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Прости, что был слишком резким."
        characterwrkhe "Я не могу тебя осуждать. Тебе со многим пришлось здесь столкнуться."
        characterwrkhe "Я не только не злюсь, но и предлагаю помощь."
        character "Какую?"
        characterwrkhe "Узнаешь позже…"
        hide ghost_wrkhe with dissolve
        "С этими словами призрак растворился."
        hide m6 with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "И все же… Они со своими фокусами и тайнами жутко раздражают…"
        hide m2 with dissolve
        if attack == 1:
            jump scene37_2_m_2
        else:
            jump scene37_2_m_1
        jump scene38
    elif gender == "G":
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Мой друг, что ты знаешь о заводе «Красный Треугольник»?"
        if architect == 1:
            "Вы выбрали учиться на архитектора и расскажете про архитектуру «Красного треугольника»."
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Большая часть исторических построек завода выполнена в характерном для промышленной архитектуры конца XIX — начала XX века стиле из неоштукатуренного красного кирпича."
            character "Это практически небольшой заводской город с внутренними улицами, трубами, металлическими лестницами, переходами."
            hide g2 with dissolve
        elif archaeologist == 1:
            "Вы выбрали учиться на археолога и расскажете про историю «Красного треугольника»."
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Гамбургский предприниматель Фердинанд Краузкопф в середине XIX века  успешно занимался продажей галош в Европе. Затем, решил наладить производство резиновой обуви и в России."
            character "В 1859 году он и его компаньоны учредили «Товарищество российско-американской резиновой мануфактуры» и открыли «Фабрику галош и других резиновых и гуттаперчевых изделий в Санкт-Петербурге» на Обводном канале."
            hide g2 with dissolve
        elif journalist == 1:
            "Вы выбрали учиться на журналиста и расскажете про современную жизнь «Красного треугольника»."
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Это самая знаменитая и масштабная заброшка нашего города. 3 февраля 2023 года 50 корпусов и 11 галерей комплекса были признаны объектами культурного наследия регионального значения."
            hide g2 with dissolve
        elif botanist == 1:
            "Вы выбрали учиться на ботаника и знаете о «Красном треугольнике» пока совсем немного. Но Тимирязев вам, как коллеге, расскажет несколько фактов о нем."
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Знаю, что здесь производили резиновые галоши и шины."
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Верно. Большая часть этих  исторических построек завода выполнена из неоштукатуренного красного кирпича. Он был очень масштабным с большим количеством корпусов."
            tmrz "Гамбургский предприниматель Фердинанд Краузкопф увидел большой потенциал для резиновой обуви на российском рынке и открыл завод, который изначально назывался просто «Треугольник», а после революции он стал красным."
            hide t1 with dissolve
            hide g2 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что мы здесь ищем?"
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Приключения, мой друг!"
        menu:
            character ""
            "Ну уж нет, ими я уже сыта по горло":
                "+ Призрак"
                $ ghost += 1
            "Что ж, надеюсь, мы найдем следующие подсказки!":
                "+ Явь"
                $ reality += 1
        hide t2 with dissolve
        hide g1 with dissolve
        scene 3back4 with fade:
            size (1280, 720)
            fit "fill"
        "На удивление, на заводе было шумно, словно рабочая жизнь никогда не уходила из этих мест. Вокруг было очень много женщин, увлеченно занимающихся своим делом."
        "Если бы фигуры этих людей не были прозрачными, нельзя было бы догадаться, что это призраки. С таким увлечением и энтузиазмом эти туманные фигуры были заняты своим ремеслом."
        show ghost_wrkshe:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterwrkshe "Эй вы! Что вы здесь делаете!"
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А я…"
        "[player_name] растерялась. Что говорить? «Я пришла вас побеждать, чтоб книжечки искать» - подойдет?"
        "Климент Аркадьевич, как назло, тоже молчал. Видимо растерялся от напора этой женщины."
        characterwrkshe "А ну прочь, бездельники! Это закрытая территория! Нечего секреты производства разведывать!"
        characterVoiswrk "Галя! Да это ж путешественница во времени и Тимирязев. Они с призраками борются."
        "Галя тут же переменилась в лице, еще раз посмотрела на Тимирязева и схватилась за сердце."
        characterwrkshe "Батюшки! Климент Аркадьевич, не признала! Богатым будете."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Будет тебе, Галина. С каждым может случиться.  Лучше подскажи нам, не брал ли кто из ваших книги библиотечные? Не завалялись ли они тут?"
        characterwrkshe "Да что вы, Климент Аркадьевич. Нашим и читать-то некогда, но даже если б и взяли, то как порядочные советские люди вернули бы в срок. Хулиганов среди нас нет."
        tmrz "Неужели мы ошиблись и здесь нам делать нечего…"
        "[player_name] задумалась . Похоже Галина не знала, что она и сама призрак, и все ее подруги-работницы. Все выглядело так, словно мы их невольно оторвали от работы."
        hide g7 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А есть ли у вас легенды о каких-нибудь призраках?"
        "Галина словно помрачнела, и ее и так грозный вид стал еще более суровым."
        characterwrkshe "Да есть тут один…. Ходит-бродит, людей пугает."
        tmrz "Галенька, дорогая наша орхидея в этом темном призрачном царстве, будьте так добры, подскажите, как его найти."
        "Галя слегка засмущалась, на секунду даже растеряв свою строгость. Но затем взяла себя в руки."
        characterwrkshe "А его и не надо искать специально. Нужно взять галошу и протереть ее тряпочкой до скрипа. Этот призрак жутко не любит этот звук. Сам на вас выйдет. Только разбирайтесь с ним сами. Я же пойду работать."
        "Тимирязев и [player_name] быстро поблагодарили Галину и подошли к стеллажу с галошами."
        hide g1 with dissolve
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Какую выбрать…"
        hide g5 with dissolve
        hide t1 with dissolve
        hide ghost_wrkshe with dissolve
        label scene_red_0_g:
            menu:
                "Синюю":
                    "Не верно, попробуйте еще раз."
                    $ rightornot += 1
                    jump scene_red_0_g
                "Зеленую":
                    "Не верно, попробуйте еще раз."
                    $ rightornot += 1
                    jump scene_red_0_g
                "Черную с красной подкладкой":
                    if rightornot == 0:
                        $ reality += 1
                        $ rightornot += 1
                        "Верно. + Явь "
                    else:
                        "Верно."
                    $ rightornot = 0
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Именно такими галошами известен «Красный треугольник»."
        "Взяв на столе тряпку, [player_name] стала протирать до блеска галошу."
        stop music fadeout 2.0
        play music office fadein 2.0 loop if_changed
        show ghost_wrker:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterwrker "ОПЯТЬ ЭТОТ МЕРЗКИЙ ЗВУК! Ненавижу эту резину! И так все пропахло ей! Я сам весь пропах этой резиной! Неужели нельзя хотя бы соблюдать тишину!"
        hide g2 with dissolve
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "…"
        hide g7 with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А чужие книжки воровать, значит, хорошо? Никто никому бы не мешал, если бы вы не пытались уничтожить мой мир!"
        character "Я бы сейчас пошла бы домой, заварила бы чай, включила бы кино и отдыхала бы. А я тут вас отлавливаю то в Российской империи, то в Советском союзе, то в языческих племенах. Оно мне надо?"
        "Призрак удивленно замер и прислушался."
        character "Я просто книжку хотела сдать! А ну хватит меня запугивать!"
        "Призрак испуганно попятился назад. Климент Аркадьевич с удивлением смотрел за разворачивающимся действом."
        hide g2 with dissolve
        hide ghost_wrker with dissolve
        label scene_red_1_g:
            menu:
                character "Ты даже…"
                "Не мог здесь работать":
                    if rightornot == 0:
                        $ reality += 1
                        $ rightornot += 1
                        "Верный вариант. + Явь "
                    else:
                        "Верный вариант."
                    $ rightornot = 0
                "В дурацкой шляпе":
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Не верный вариант. + Призрак "
                    else:
                        "Не верный вариант."
                    show t1:   
                        zoom 1.0 xalign 1.3 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    tmrz "Зачем ты его так оскорбляешь?"
                    show g6:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Простите. Видимо это усталость."
                    "Попробуйте еще раз."
                    hide g6 with dissolve
                    hide t1 with dissolve
                    jump scene_red_1_g
                "Не гражданин":
                    show g6:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Что за бред? О чем я?"
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Не верный вариант. + Призрак "
                    else:
                        "Не верный вариант."
                    "Попробуйте еще раз."
                    hide g6 with dissolve
                    jump scene_red_1_g
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "На заводе использовали в основном женский труд, откуда здесь взялся рабочий? Кто ты такой?!"
        hide g2 with dissolve
        #########################################
        stop music fadeout 2.0
        play music factory fadein 2.0 loop if_changed
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что за пила у тебя в руках? Что ты вообще собрался здесь пилить? Галоши?!"
        show ghost_wrker:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterwrker "Да с чего ты вообще на меня так нападаешь? Я еще ничего плохого тебе не сделал!"
        hide g2 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Знаю я вас!"
        "Тимирязев добродушно усмехнулся."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Смотрю, мой друг, ты уже осваиваешься среди призраков.  Уже опережаешь их действия."
        character "Я быстро учусь."
        hide g1 with dissolve
        if seria4vibr > 1 and book_rest > 0:
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Тогда просто дайте нам пройти, а сами ступайте по своим делам."
            "Было сложно понять, какие эмоции испытывает призрак, но казалось, что он слегка обескуражен и сконфужен."
            characterwrker "Я не могу просто так вас отпустить. Меня все призраки квартала засмеют. Сначала ты должна угадать: Я действительно здесь существовал или я часть легенды, придуманной людьми."
            character "Опять загадки…"
            character "Я думаю, что…"
            hide g2
            hide t1
            hide ghost_wrker
            with dissolve
            menu:
                "Ты действительно был когда-то на «Красном треугольнике»":
                    $ ghost += 1
                    "+Призрак"
                    show ghost_wrker:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterwrker "А вот и нет! Не заслужила ты книгу, уж извини!"
                    "Вам стоит доверять себе и своим наблюдениям!"
                    hide ghost_wrker with dissolve
                "Легенду о тебе придумали люди":
                    show g1:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Слишком многое не сходится… Я думаю, что ты не отсюда."
                    show ghost_wrker:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterwrker "Что ж…"
                    characterwrker "Видимо тебя не так просто обмануть."
                    $ reality += 1
                    "+Явь" 
        elif seria4vibr == 1:
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "А теперь просто отдай нам с Климентом Аркадьевичем книгу и ступай по своим делам."
            "Было сложно понять, какие эмоции испытывает призрак, но казалось, что он слегка обескуражен и сконфужен."
            characterwrker "Я не могу просто так вам подарить книгу. Меня все призраки квартала засмеют. Сначала ты должна угадать: Я действительно существовал здесь или я часть легенды, придуманной людьми."
            character "Опять загадки…"
            character "Я думаю, что…"
            hide g2
            hide t1
            hide ghost_wrker
            with dissolve
            menu:
                "Ты действительно был когда-то на «Красном треугольнике»":
                    $ ghost += 1
                    "+Призрак"
                    show ghost_wrker:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterwrker "А вот и нет! Не заслужила ты книгу, уж извини!"
                    "Вам стоит доверять себе и своим наблюдениям!"
                    hide ghost_wrker with dissolve
                "Легенду о тебе придумали люди":
                    show g1:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Слишком многое не сходится… Я думаю, что ты не отсюда."
                    show ghost_wrker:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterwrker "Что ж…"
                    characterwrker "Видимо тебя не так просто обмануть."
                    $ reality += 1
                    "+Явь" 
                    hide ghost_wrker with dissolve
                    $ book_rest += 1
                    $ reality += 1
                    show rest with fade:
                        zoom 1.0 xalign 0 yalign 0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    $ sceneredbook += 1
                    "Вы нашли еще одну книгу! +Явь"
        hide rest
        hide g1
        with dissolve
        show ghost_wrker:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        "Призрака окутал туман, и [player_name] приготовилась к нападению. Однако, когда дымка рассеялась, рабочий изменился."
        hide ghost_wrker with dissolve
        show ghost_wrkhe:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterwrkhe "Знаешь, уже долгое время я здесь пугаю ребятишек, которые залезают в заброшенные корпуса, чтобы неповадно было сюда заходить."
        characterwrkhe "Я вообще не злой на самом деле. Меня родители сорванцов придумали, чтобы их пугать, и они меньше ходили по заброшенным зданиям."
        characterwrkhe "Правда, эффект это имело обратный. Всем детям еще больше хотелось на призрака посмотреть."
        "[player_name] почувствовала себя неловко.  Призрак оказался совсем незлой, даже в некоторой степени благородный.  Не стоило на него так нападать."
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Прости, что была слишком резкой."
        characterwrkhe "Я не могу тебя осуждать. Тебе со многим пришлось здесь столкнуться."
        characterwrkhe "Я не только не злюсь, но и предлагаю помощь."
        character "Какую?"
        characterwrkhe "Узнаешь позже…"
        hide ghost_wrkhe with dissolve
        "С этими словами призрак растворился."
        hide g6 with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "И все же… Они со своими фокусами и тайнами жутко раздражают…"
        hide g2 with dissolve
        if attack == 1:
            jump scene37_2_g_2
        else:
            jump scene37_2_g_1
        jump scene38

# В дом владельца плиточного завода Ивана Карловича Бредаля
label scene_huse:
    $ seria4vibr += 1
    $ scenehuse += 1
    scene 3back7 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music ball fadein 2.0 loop if_changed
    if gender == "M":
        show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
        tmrz "Здесь размещалась контора фабрики и квартира Ивана Карловича Бредаля, он владел собственным камнерезным заводом, где изготавливали плиты. Фасад здания тоже оформлен плитами светло-серого камня. Пожалуй, это самое богатое в плане декора здание Везенбергского квартала."
        show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
        character "Я и забыл, как выглядит этот дом, он уже 15 лет пустует и постоянно завешан строительной сеткой. Действительно очень красивый."
        tmrz "Иван Карлович сам его спроектировал."
        character "Надеюсь, если я справлюсь с призраками и вернусь в свое время, увижу его дальнейшую судьбу. Хотелось бы, чтобы его восстановили."
        hide t1 with dissolve
        show t2:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
        tmrz "Не «если» справишься с призраками, а «когда» с ними справишься."
        character "Вы очень оптимистичны."
        tmrz "Кстати, знаешь, что у хризантем есть такой сорт «оптимист»?"
        character "Не знаю. Это какая-то подсказка к следующему испытанию?"
        "Климент Аркадьевич тихо засмеялся."
        hide t2 with dissolve
        show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
        tmrz "Просто интересный факт. Полезно тренировать мозг занимательной информацией."
        hide t1 with dissolve
        hide m1 with dissolve
        scene 3back8 with fade:
            size (1280, 720)
            fit "fill"
        "Вход украшали изображения Вакханок, по бокам красовались различные узоры с фруктами и вазами изобилия. [player_name] невольно залюбовался  деталями дома Бредаля."
        "Было немного волнительно заходить сюда."
        show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
        character "Ладно, Климент Аркадьевич. Не будем тянуть. Пора действовать."
        show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
        tmrz "Удачи, мой друг."
        hide t1 with dissolve
        hide m1 with dissolve
        scene 3back9 with fade:
            size (1280, 720)
            fit "fill"
        show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
        character "Здесь довольно уютно… ну, если представить, что эту комнату не тронул бы туман."
        show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
        tmrz "Да, кабинет богатый. Очень много книг…"
        hide t1 with dissolve
        hide m1 with dissolve
        if vstret_rab == 1:
            show ghost_wrkhe:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
            characterwrkhe "Снова приветствую вас, друзья!"
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "А ты откуда здесь?"
            characterwrkhe "Я здесь жил. А на «Красном Треугольнике» только от скуки «подрабатываю» местной легендой. Сюда-то давно никто не заходит."
            character "Прости, если говорю очень предвзято, но не похоже, что бы ты мог жить в таком роскошном доме."
            characterwrkhe "Здесь же не только Иван Карлович проживал. Первый этаж занимала конюшня, кладовая и каретный сарай. На втором этаже жили управляющий, кучер, сторож и холостые рабочие."
            characterwrkhe "И вот только тут, на третьем и еще на четвертом этажах, располагалась восьмикомнатная квартира хозяина дома."
            hide m2 with dissolve
            show m5:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Надо же."
            hide m5 with dissolve
            hide ghost_wrkhe with dissolve
            if sceneredbook == 1:
                show ghost_wrkhe:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterwrkhe "Спрашивай, если вдруг тебе еще что-то интересно."
                hide ghost_wrkhe with dissolve
                menu:
                    character ""
                    "Раз здесь все спокойно, то, я думаю, лучше не буду терять время":
                        $ ghost += 1
                        "+ Призрак"
                        if attack == 1:
                            jump scene37_2_m_2
                        else:
                            jump scene37_2_m_1
                        jump scene38
                    "Расскажи немного о владельце":
                        $ reality += 1
                        "Призрак рабочего оценил ваш интерес + Явь"
                        show ghost_wrkhe:
                            zoom 1.0 xalign 0.7 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        characterwrkhe "Иоганн Бредаль был инженером, выполнял чертежные работы. Спустя четыре года жизни в Санкт-Петербурге он стал Иоганном Карловичем Бредалем и переселился на Ново-Петергофский проспект."
                        characterwrkhe "Позднее, будучи уже Иваном Карловичем, Бредаль приобрел в собственность участки земли по новой на тот момент Везенбергской улице. Здесь он построил плитный завод и склад. Фабрика инженера И.К. Бредаля занималась обработкой камня, поступавшего из собственных каменоломен близь Ревеля."
                        show m5:   
                            zoom 1.0 xalign -0.3 yalign 0.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        character "Ревеля?"
                        show t1:   
                            zoom 1.0 xalign 1.3 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        tmrz "Современного Таллина."
                        character "Вот как…"
                        tmrz "Не хочу прерывать тебя, мой друг, но нам пора."
                        hide m5 with dissolve
                        show m1:   
                            zoom 1.0 xalign -0.3 yalign 0.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        character "Спасибо вам за небольшую экскурсию."
                        characterwrkhe "Всегда рад."
                        hide m1 with dissolve
                        hide t1 with dissolve
                        hide ghost_wrkhe with dissolve
                        if attack == 1:
                            jump scene37_2_m_2
                        else:
                            jump scene37_2_m_1
                        jump scene38
        elif scenered == 0:
            "Не смотря на красоту кабинета, здесь было очень неуютно и холодно. [player_name] чувствовал опасность."
            show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
            characterht3 "..."
            show m7:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Это еще кто?!"
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Боюсь, что это один из самых страшных призраков – чудовище запустения."
            hide m7 with dissolve
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Это что еще такое?"
            tmrz "Когда дом долго стоит бесхозным и забытым, в нем заводится нечто ужасное."
            "Призрак тихо захрипел."
            characterghost "З…д...д…ррравссст…уй…"
            "Говорить по-человечески у призрака очень плохо получалось. Но очень радовало то, что он не спешил нападать."
            character "Что тебе нужно?"
            characterghost "За…га….д..т….ка."
            "[player_name] старался быть терпеливее."
            character "Я слушаю твою загадку."
            characterghost "Их..бу…три…"
            character "Их будет три?"
            "Призрак кивнул."
            hide m1 with dissolve
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "А не много ли для тебя?"
            "В ответ призрак покачал головой."
            "[player_name] переглянулся с Климентом Аркадьевичем и вздохнул."
            hide m2 with dissolve
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Ладно, давай твои загадки."
            characterghost "Они…бу…о камнях…"
            character "Ну что ж, я слушаю."
            "По рукам призрака скользнул туман. В его руках появился листок, и он протянул его вперед."
            "[player_name] с опасением забрал его себе и прочел."
            character "{i}«Это ярче глаз Багиры» - сказал Маугли, с восхищением поворачивая кристалл…{/i}"
            character "{i}«Многие люди убивали бы трижды в ночь ради одного этого красного камня» - заметил Каа.{/i}"
            hide m1 with dissolve
            hide t1 with dissolve
            hide ghost_ht3 with dissolve
            menu:
                "О каком камне идет речь?"
                "Гранат":
                    $ ghost += 1
                    "Не верно. +Призрак"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht3 "Ты ошшш…иб..ся."
                    hide ghost_ht3 with dissolve
                "Рубин":
                    $ zagadka += 1
                    $ reality += 1
                    "Верно. +Явь"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht3 "Веррр…но"
                    hide ghost_ht3 with dissolve
                "Малахит":
                    $ ghost += 1
                    "Не верно. +Призрак"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterghost "Ты ошшш…иб..ся."
                    hide ghost_ht3 with dissolve
            show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
            characterghost "Еще… За…га….д..т….ка."
            "Листок в руках растворился, и вместо него [player_name] держал следующий."
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "{i}«Чудесно зелена и знаменита{/i}"
            character "{i}Та чаша из резного ...»{/i}"
            hide m1 with dissolve
            hide ghost_ht3 with dissolve
            menu:
                "О каком камне идет речь?"
                "Гранита":
                    $ ghost += 1
                    "Не верно. +Призрак"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht3 "Ты ошшш…иб..ся."
                    hide ghost_ht3 with dissolve
                "Малахита":
                    $ zagadka += 1
                    $ reality += 1
                    "Верно. +Явь"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht3 "Веррр…но"
                    hide ghost_ht3 with dissolve
                "Аконита":
                    $ ghost += 1
                    "Не верно. +Призрак"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterghost "Ты ошшш…иб..ся."
                    hide ghost_ht3 with dissolve
            show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
            characterghost "Пос…дняяяя"
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Последняя?"
            "В руках появился листок с еще одной загадкой."
            character "{i} «Когда ж Куприн назвал им свой «Браслет…\nОн повести отдал свой дивный свет»{/i}"
            hide m1 with dissolve
            hide ghost_ht3 with dissolve
            menu:
                "О каком камне идет речь?"
                "Гранат":
                    $ zagadka += 1
                    $ reality += 1
                    "Верно. +Явь"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht3 "Веррр…но"
                    hide ghost_ht3 with dissolve
                "Рубин":
                    $ ghost += 1
                    "Не верно. +Призрак"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterghost "Ты ошшш…иб..ся."
                    hide ghost_ht3 with dissolve      
                "Малахит":
                    $ ghost += 1
                    "Не верно. +Призрак"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterghost "Ты ошшш…иб..ся."
                    hide ghost_ht3 with dissolve        
            if zagadka >= 2 and book_rest == 0:
                show ghost_ht3:
                            zoom 1.0 xalign 0.7 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                characterghost "Ты…засл…уж…л….я верн…кни..гху.."
                hide ghost_ht3 with dissolve
                "Вы нашли книгу."
                show rest with fade:
                    zoom 1.0 xalign 0 yalign 0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                $ scenehusebook += 1
                $ book_rest += 1
                hide rest with dissolve
                "Призрак растворился также внезапно, как и появился в этом доме."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Молодец, мой друг! Здесь наша работа окончена."
                hide t1 with dissolve
            elif zagadka >= 2 and book_rest == 1:
                show ghost_ht3:
                            zoom 1.0 xalign 0.7 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                characterghost "Чт….ооож. Про…ходи. Ты от…вИл  вер…но."
                hide ghost_ht3 with dissolve
                "Призрак растворился также внезапно, как и появился в этом доме."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Молодец, мой друг! Здесь наша работа окончена."
                hide t1 with dissolve
            elif zagadka <= 1 and book_rest == 0:
                show ghost_ht3:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterghost "Ты..не смо..гх… Мы силь…ллл…ее…"
                characterghost "Книии…гху..я оста..ляю сеепе….."
                hide ghost_ht3 with dissolve
                "Призрак растворился также внезапно, как и появился в этом доме."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Не расстраивайся, мой друг. Нам пора следовать далее."
                hide t1 with dissolve
            elif zagadka <= 1 and book_rest >= 1:
                show ghost_ht3:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterghost "Ты..не смо..гх… Мы силь…ллл…ее…"
                hide ghost_ht3 with dissolve
                "Призрак растворился также внезапно, как и появился в этом доме."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Не расстраивайся, мой друг. Нам пора следовать далее."
                hide t1 with dissolve
        if attack == 1:
            jump scene37_2_m_2
        else:
            jump scene37_2_m_1
        jump scene38
    elif gender == "G":
        show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
        tmrz "Здесь размещалась контора фабрики и квартира Ивана Карловича Бредаля, он владел собственным камнерезным заводом, где изготавливали плиты. Фасад здания тоже оформлен плитами светло-серого камня. Пожалуй, это самое богатое в плане декора здание Везенбергского квартала."
        show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
        character "Я и забыла, как выглядит этот дом, он уже 15 лет пустует и постоянно завешан строительной сеткой. Действительно очень красивый."
        tmrz "Иван Карлович сам его спроектировал."
        character "Надеюсь, если я справлюсь с призраками и вернусь в свое время, увижу его дальнейшую судьбу. Хотелось бы, чтобы его восстановили."
        hide t1 with dissolve
        show t2:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
        tmrz "Не «если» справишься с призраками, а «когда» с ними справишься."
        character "Вы очень оптимистичны."
        tmrz "Кстати, знаешь, что у хризантем есть такой сорт «оптимист»?"
        character "Не знаю. Это какая-то подсказка к следующему испытанию?"
        "Климент Аркадьевич тихо засмеялся."
        hide t2 with dissolve
        show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
        tmrz "Просто интересный факт. Полезно тренировать мозг занимательной информацией."
        hide t1 with dissolve
        hide g1 with dissolve
        scene 3back8 with fade:
            size (1280, 720)
            fit "fill"
        "Вход украшали изображения Вакханок, по бокам красовались различные узоры с фруктами и вазами изобилия. [player_name] невольно залюбовалась  деталями дома Бредаля."
        "Было немного волнительно заходить сюда."
        show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
        character "Ладно, Климент Аркадьевич. Не будем тянуть. Пора действовать."
        show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
        tmrz "Удачи, мой друг."
        hide t1 with dissolve
        hide g1 with dissolve
        scene 3back9 with fade:
            size (1280, 720)
            fit "fill"
        show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
        character "Здесь довольно уютно… ну, если представить, что эту комнату не тронул бы туман."
        show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
        tmrz "Да, кабинет богатый. Очень много книг…"
        hide t1 with dissolve
        hide g1 with dissolve
        if vstret_rab == 1:
            show ghost_wrkhe:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
            characterwrkhe "Снова приветствую вас, друзья!"
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "А ты откуда здесь?"
            characterwrkhe "Я здесь жил. А на «Красном Треугольнике» только от скуки «подрабатываю» местной легендой. Сюда-то давно никто не заходит."
            character "Прости, если говорю очень предвзято, но не похоже, что бы ты мог жить в таком роскошном доме."
            characterwrkhe "Здесь же не только Иван Карлович проживал. Первый этаж занимала конюшня, кладовая и каретный сарай. На втором этаже жили управляющий, кучер, сторож и холостые рабочие."
            characterwrkhe "И вот только тут, на третьем и еще на четвертом этажах, располагалась восьмикомнатная квартира хозяина дома."
            hide g2 with dissolve
            show g5:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Надо же."
            hide g5 with dissolve
            hide ghost_wrkhe with dissolve
            if sceneredbook == 1:
                show ghost_wrkhe:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterwrkhe "Спрашивай, если вдруг тебе еще что-то интересно."
                hide ghost_wrkhe with dissolve
                menu:
                    character ""
                    "Раз здесь все спокойно, то, я думаю, лучше не буду терять время":
                        $ ghost += 1
                        "+ Призрак"
                        if attack == 1:
                            jump scene37_2_g_2
                        else:
                            jump scene37_2_g_1
                        jump scene38
                    "Расскажи немного о владельце":
                        $ reality += 1
                        "Призрак рабочего оценил ваш интерес + Явь"
                        show ghost_wrkhe:
                            zoom 1.0 xalign 0.7 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        characterwrkhe "Иоганн Бредаль был инженером, выполнял чертежные работы. Спустя четыре года жизни в Санкт-Петербурге он стал Иоганном Карловичем Бредалем и переселился на Ново-Петергофский проспект."
                        characterwrkhe "Позднее, будучи уже Иваном Карловичем, Бредаль приобрел в собственность участки земли по новой на тот момент Везенбергской улице. Здесь он построил плитный завод и склад. Фабрика инженера И.К. Бредаля занималась обработкой камня, поступавшего из собственных каменоломен близь Ревеля."
                        show g5:   
                            zoom 1.0 xalign -0.3 yalign 0.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        character "Ревеля?"
                        show t1:   
                            zoom 1.0 xalign 1.3 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        tmrz "Современного Таллина."
                        character "Вот как…"
                        tmrz "Не хочу прерывать тебя, мой друг, но нам пора."
                        hide g5 with dissolve
                        show g1:   
                            zoom 1.0 xalign -0.3 yalign 0.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        character "Спасибо вам за небольшую экскурсию."
                        characterwrkhe "Всегда рад."
                        hide g1 with dissolve
                        hide t1 with dissolve
                        hide ghost_wrkhe with dissolve
                        if attack == 1:
                            jump scene37_2_g_2
                        else:
                            jump scene37_2_g_1
                        jump scene38
        if scenered == 0:
            "Не смотря на красоту кабинета, здесь было очень неуютно и холодно. [player_name] чувствовала опасность."
            show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
            characterht3 "..."
            show g7:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Это еще кто?!"
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Боюсь, что это один из самых страшных призраков – чудовище запустения."
            hide g7 with dissolve
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Это что еще такое?"
            tmrz "Когда дом долго стоит бесхозным и забытым, в нем заводится нечто ужасное."
            "Призрак тихо захрипел."
            characterghost "З…д...д…ррравссст…уй…"
            "Говорить по-человечески у призрака очень плохо получалось. Но очень радовало то, что он не спешил нападать."
            character "Что тебе нужно?"
            characterghost "За…га….д..т….ка."
            "[player_name] старалась быть терпеливее."
            character "Я слушаю твою загадку."
            characterghost "Их..бу…три…"
            character "Их будет три?"
            "Призрак кивнул."
            hide g1 with dissolve
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "А не много ли для тебя?"
            "В ответ призрак покачал головой."
            "[player_name] переглянулась с Климентом Аркадьевичем и вздохнула."
            hide g2 with dissolve
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Ладно, давай твои загадки."
            characterghost "Они…бу…о камнях…"
            character "Ну что ж, я слушаю."
            "По рукам призрака скользнул туман. В его руках появился листок, и он протянул его вперед."
            "[player_name] с опасением забрала его себе и прочла."
            character "{i}«Это ярче глаз Багиры» - сказал Маугли, с восхищением поворачивая кристалл…{/i}"
            character "{i}«Многие люди убивали бы трижды в ночь ради одного этого красного камня» - заметил Каа.{/i}"
            hide g1 with dissolve
            hide t1 with dissolve
            hide ghost_ht3 with dissolve
            menu:
                "О каком камне идет речь?"
                "Гранат":
                    $ ghost += 1
                    "Не верно. +Призрак"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht3 "Ты ошшш…иб..лась."
                    hide ghost_ht3 with dissolve
                "Рубин":
                    $ zagadka += 1
                    $ reality += 1
                    "Верно. +Явь"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht3 "Веррр…но"
                    hide ghost_ht3 with dissolve
                "Малахит":
                    $ ghost += 1
                    "Не верно. +Призрак"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterghost "Ты ошшш…иб..лась."
                    hide ghost_ht3 with dissolve
            show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
            characterghost "Еще… За…га….д..т….ка."
            "Листок в руках растворился, и вместо него [player_name] держала следующий."
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "{i} «Чудесно зелена и знаменита\nТа чаша из резного ...»{/i}"
            hide g1 with dissolve
            hide ghost_ht3 with dissolve
            menu:
                "О каком камне идет речь?"
                "Гранита":
                    $ ghost += 1
                    "Не верно. +Призрак"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht3 "Ты ошшш…иб..лась."
                    hide ghost_ht3 with dissolve
                "Малахита":
                    $ zagadka += 1
                    $ reality += 1
                    "Верно. +Явь"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht3 "Веррр…но"
                    hide ghost_ht3 with dissolve
                "Аконита":
                    $ ghost += 1
                    "Не верно. +Призрак"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterghost "Ты ошшш…иб..лась."
                    hide ghost_ht3 with dissolve
            show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
            characterghost "Пос…дняяяя"
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Последняя?"
            "В руках появился листок с еще одной загадкой."
            character "{i} «Когда ж Куприн назвал им свой «Браслет…\nОн повести отдал свой дивный свет»{/i}"
            hide g1 with dissolve
            hide ghost_ht3 with dissolve
            menu:
                "О каком камне идет речь?"
                "Гранат":
                    $ zagadka += 1
                    $ reality += 1
                    "Верно. +Явь"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterht3 "Веррр…но"
                    hide ghost_ht3 with dissolve
                "Рубин":
                    $ ghost += 1
                    "Не верно. +Призрак"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterghost "Ты ошшш…иб..лась."
                    hide ghost_ht3 with dissolve      
                "Малахит":
                    $ ghost += 1
                    "Не верно. +Призрак"
                    show ghost_ht3:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterghost "Ты ошшш…иб..лась."
                    hide ghost_ht3 with dissolve        
            if zagadka >= 2 and book_rest == 0:
                show ghost_ht3:
                            zoom 1.0 xalign 0.7 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                characterghost "Ты…засл…уж…л….я верн…кни..гху.."
                hide ghost_ht3 with dissolve
                "Вы нашли книгу."
                show rest with fade:
                    zoom 1.0 xalign 0 yalign 0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                $ scenehusebook += 1
                $ book_rest += 1
                hide rest with dissolve
                "Призрак растворился также внезапно, как и появился в этом доме."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Молодец, мой друг! Здесь наша работа окончена."
                hide t1 with dissolve
            elif zagadka >= 2 and book_rest == 1:
                show ghost_ht3:
                            zoom 1.0 xalign 0.7 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                characterghost "Чт….ооож. Про…ходи. Ты от…вИл  вер…но."
                hide ghost_ht3 with dissolve
                "Призрак растворился также внезапно, как и появился в этом доме."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Молодец, мой друг! Здесь наша работа окончена."
                hide t1 with dissolve
            elif zagadka <= 1 and book_rest == 0:
                show ghost_ht3:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterghost "Ты..не смо..гх… Мы силь…ллл…ее…"
                characterghost "Книии…гху..я оста..ляю сеепе….."
                hide ghost_ht3 with dissolve
                "Призрак растворился также внезапно, как и появился в этом доме."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Не расстраивайся, мой друг. Нам пора следовать далее."
                hide t1 with dissolve
            elif zagadka <= 1 and book_rest >= 1:
                show ghost_ht3:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterghost "Ты..не смо..гх… Мы силь…ллл…ее…"
                hide ghost_ht3 with dissolve
                "Призрак растворился также внезапно, как и появился в этом доме."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Не расстраивайся, мой друг. Нам пора следовать далее."
                hide t1 with dissolve
        if attack == 1:
            jump scene37_2_g_2
        else:
            jump scene37_2_g_1
        jump scene38

# В филиал Обуховской больницы
label scene_medic:
    $ seria4vibr += 1
    $ scenemedic += 1
    scene 3back5 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music bany fadein 2.0 loop if_changed
    if gender == "M":
        "В этот раз [player_name] и Климент Аркадьевич оказались у краснокирпичного небольшого здания."
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Здесь была больница?"
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "У этого здания интересная история…"
        character "Расскажите."
        tmrz "Оно было построено в 1902 году на участке, принадлежавшем Доктору медицины Владимиру Ивановичу Рамму."
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Он увлекался издательским делом и мечтал открыть свой Полиграфический институт."
        hide m6 with dissolve
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Дело неплохое."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Проблема была в том, что он был не самый честный человек."
        hide m5 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "И что случилось?"
        tmrz "Вместе со своим компаньоном Гавриловым Владимир Иванович Рамм занялся выпуском ежемесячного журнала «Живописное обозрение». Подписчикам обещали, что всего за 7 рублей в год они получат помимо самих выпусков журнала более 300 различных книг в качестве подарков."
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "С подписчиков было собрано более ста тысяч рублей. А в то время это были большие деньги. Вышло всего несколько номеров журнала, и на этом все. Читатели остались без журнала."
        hide m1 with dissolve
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Хитро."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Эта издательская афера, которая, кстати, была не первой в жизни В.И. Рамма, вскрылась, и доктору медицины пришлось полностью менять привычный образ жизни. До этого он жил на широкую ногу."
        hide m5 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Надо же! А что стало с домом?"
        tmrz "В начале 1903 года над имуществом В.И. Рамма была назначена администрация, дом был продан, а сам доктор стал штатным сотрудником обычной газеты."
        hide m1 with dissolve
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Печальная история…"
        tmrz "В 1908 году дом приобрела Обуховская больница. В здании разместилось Лейхтенбергское отделение больницы для лечения кожных заболеваний. Во время войны сюда возили раненых."
        hide m6 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Какая необычная судьба у дома…"
        tmrz "В Везенбергском квартале нет скучных домов."
        "Климент Аркадьевич подмигнул и кивнул в сторону дома."
        stop music fadeout 1.0
        play music haspit fadein 2.0 loop if_changed
        tmrz "Пойдем, есть предчувствие, что там нас ждет что-то зловещее."
        hide m1 with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Надеюсь, что это только предчувствие."
        hide m2
        hide t1
        with dissolve
        scene 3back6 with fade:#########
            size (1280, 720)
            fit "fill"
        "Из всех мест, которые [player_name] успел посетить, это оказалось самым эффектным и гнетущим."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ну почему мы попали именно в то время, когда здесь была больница."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Видимо это самые яркие воспоминания, которые хранят эти стены."
        hide t1 with dissolve
        "[player_name] бродил по пустым палатам и старался найти хоть какую-то подсказку."
        "Постели были расправлены и по-разному смяты, словно их хозяева только-только куда-то отошли и скоро вернутся."
        "И хотя здесь никого не было, острое чувство присутствия никуда не уходило."
        "Неизвестно, как долго [player_name] и Тимирязев рассматривали пространство вокруг. Но ничего не происходило."
        "[player_name] от скуки стал залезать в ящики и смотреть, что оставили призраки. Больничные бинты, лекарства, пустые пузырьки… Но никаких книг. Тогда [player_name] решил заглянуть в шкаф."
        hide m1 with dissolve
        show ghost_pacient:
            xpos 200 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ты кто?!!!!"
        "Призрак, довольный эффектом, плавно выскользнул из шкафа."
        characterpacient "Знаешь, в нашем мире все так всполошились из-за твоего появления. Ушли даже на собрание, чтоб придумать новые козни."
        hide m7 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А ты почему не там?"
        characterpacient "А меня не взяли. Сказали, что я постоянно бьюсь обо все углы, спотыкаюсь и вообще ничего не могу сделать. Только рассмешить тебя могу, а не напугать."
        "[player_name] с удивлением осознал, что ему стало обидно за призрака, ведь за собой он тоже часто замечал неуклюжесть. Это же не повод сразу кого-то списывать со счетов."
        hide m1 with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Они не правы. В шкафу ты меня сильно напугал."
        characterpacient "Не утешай меня. Мы все равно враги."
        hide m2 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Как скажешь."
        "Ненадолго повисла неловкая пауза. Призрак о чем-то раздумывал."
        characterpacient "Хотя…спасибо, что оценил."
        character "Нет проблем."
        "И снова пауза. Видимо никто не знал, что делать дальше. На помощь пришел Климент Аркадьевич."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Знаешь, обычно призраки придумывают загадки или испытания…"
        characterpacient "Обычно да…"
        "Снова повисла пауза."
        character "Ты странный. Ты знаешь?"
        characterpacient "Да… Мне говорили."
        character "..."
        characterpacient "..."
        tmrz "..."
        character "Может, у тебя для меня есть загадка?"
        characterpacient "Загадка? Нет-Нет… Это я не умею придумывать."
        hide m1 with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Испытание?"
        characterpacient "Нееее, это еще сложнее."
        character "Может быть бой?"
        characterpacient "Ты смеешься? Я капельницу за собой везде таскаю. Как я драться буду?"
        hide m2 with dissolve
        hide t1 with dissolve
        hide ghost_pacient with dissolve
        if book_rest == 1:
            show ghost_pacient:
                xpos 200 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterpacient "Давай так. Ты расскажешь мне о своем мире, и, если рассказ мне понравится – я тебе дам подсказку."
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Будь осторожен, мне кажется, его нельзя расстраивать."
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Хорошо. Что ты хочешь знать?"
            hide m1
            hide t1
            hide ghost_pacient
            with dissolve
        elif book_rest == 0:
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Так, а может, ты мне просто подаришь книгу?"
            show ghost_pacient:
                xpos 200 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterpacient "Нееет, хитрюга. Так просто я тебе ее не отдам."
            characterpacient "Давай так. Ты расскажешь мне о своем мире, и, если рассказ мне понравится, я тебе отдам книжку."
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Будь осторожен, мне кажется, его нельзя расстраивать."
            character "Хорошо. Что ты хочешь знать?"
            hide m1
            hide t1
            hide ghost_pacient
            with dissolve
        show ghost_pacient:
            xpos 200 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterpacient "Расскажи, спокойно ли в вашем мире?"
        hide ghost_pacient with dissolve
        menu:
            "Люди остаются людьми":
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Каждый старается сделать как лучше, но не всегда все сходятся во мнении."
                $ zagadkamedic += 1
                "Призраку нравится ваш ответ."
                hide m2 with dissolve
            "Ничего не меняется. Все злые и вредные. Особенно с утра":
                "Призраку не нравится ваш ответ."
                show ghost_pacient:
                    xpos 200 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpacient "А может, ты просто не хочешь видеть хорошее?"
                hide ghost_pacient with dissolve
            "Относительно спокойно":
                show ghost_pacient:
                    xpos 200 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpacient "Относительно чего?"
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Не знаю."
                characterpacient "А зачем ты говоришь, если не знаешь?"
                "Призраку не нравится ваш ответ."
                hide m2
                hide ghost_pacient 
                with dissolve
        show ghost_pacient:
            xpos 200 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterpacient "А какие технологии у вас появились?"
        hide ghost_pacient with dissolve
        menu:
            "Появилась коробка, в которой хранится информация про все и обо всем":
                show ghost_pacient:
                    xpos 200 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpacient "Это как?"
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Их называют компьютеры. Они помогают людям работать, искать информацию об окружающем мире, там можно писать и сохранять свои… книги, например. И новости теперь люди узнают через интернет, а не с помощью газет."
                characterpacient "Интернет?"
                character "Всемирная сеть. Туда заходят через компьютеры со всего мира и пишут все, что происходит."
                characterpacient "Ты выдумываешь."
                character "Не выдумываю!"
                characterpacient "Нет, это какая-то бессвязная сказка. Так не бывает."
                "Призраку не нравится ваш ответ."
                hide ghost_pacient
                hide m2
                with dissolve
            "Появились у каждого личные устройства для общения на расстоянии":
                show ghost_pacient:
                    xpos 200 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpacient "Это как?"
                show m1:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Мы носим с собой прямоугольные устройства и в любой момент можем друг другу позвонить по ним."
                characterpacient "Как волшебное блюдце в сказках?"
                character "Ну почти. Используются радиоволны с определёнными частотами. Эти устройства их ловят и передают связь."
                characterpacient "Наверно это очень удобно."
                character "Пожалуй."
                $ zagadkamedic += 1
                "Призраку нравится ваш ответ."
                hide ghost_pacient
                hide m1
                with dissolve
            "Не знаю":
                show ghost_pacient:
                    xpos 200 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpacient "Так это же твой мир, который ты защищаешь. Неужели ты не можешь похвалиться тем, чего вы добились."
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Да так сразу и не вспомнишь!"
                characterpacient "Странный ты человек, совсем не интересуешься тем, что тебя окружает, а хочешь зачем-то этот мир спасти."
                "Призраку не нравится ваш ответ."
                characterpacient "Вы помните о нас? О том, что было здесь? Люди хранят память об этих местах?"
                hide ghost_pacient
                hide m2
                with dissolve
                menu:
                    "Да":
                        show m2:   
                            zoom 1.0 xalign -0.3 yalign 0.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        character "Хранят, изучают, стараются рассказывать. Когда я пришел в библиотеку, я увидел, что люди читают про Везенбергский квартал. Ищут о нем информацию, водят по нему экскурсии."
                        show ghost_pacient:
                            xpos 200 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        characterpacient "Приятно знать. Значит, призраки не очень справедливы к вам."
                        character "Думаю, что да."
                        $ zagadkamedic += 1
                        "Призраку нравится ваш ответ."
                        hide ghost_pacient
                        hide m2
                        with dissolve
                    "По-разному":
                        show m2:   
                            zoom 1.0 xalign -0.3 yalign 0.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        character "Много тех, кто изучает историю, читает архивы и пишет научные работы. Однако мы потеряли много исторических домов. Не смогли их сохранить и защитить. Уничтожили своим равнодушием."
                        show ghost_pacient:
                            xpos 200 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        characterpacient "Спасибо за честный ответ."
                        $ zagadkamedic += 1
                        "Призраку нравится ваш ответ."
                        hide ghost_pacient
                        hide m2
                        with dissolve
                    "Нет":
                        show m2:   
                            zoom 1.0 xalign -0.3 yalign 0.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        character "Стыдно признаться, но я мало знаю о том, как сохраняют память об этих местах. До этого дня я не знал о существовании этого квартала."
                        show ghost_pacient:
                            xpos 200 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        characterpacient "Что ж, тогда я надеюсь, ты не удивляешься тому, что призраки квартала разозлились на вас."
                        character "Теперь я понимаю."
                        "Призрака разочаровал ваш ответ."
                        hide ghost_pacient
                        hide m2
                        with dissolve
        if zagadkamedic >= 1 and book_rest == 1:
            show ghost_pacient:
                xpos 200 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterpacient "Спасибо за эту беседу. Было очень познавательно. В благодарность я тебя предупрежу – опасайся призрачных полицейских. Уж очень они подозрительные."
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Спасибо."
            $ reality += 1
            "+ Явь"
            hide m1
            hide ghost_pacient
            with dissolve
        elif zagadkamedic >= 1 and book_rest == 0:
            show ghost_pacient:
                xpos 200 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterpacient "Спасибо за эту беседу. Было очень познавательно. Как и обещал, держи свою книгу."
            $ reality += 1
            $ book_rest += 1
            show rest with fade:
                zoom 1.0 xalign 0 yalign 0
                alpha 0.0
                easein 0.3 alpha 1.0
            "+ Явь. Вы получили еще одну библиотечную книгу."
            hide rest
            hide ghost_pacient 
            with dissolve
        elif zagadkamedic == 0:
            show ghost_pacient:
                xpos 200 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterpacient "Прости, но, кажется, я убедился, что призраки правы. Я не буду тебе помогать. Хотя и вижу, что ты человек неплохой, но этого не достаточно. Ступай своей дрогой."
            $ ghost += 1
            "+Призрак"
            hide ghost_pacient with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Нам пора, мой друг. Нужно спешить дальше, времени осталось совсем мало."
        hide t1 with dissolve
        if attack == 1:
            jump scene37_2_m_2
        else:
            jump scene37_2_m_1
        jump scene38
    elif gender == "G":
        "В этот раз [player_name] и Климент Аркадьевич оказались у краснокирпичного небольшого здания."
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Здесь была больница?"
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "У этого здания интересная история…"
        character "Расскажите."
        tmrz "Оно было построено в 1902 году на участке, принадлежавшем Доктору медицины Владимиру Ивановичу Рамму."
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Он увлекался издательским делом и мечтал открыть свой Полиграфический институт."
        hide g6 with dissolve
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Дело неплохое."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Проблема была в том, что он был не самый честный человек."
        hide g5 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "И что случилось?"
        tmrz "Вместе со своим компаньоном Гавриловым Владимир Иванович Рамм занялся выпуском ежемесячного журнала «Живописное обозрение». Подписчикам обещали, что всего за 7 рублей в год они получат помимо самих выпусков журнала более 300 различных книг в качестве подарков."
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "С подписчиков было собрано более ста тысяч рублей. А в то время это были большие деньги. Вышло всего несколько номеров журнала, и на этом все. Читатели остались без журнала."
        hide g1 with dissolve
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Хитро."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Эта издательская афера, которая, кстати, была не первой в жизни В.И. Рамма, вскрылась, и доктору медицины пришлось полностью менять привычный образ жизни. До этого он жил на широкую ногу."
        hide g5 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Надо же! А что стало с домом?"
        tmrz "В начале 1903 года над имуществом В.И. Рамма была назначена администрация, дом был продан, а сам доктор стал штатным сотрудником обычной газеты."
        hide g1 with dissolve
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Печальная история…"
        tmrz "В 1908 году дом приобрела Обуховская больница. В здании разместилось Лейхтенбергское отделение больницы для лечения кожных заболеваний. Во время войны сюда возили раненых."
        hide g6 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Какая необычная судьба у дома…"
        tmrz "В Везенбергском квартале нет скучных домов."
        "Климент Аркадьевич подмигнул и кивнул в сторону дома."
        stop music fadeout 1.0
        play music haspit fadein 2.0 loop if_changed
        tmrz "Пойдем, есть предчувствие, что там нас ждет что-то зловещее."
        hide g1 with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Надеюсь, что это только предчувствие."
        hide g2
        hide t1
        with dissolve
        scene 3back6 with fade:
            size (1280, 720)
            fit "fill"
        "Из всех мест, которые [player_name] успела посетить, это оказалось самым эффектным и гнетущим."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ну почему мы попали именно в то время, когда здесь была больница."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Видимо это самые яркие воспоминания, которые хранят эти стены."
        hide t1 with dissolve
        "[player_name] бродила по пустым палатам и старалась найти хоть какую-то подсказку."
        "Постели были расправлены и по-разному смяты, словно их хозяева только-только куда-то отошли и скоро вернутся."
        "И хотя здесь никого не было, острое чувство присутствия никуда не уходило."
        "Неизвестно, как долго [player_name] и Тимирязев рассматривали пространство вокруг. Но ничего не происходило."
        "[player_name] от скуки стала залезать в ящики и смотреть, что оставили призраки. Больничные бинты, лекарства, пустые пузырьки… Но никаких книг. Тогда [player_name] решила заглянуть в шкаф."
        hide g1 with dissolve
        show ghost_pacient:
                xpos 200 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ты кто?!!!!"
        "Призрак, довольный эффектом, плавно выскользнул из шкафа."
        characterpacient "Знаешь, в нашем мире все так всполошились из-за твоего появления. Ушли даже на собрание, чтоб придумать новые козни."
        hide g7 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А ты почему не там?"
        characterpacient "А меня не взяли. Сказали, что я постоянно бьюсь обо все углы, спотыкаюсь и вообще ничего не могу сделать. Только рассмешить тебя могу, а не напугать."
        "[player_name] с удивлением осознала, что ей стало обидно за призрака, ведь за собой она тоже часто замечала неуклюжесть. Это же не повод сразу кого-то списывать со счетов."
        hide g1 with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Они не правы. В шкафу ты меня сильно напугал."
        characterpacient "Не утешай меня. Мы все равно враги."
        hide g2 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Как скажешь."
        "Ненадолго повисла неловкая пауза. Призрак о чем-то раздумывал."
        characterpacient "Хотя…спасибо, что оценила."
        character "Нет проблем."
        "И снова пауза. Видимо никто не знал, что делать дальше. На помощь пришел Климент Аркадьевич."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Знаешь, обычно призраки придумывают загадки или испытания…"
        characterpacient "Обычно да…"
        "Снова повисла пауза."
        character "Ты странный. Ты знаешь?"
        characterpacient "Да… Мне говорили."
        character "..."
        characterpacient "..."
        tmrz "..."
        character "Может, у тебя для меня есть загадка?"
        characterpacient "Загадка? Нет-Нет… Это я не умею придумывать."
        hide g1 with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Испытание?"
        characterpacient "Нееее, это еще сложнее."
        character "Может быть бой?"
        characterpacient "Ты смеешься? Я капельницу за собой везде таскаю. Как я драться буду?"
        hide g2 with dissolve
        hide t1 with dissolve
        hide ghost_pacient with dissolve
        if book_rest == 1:
            show ghost_pacient:
                xpos 200 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterpacient "Давай так. Ты расскажешь мне о своем мире, и, если рассказ мне понравится – я тебе дам подсказку."
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Будь осторожна, мне кажется, его нельзя расстраивать."
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Хорошо. Что ты хочешь знать?"
            hide g1
            hide t1
            hide ghost_pacient
            with dissolve
        elif book_rest == 0:
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Так, а может, ты мне просто подаришь книгу?"
            show ghost_pacient:
                xpos 200 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterpacient "Нееет, хитрюга. Так просто я тебе ее не отдам."
            characterpacient "Давай так. Ты расскажешь мне о своем мире, и, если рассказ мне понравится, я тебе отдам книжку."
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Будь осторожна, мне кажется, его нельзя расстраивать."
            character "Хорошо. Что ты хочешь знать?"
            hide g1
            hide t1
            hide ghost_pacient
            with dissolve
        show ghost_pacient:
            xpos 200 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterpacient "Расскажи, спокойно ли в вашем мире?"
        hide ghost_pacient with dissolve
        menu:
            "Люди остаются людьми":
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Каждый старается сделать как лучше, но не всегда все сходятся во мнении."
                $ zagadkamedic += 1
                "Призраку нравится ваш ответ."
                hide g2 with dissolve
            "Ничего не меняется. Все злые и вредные. Особенно с утра":
                "Призраку не нравится ваш ответ."
                show ghost_pacient:
                    xpos 200 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpacient "А может, ты просто не хочешь видеть хорошее?"
                hide ghost_pacient with dissolve
            "Относительно спокойно":
                show ghost_pacient:
                    xpos 200 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpacient "Относительно чего?"
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Не знаю."
                characterpacient "А зачем ты говоришь, если не знаешь?"
                "Призраку не нравится ваш ответ."
                hide g2
                hide ghost_pacient 
                with dissolve
        show ghost_pacient:
            xpos 200 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterpacient "А какие технологии у вас появились?"
        hide ghost_pacient with dissolve
        menu:
            "Появилась коробка, в которой хранится информация про все и обо всем":
                show ghost_pacient:
                    xpos 200 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpacient "Это как?"
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Их называют компьютеры. Они помогают людям работать, искать информацию об окружающем мире, там можно писать и сохранять свои… книги, например. И новости теперь люди узнают через интернет, а не с помощью газет."
                characterpacient "Интернет?"
                character "Всемирная сеть. Туда заходят через компьютеры со всего мира и пишут все, что происходит."
                characterpacient "Ты выдумываешь."
                character "Не выдумываю!"
                characterpacient "Нет, это какая-то бессвязная сказка. Так не бывает."
                "Призраку не нравится ваш ответ."
                hide ghost_pacient
                hide g2
                with dissolve
            "Появились у каждого личные устройства для общения на расстоянии":
                show ghost_pacient:
                    xpos 200 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpacient "Это как?"
                show g1:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Мы носим с собой прямоугольные устройства и в любой момент можем друг другу позвонить по ним."
                characterpacient "Как волшебное блюдце в сказках?"
                character "Ну почти. Используются радиоволны с определёнными частотами. Эти устройства их ловят и передают связь."
                characterpacient "Наверно это очень удобно."
                character "Пожалуй."
                $ zagadkamedic += 1
                "Призраку нравится ваш ответ."
                hide ghost_pacient
                hide g1
                with dissolve
            "Не знаю":
                show ghost_pacient:
                    xpos 200 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterpacient "Так это же твой мир, который ты защищаешь. Неужели ты не можешь похвалиться тем, чего вы добились."
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Да так сразу и не вспомнишь!"
                characterpacient "Странный ты человек, совсем не интересуешься тем, что тебя окружает, а хочешь зачем-то этот мир спасти."
                "Призраку не нравится ваш ответ."
                characterpacient "Вы помните о нас? О том, что было здесь? Люди хранят память об этих местах?"
                hide ghost_pacient
                hide g2
                with dissolve
                menu:
                    "Да":
                        show g2:   
                            zoom 1.0 xalign -0.3 yalign 0.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        character "Хранят, изучают, стараются рассказывать. Когда я пришла в библиотеку, я увидела, что люди читают про Везенбергский квартал. Ищут о нем информацию, водят по нему экскурсии."
                        show ghost_pacient:
                            xpos 200 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        characterpacient "Приятно знать. Значит, призраки не очень справедливы к вам."
                        character "Думаю, что да."
                        $ zagadkamedic += 1
                        "Призраку нравится ваш ответ."
                        hide ghost_pacient
                        hide g2
                        with dissolve
                    "По-разному":
                        show g2:   
                            zoom 1.0 xalign -0.3 yalign 0.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        character "Много тех, кто изучает историю, читает архивы и пишет научные работы. Однако мы потеряли много исторических домов. Не смогли их сохранить и защитить. Уничтожили своим равнодушием."
                        show ghost_pacient:
                            xpos 200 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        characterpacient "Спасибо за честный ответ."
                        $ zagadkamedic += 1
                        "Призраку нравится ваш ответ."
                        hide ghost_pacient
                        hide g2
                        with dissolve
                    "Нет":
                        show g2:   
                            zoom 1.0 xalign -0.3 yalign 0.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        character "Стыдно признаться, но я мало знаю о том, как сохраняют память об этих местах. До этого дня я не знала о существовании этого квартала."
                        show ghost_pacient:
                            xpos 200 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        characterpacient "Что ж, тогда я надеюсь, ты не удивляешься тому, что призраки квартала разозлились на вас."
                        character "Теперь я понимаю."
                        "Призрака разочаровал ваш ответ."
                        hide ghost_pacient
                        hide g2
                        with dissolve
        if zagadkamedic >= 1 and book_rest == 1:
            show ghost_pacient:
                xpos 200 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterpacient "Спасибо за эту беседу. Было очень познавательно. В благодарность я тебя предупрежу – опасайся призрачных полицейских. Уж очень они подозрительные."
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Спасибо."
            $ reality += 1
            "+ Явь"
            hide g1
            hide ghost_pacient
            with dissolve
        elif zagadkamedic >= 1 and book_rest == 0:
            show ghost_pacient:
                xpos 200 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterpacient "Спасибо за эту беседу. Было очень познавательно. Как и обещал, держи свою книгу."
            $ reality += 1
            "+ Явь. Вы получили еще одну библиотечную книгу."
            $ book_rest += 1
            show rest with fade:
                zoom 1.0 xalign 0 yalign 0
                alpha 0.0
                easein 0.3 alpha 1.0
            hide rest
            hide ghost_pacient 
            with dissolve
        elif zagadkamedic == 0:
            show ghost_pacient:
                xpos 200 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterpacient "Прости, но, кажется, я убедился, что призраки правы. Я не буду тебе помогать. Хотя и вижу, что ты человек неплохой, но этого не достаточно. Ступай своей дрогой."
            $ ghost += 1
            "+Призрак"
            hide ghost_pacient with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Нам пора, мой друг. Нужно спешить дальше, времени осталось совсем мало."
        hide t1 with dissolve
        if attack == 1:
            jump scene37_2_g_2
        else:
            jump scene37_2_g_1
        jump scene38

# В фотостудию Н.Ф. Агафонова
label scene_pht:
    $ seria4vibr += 1
    $ scenepht += 1
    scene 3back10 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music bany fadein 2.0 loop if_changed
    if gender == "M":
        "Фотостудия располагалась в доме на углу  Везенбергской улицы. На первом этаже находилась рюмочная, [player_name] с тоской вспомнил, что сейчас, в наше время, в этом доме есть кофейня."
        "Силы уже покидали в сражениях с призраками. И кофе бы совсем не помешал."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Всегда нравились подобные здания, где из кирпича на фасаде выложен рисунок, словно это вышивка."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Да, хитрый способ украсить здания без дополнительной скульптуры."
        character "Здесь находилась фотостудия? Она имела успех?"
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Конечно, рядом же два вокзала – места встреч и расставаний. Раньше не так просто было сделать фото, а сфотографироваться на память очень хотелось."
        character "Я помню, что вы любите фотографировать."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Конечно."
        character "Вам бы хотелось попасть в наше время? Теперь столько устройств для фотографии. И фотографировать теперь может буквально каждый."
        tmrz "Я всегда был убежден, что придет время, когда люди будут чаще бродить по лесам и полям не с ружьем, а с камерой фотографа за плечами."
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "И не затем, чтобы подшибить несчастную пичужку и лишь мимоходом, урывками полюбоваться на природу, а затем именно, чтобы любоваться природой и при случае унести с собой возможно художественное её воспроизведение."
        "Эта цитата действительно принадлежит Клименту Аркадьевичу Тимирязеву."
        character "Вы оказались правы."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Пойдем, мой друг. Познакомимся с фотостудией Агафонова."
        hide t1 
        hide m1 
        with dissolve
        scene 3back11 with fade:
            size (1280, 720)
            fit "fill"
        "Фотостудия была небольшой. Всюду стояло специальное оборудование."
        "[player_name] приблизился к столу. Здесь лежал фотоальбом с различными фотографиями."
        "[player_name] осмотрел несколько снимков, и особенно его привлекла фотография маленькой девочки."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Такие все суровые на фото. Совсем не улыбаются."
        show ghost_children:
            size (1280, 720)
            fit "fill"
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterchildren "Вот так?!"
        "Прямо перед столом появился призрак маленькой девочки. Она от уха до уха улыбнулась и, захохотав, стала бегать по комнате."
        "От неожиданности [player_name] отшатнулся от стола."
        hide ghost_children
        hide m1
        with dissolve
        if book_rest > 0: # >0
            show ghost_children:
                size (1280, 720)
                fit "fill"
                zoom 1.0 xalign 0.7 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            $ book_rest -= 1
            "[player_name] не заметил, как, воспользовавшись его смятением, девочка выхватила из рук недавно найденную книгу, которую еще не спрятали в рюкзак."
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "А ну отдай! Я ее честно отвоевал!"
            characterchildren "Не догонишь, не догонишь!"
            "Поддавшись на игру, [player_name] начал гоняться за вредным призраком."
            "Отбежав на достаточное расстояние, девочка развернулась и показала язык."
            character "А ну иди сюда, маленькая гадость!"
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "А ну стой!"
            "[player_name] почвувствовал, что Климент Аркадьевич схватил его за шиворот, остановив беготню."
            tmrz "Она-то маленькая, а ты куда?"
            character "Сейчас я быстро ей ремня дам, если родители не воспитывали!"
            "Девочка стояла на безопасном расстоянии и продолжала корчить рожицы за спиной Климента Аркадьевича."
            tmrz "Остынь! Веди себя, как взрослый."
            hide m2 with dissolve
            show m6:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Лаааадно."
            hide m6 with dissolve
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Что тебе надо?"
            "Коварно усмехаясь, девочка ковыряла ножкой пол."
            characterchildren "Нууу, не знаю."
            hide m2 with dissolve
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Давай, как взрослый призрак. Придумай загадку, и, если я ее решу, оставляю книжку себе. А если нет, ее забираешь ты!"
            "Девочка заинтересованно и осторожно посмотрела в ответ."
            characterchildren "Ты поиграешь со мной?"
            character "Во что?"
            characterchildren "Хочу в прятки!!!! Прятки! ПРЯТКИ!!!!"
            character "Хорошо-хорошо! Прячься."
            characterchildren "Ну нет! Я большая! Ты меня тут быстро найдешь! Я спрячу твою книгу!  Отвернись."
            "[player_name], понимая, что у него нет выбора, вздохнул и отвернулся."
            characterchildren "Все! Поворачивайся!"
            "Найдите в комнате книгу и нажмите на нее."
            hide m1
            hide t1
            hide ghost_children
            with dissolve
            label scene_pht_1_m:
                window hide
                $ return_label = "scene_pht_1_timeout_m"  # Куда перейти при тайм-ауте
                show screen choice_timer(15)             # Таймер на 15 секунд
                call screen find_item_game_1
                if _return == "found":
                    hide screen choice_timer
                $ book_rest += 1
                window show
                show rest with fade:
                    zoom 1.0 xalign 0 yalign 0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                "Вы нашли книгу, теперь вы можете ее забрать."
                hide rest with dissolve
                show ghost_children:
                    size (1280, 720)
                    fit "fill"
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterchildren "Ууууууу вредина! Я думала, не заметишь! Ну и проваливай! Не хочу больше с тобой играть. Не интересно."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Молодец, мой друг. Здесь нам больше нечего делать."
                hide t1
                hide ghost_children
                with dissolve
                if attack == 1:
                    jump scene37_2_m_2
                else:
                    jump scene37_2_m_1
                jump scene38
                label scene_pht_1_timeout_m:
                    show ghost_children:
                        size (1280, 720)
                        fit "fill"
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterchildren "Ураааа! У тебя не вышло! Я забираю ее!"
                    characterchildren "А мне говорили: «она маленькая, ни на что не годна»! А я тебя обдурила!!!!"
                    "Девочка радостно скакала вокруг. И ужасно раздражала."
                    show t1:   
                        zoom 1.0 xalign 1.3 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    tmrz "Придется признать поражение."
                    "Вы потеряли одну книгу."
                    tmrz "Ничего, у нас еще есть возможность победить. Пойдем."
                    $ ghost += 1
                    "+ Призрак"
                    hide t1
                    hide ghost_children
                    with dissolve
                    if attack == 1:
                        jump scene37_2_m_2
                    else:
                        jump scene37_2_m_1
                    jump scene38
        elif book_rest == 0:
            show ghost_children:
                size (1280, 720)
                fit "fill"
                zoom 1.0 xalign 0.7 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterchildren "Поиграй со мной!"
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Я тороплюсь!"
            characterchildren "А у меня есть книжка!"
            "Девочка, захохотав, продемонстрировала ее."
            characterchildren "Если поиграешь со мной, то отдам ее тебе!"
            character "Я не маленький, чтобы играться. Отдай!"
            "[player_name] попробовал схватить девчонку, но та ловко вывернулась."
            characterchildren "Не догонишь! Не догонишь!"
            "Поддавшись на игру, [player_name] начал гоняться за вредным призраком."
            "Отбежав на достаточное расстояние, девочка развернулась и показала язык."
            character "А ну иди сюда, маленькая гадость!"
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "А ну стой!"
            "[player_name] почувствовал, что Климент Аркадьевич схватил его за шиворот, остановив беготню."
            tmrz "Она-то маленькая, а ты куда?"
            character "Сейчас я быстро ей ремня дам, если родители не воспитывали!"
            "Девочка стояла на безопасном расстоянии и продолжала корчить рожицы за спиной Климента Аркадьевича."
            tmrz "Остынь! Веди себя, как взрослый."
            hide m2 with dissolve
            show m6:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Лаааадно."
            hide m6 with dissolve
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Что тебе надо?"
            "Коварно усмехаясь,  девочка ковыряла ножкой пол."
            characterchildren "Нууу не знаю."
            character "Давай, как взрослый призрак. Придумай загадку, и, если я ее решу, оставляю книжку себе. А если нет, ее забираешь ты!"
            "Девочка заинтересованно и осторожно посмотрела в ответ."
            characterchildren "Ты поиграешь со мной?"
            hide m2 with dissolve
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Во что?"
            characterchildren "Хочу в прятки!!!! Прятки! ПРЯТКИ!!!!" 
            hide m1 with dissolve
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Хорошо-хорошо! Прячься."
            characterchildren "Ну нет! Я большая! Ты меня тут быстро найдешь! Я спрячу твою книгу!  Отвернись."
            "[player_name], понимая, что у него нет выбора, вздохнул и отвернулся."
            characterchildren "Все! Поворачивайся!"
            "Найдите в комнате книгу и нажмите на нее."
            hide m2
            hide t1
            hide ghost_children
            with dissolve
            label scene_pht_2_m:
                window hide
                $ return_label = "scene_pht_2_timeout_m"  # Куда перейти при тайм-ауте
                show screen choice_timer(15)             # Таймер на 15 секунд
                call screen find_item_game_1
                if _return == "found":
                    hide screen choice_timer
                $ book_rest += 1
                show rest with fade:
                    zoom 1.0 xalign 0 yalign 0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                window show
                $ reality += 1
                "Вы нашли книгу, теперь вы можете ее забрать. + Явь"
                hide rest with dissolve
                show ghost_children:
                    size (1280, 720)
                    fit "fill"
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterchildren "Ууууууу вредина! Я думала, не заметишь! Ну и проваливай! Не хочу больше с тобой играть. Не интересно."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Молодец, мой друг. Здесь нам больше нечего делать."
                hide t1
                hide ghost_children
                with dissolve
                if attack == 1:
                    jump scene37_2_m_2
                else:
                    jump scene37_2_m_1
                jump scene38
                label scene_pht_2_timeout_m:
                    show ghost_children:
                        size (1280, 720)
                        fit "fill"
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    window show
                    characterchildren "Ураааа! У тебя не вышло! Я забираю ее!"
                    characterchildren "А мне говорили: «она маленькая, ни на что не годна»! А я тебя обдурила!!!!"
                    "Девочка радостно скакала вокруг. И ужасно раздражала."
                    show t1:   
                        zoom 1.0 xalign 1.3 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    tmrz "Придется признать поражение."
                    "Вы потеряли одну книгу."
                    tmrz "Ничего, у нас еще есть возможность победить. Пойдем."
                    hide t1
                    hide ghost_children
                    with dissolve
                    if attack == 1:
                        jump scene37_2_m_2
                    else:
                        jump scene37_2_m_1
                    jump scene38
    elif gender == "G":
        "Фотостудия располагалась в доме на углу  Везенбергской улицы. На первом этаже находилась рюмочная, [player_name] с тоской вспомнила, что сейчас, в наше время, в этом доме есть кофейня."
        "Силы уже покидали в сражениях с призраками. И кофе бы совсем не помешал."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Всегда нравились подобные здания, где из кирпича на фасаде выложен рисунок, словно это вышивка."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Да, хитрый способ украсить здания без дополнительной скульптуры."
        character "Здесь находилась фотостудия? Она имела успех?"
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Конечно, рядом же два вокзала – места встреч и расставаний. Раньше не так просто было сделать фото, а сфотографироваться на память очень хотелось."
        character "Я помню, что вы любите фотографировать."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Конечно."
        character "Вам бы хотелось попасть в наше время? Теперь столько устройств для фотографии. И фотографировать теперь может буквально каждый."
        tmrz "Я всегда был убежден, что придет время, когда люди будут чаще бродить по лесам и полям не с ружьем, а с камерой фотографа за плечами."
        hide t1 with dissolve
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "И не затем, чтобы подшибить несчастную пичужку и лишь мимоходом, урывками полюбоваться на природу, а затем именно, чтобы любоваться природой и при случае унести с собой возможно художественное её воспроизведение."
        "Эта цитата действительно принадлежит Клименту Аркадьевичу Тимирязеву."
        character "Вы оказались правы."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Пойдем, мой друг. Познакомимся с фотостудией Агафонова."
        hide t1 
        hide g1 
        with dissolve
        scene 3back11 with fade:
            size (1280, 720)
            fit "fill"
        "Фотостудия была небольшой. Всюду стояло специальное оборудование."
        "[player_name] приблизилась к столу. Здесь лежал фотоальбом с различными фотографиями."
        "[player_name] осмотрела несколько снимков, и особенно ее привлекла фотография маленькой девочки. "
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Такие все суровые на фото. Совсем не улыбаются."
        show ghost_children:
            size (1280, 720)
            fit "fill"
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterchildren "Вот так?!"
        "Прямо перед столом появился призрак маленькой девочки. Она от уха до уха улыбнулась и, захохотав, стала бегать по комнате."
        "От неожиданности [player_name] отшатнулась от стола."
        hide ghost_children
        hide g1
        with dissolve
        if book_rest > 0: # >0
            show ghost_children:
                size (1280, 720)
                fit "fill"
                zoom 1.0 xalign 0.7 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            $ book_rest -= 1
            "[player_name] не заметила, как, воспользовавшись ее смятением, девочка выхватила из рук недавно найденную книгу, которую еще не спрятали в рюкзак."
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character " А ну отдай! Я ее честно отвоевала!"
            characterchildren "Не догонишь, не догонишь!"
            "Поддавшись на игру, [player_name] начала гоняться за вредным призраком."
            "Отбежав на достаточное расстояние, девочка развернулась и показала язык."
            character "А ну иди сюда, маленькая гадость!"
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "А ну стой!"
            "[player_name] почувствовала, что Климент Аркадьевич схватил ее за шиворот, остановив беготню."
            tmrz "Она-то маленькая, а ты куда?"
            character "Сейчас я быстро ей ремня дам, если родители не воспитывали!"
            "Девочка стояла на безопасном расстоянии и продолжала корчить рожицы за спиной Климента Аркадьевича."
            tmrz "Остынь! Веди себя, как взрослая."
            hide g2 with dissolve
            show g6:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Лаааадно."
            hide g6 with dissolve
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Что тебе надо?"
            "Коварно усмехаясь, девочка ковыряла ножкой пол."
            characterchildren "Нууу, не знаю."
            hide g2 with dissolve
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Давай, как взрослый призрак. Придумай загадку, и, если я ее решу, оставляю книжку себе. А если нет, ее забираешь ты!"
            "Девочка заинтересованно и осторожно посмотрела в ответ."
            characterchildren "Ты поиграешь со мной?"
            character "Во что?"
            characterchildren "Хочу в прятки!!!! Прятки! ПРЯТКИ!!!!"
            character "Хорошо-хорошо! Прячься."
            characterchildren "Ну нет! Я большая! Ты меня тут быстро найдешь! Я спрячу твою книгу!  Отвернись."
            "[player_name], понимая, что у нее нет выбора, вздохнула и отвернулась."
            characterchildren "Все! Поворачивайся!"
            "Найдите в комнате книгу и нажмите на нее."
            hide g1
            hide t1
            hide ghost_children
            with dissolve
            label scene_pht_1_g:
                window hide
                $ return_label = "scene_pht_1_timeout_g"  # Куда перейти при тайм-ауте
                show screen choice_timer(15)             # Таймер на 15 секунд
                call screen find_item_game_1
                if _return == "found":
                    hide screen choice_timer
                $ book_rest += 1
                window show
                $ reality += 1
                show rest with fade:
                    zoom 1.0 xalign 0 yalign 0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                "Вы нашли книгу, теперь вы можете ее забрать. + Явь"
                hide rest with dissolve
                show ghost_children:
                    size (1280, 720)
                    fit "fill"
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterchildren "Ууууууу вредина! Я думала, не заметишь! Ну и проваливай! Не хочу больше с тобой играть. Не интересно."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Молодец, мой друг. Здесь нам больше нечего делать."
                hide t1
                hide ghost_children
                with dissolve
                if attack == 1:
                    jump scene37_2_g_2
                else:
                    jump scene37_2_g_1
                jump scene38
                label scene_pht_1_timeout_g:
                    show ghost_children:
                        size (1280, 720)
                        fit "fill"
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterchildren "Ураааа! У тебя не вышло! Я забираю ее!"
                    characterchildren "А мне говорили: «она маленькая, ни на что не годна»! А я тебя обдурила!!!!"
                    "Девочка радостно скакала вокруг. И ужасно раздражала."
                    $ ghost += 1
                    "+ Призрак"
                    show t1:   
                        zoom 1.0 xalign 1.3 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    tmrz "Придется признать поражение."
                    "Вы потеряли одну книгу."
                    tmrz "Ничего, у нас еще есть возможность победить. Пойдем."
                    hide t1
                    hide ghost_children
                    with dissolve
                    if attack == 1:
                        jump scene37_2_g_2
                    else:
                        jump scene37_2_g_1
                    jump scene38
        elif book_rest == 0:
            show ghost_children:
                size (1280, 720)
                fit "fill"
                zoom 1.0 xalign 0.7 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterchildren "Поиграй со мной!"
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Я тороплюсь!"
            characterchildren "А у меня есть книжка!"
            "Девочка, захохотав, продемонстрировала ее."
            characterchildren "Если поиграешь со мной, то отдам ее тебе!"
            character "Я не маленькая, чтобы играться. Отдай!"
            "[player_name] попробовала схватить девчонку, но та ловко вывернулась."
            characterchildren "Не догонишь! Не догонишь!"
            "Поддавшись на игру, [player_name] начала гоняться за вредным призраком."
            "Отбежав на достаточное расстояние, девочка развернулась и показала язык."
            character "А ну иди сюда, маленькая гадость!"
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "А ну стой!"
            "[player_name] почувствовала, что Климент Аркадьевич схватил ее за шиворот, остановив беготню."
            tmrz "Она-то маленькая, а ты куда?"
            character "Сейчас я быстро ей ремня дам, если родители не воспитывали!"
            "Девочка стояла на безопасном расстоянии и продолжала корчить рожицы за спиной Климента Аркадьевича."
            tmrz "Остынь! Веди себя, как взрослая."
            hide g2 with dissolve
            show g6:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Лаааадно."
            hide g6 with dissolve
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Что тебе надо?"
            "Коварно усмехаясь,  девочка ковыряла ножкой пол."
            characterchildren "Нууу не знаю."
            character "Давай, как взрослый призрак. Придумай загадку, и, если я ее решу, оставляю книжку себе. А если нет, ее забираешь ты!"
            "Девочка заинтересованно и осторожно посмотрела в ответ."
            characterchildren "Ты поиграешь со мной?"
            hide g2 with dissolve
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Во что?"
            characterchildren "Хочу в прятки!!!! Прятки! ПРЯТКИ!!!!" 
            hide g1 with dissolve
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Хорошо-хорошо! Прячься."
            characterchildren "Ну нет! Я большая! Ты меня тут быстро найдешь! Я спрячу твою книгу!  Отвернись."
            "[player_name], понимая, что у нее нет выбора, вздохнула и отвернулась."
            characterchildren "Все! Поворачивайся!"
            "Найдите в комнате книгу и нажмите на нее."
            hide g2
            hide t1
            hide ghost_children
            with dissolve
            label scene_pht_2_g:
                window hide
                $ return_label = "scene_pht_2_timeout_g"  # Куда перейти при тайм-ауте
                show screen choice_timer(15)             # Таймер на 15 секунд
                call screen find_item_game_1
                if _return == "found":
                    hide screen choice_timer
                $ book_rest += 1
                show rest with fade:
                    zoom 1.0 xalign 0 yalign 0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                window show
                "Вы нашли книгу, теперь вы можете ее забрать."
                hide rest with dissolve
                show ghost_children:
                    size (1280, 720)
                    fit "fill"
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterchildren "Ууууууу вредина! Я думала, не заметишь! Ну и проваливай! Не хочу больше с тобой играть. Не интересно."
                show t1:   
                    zoom 1.0 xalign 1.3 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                tmrz "Молодец, мой друг. Здесь нам больше нечего делать."
                hide t1
                hide ghost_children
                with dissolve
                if attack == 1:
                    jump scene37_2_g_2
                else:
                    jump scene37_2_g_1
                jump scene38
                label scene_pht_2_timeout_g:
                    show ghost_children:
                        size (1280, 720)
                        fit "fill"
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    window show
                    characterchildren "Ураааа! У тебя не вышло! Я забираю ее!"
                    characterchildren "А мне говорили: «она маленькая, ни на что не годна»! А я тебя обдурила!!!!"
                    "Девочка радостно скакала вокруг. И ужасно раздражала."
                    show t1:   
                        zoom 1.0 xalign 1.3 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    tmrz "Придется признать поражение."
                    "Вы потеряли одну книгу."
                    tmrz "Ничего, у нас еще есть возможность победить. Пойдем."
                    hide t1
                    hide ghost_children
                    with dissolve
                    if attack == 1:
                        jump scene37_2_g_2
                    else:
                        jump scene37_2_g_1
                    jump scene38

# Мы исследовали все, пора двигаться дальше
label scene38:
    label scene_ised: 
        if gender == "M":
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Мой друг, крепись. Осталось совсем немного."
            show m1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Я уже начинаю привыкать. И, если честно, даже сочувствовать призракам."
            tmrz "Твоя доброта похвальна. Но ты должен бороться за свой мир. Нельзя оглядываться назад, нужно двигаться дальше, сохраняя при том память о прошлом."
            tmrz "Думаю, настало время посетить Балтийский вокзал."
            character "Мне даже не терпится узнать, кого мы там встретим. Меня уже сложно удивить."
            tmrz "О, поверь мне, ты будешь под впечатлением."
            hide m1
            hide t1
            with dissolve
            jump scene39
        elif gender == "G":
            show t1:   
                zoom 1.0 xalign 1.3 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            tmrz "Мой друг, крепись. Осталось совсем немного."
            show g1:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Я уже начинаю привыкать. И, если честно, даже сочувствовать призракам."
            tmrz "Твоя доброта похвальна. Но ты должна бороться за свой мир. Нельзя оглядываться назад, нужно двигаться дальше, сохраняя при том память о прошлом."
            tmrz "Думаю, настало время посетить Балтийский вокзал."
            character "Мне даже не терпится узнать, кого мы там встретим. Меня уже сложно удивить."
            tmrz "О, поверь мне, ты будешь под впечатлением."
            hide g1
            hide t1
            with dissolve
            jump scene39

# 5 серия
label scene39:
    window hide
    with None
    # кат - сцена
    scene seria5 with fade:
        size (1280, 720)
        fit "fill"
    $ renpy.pause(delay=4.0, hard=True)
    scene 4back1 with fade:
        size (1280, 720)
        fit "fill"
    stop music fadeout 2.0
    play music imperator fadein 2.0 loop if_changed
    if gender == "M":
        "[player_name] и Климент Аркадьевич остановились на площади Балтийского вокзала. Как и в современности, в призрачном мире тоже было довольно людно, если так можно сказать о привидениях."
        "Тени людей вышагивали туда-сюда, имитируя какие-то дела, хотя их лица оставались безучастными."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Что скажешь, мой друг?"
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Мы в Петергоф поедем?"
        tmrz "О нет, не хватало нам призраков Петергофа."
        character "Там тоже есть призраки?"
        tmrz "Еще какие! Я, конечно, в тебя верю, но все-таки оно не стоит того."
        tmrz "Давай подойдем поближе к Балтийскому вокзалу."
        hide t1 with dissolve
        scene 4back2 with fade:
            size (1280, 720)
            fit "fill"
        show t2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Видишь часы на окошке?"
        character "Ага."
        tmrz "Это часы фирмы \"Павел Буре\", которая в свое время была на рынке вне конкуренции. В 1899 году компания получила звание «Поставщик Двора Его Императорского Величества»."
        tmrz "В твое время они все еще работают, в ХХ веке их перевели на электрическое питание."
        character "Не знал, что они такие стар…кхем… ценные."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Если это тебя не удивило, тогда посмотри вон туда."
        hide t1 with dissolve
        hide m1 with dissolve
        scene 4back1 with fade:
            size (1280, 720)
            fit "fill"
        "Из левого крыла Балтийского вокзала вышел человек, которого сразу можно было узнать, но поверить в то, что видишь его, было невозможно."
        show ghost_nikolai:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characternikolay2 "…"
        "[player_name] потерял дар речи. Видимо государь Российской Империи вместе с семьей вернулся из Петергофа в Петроград."
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "…"
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Вижу, ты под впечатлением, мой друг."
        character "Не каждый день я встречаю представителей семьи Романовых."
        characternikolay2 "…"
        hide m7 with dissolve
        hide ghost_nikolai with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Только сейчас заметил: а где центральный вход на вокзал?"
        tmrz "Раньше входа было два:  справа — для простого люда, а тот, что слева, принадлежал императорской семье, кстати, нам туда."
        character "Климент Аркадьевич, мы же не принадлежим к «августейшим особам». Как мы туда пройдем?"
        tmrz "Подключай смекалку, мой друг."
        "Климент Аркадьевич выдвинулся в сторону Балтийского вокзала. [player_name], вздохнув, нехотя, отправился за ним."
        show ghost_policia:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterpolicia "Стой! Кто тут!"
        hide ghost_policia with dissolve
        hide m2 with dissolve
        hide t1 with dissolve
        label scene39_0_m:
            menu:
                character ""
                "Мы на экскурсию":
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "+ Призрак"
                    show ghost_policia:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpolicia "Вы что, с ума сошли? Какая экскурсия? А ну прочь!"
                    "Вам не удалось обойти полицейского, попробуйте еще раз."
                    jump scene39_0_m
                    hide ghost_policia with dissolve
                "Мы инженеры-механики":
                    show ghost_policia:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpolicia "Ну наконец-то, вас уже заждались. Проходите быстрее."
                    if rightornot == 0:
                        $ reality += 1
                        $ rightornot += 1
                        "+ Явь"
                    "Вам удалось обойти полицейского."
                    hide ghost_policia with dissolve
                    $ rightornot == 0
                    "Тимирязев и [player_name] переглянулись и поспешили вперед."
                    jump scene40
                "Простите, заблудились":
                    show ghost_policia:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpolicia "А ну прочь отсюда! Вам нельзя здесь находиться."
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "+ Призрак"
                    "Вам не удалось обойти полицейского, попробуйте еще раз."
                    hide ghost_policia with dissolve
                    jump scene39_0_m
        jump scene40
    elif gender == "G":
        "[player_name] и Климент Аркадьевич остановились на площади Балтийского вокзала. Как и в современности, в призрачном мире тоже было довольно людно, если так можно сказать о привидениях."
        "Тени людей вышагивали туда-сюда, имитируя какие-то дела, хотя их лица оставались безучастными."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Что скажешь, мой друг?"
        show g1:
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Мы в Петергоф поедем?"
        tmrz "О нет, не хватало нам призраков Петергофа."
        character "Там тоже есть призраки?"
        tmrz "Еще какие! Я, конечно, в тебя верю, но все-таки оно не стоит того."
        tmrz "Давай подойдем поближе к Балтийскому вокзалу."
        hide t1 with dissolve
        scene 4back2 with fade:
            size (1280, 720)
            fit "fill"
        show t2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Видишь часы на окошке?"
        character "Ага."
        tmrz "Это часы фирмы \"Павел Буре\", которая в свое время была на рынке вне конкуренции. В 1899 году компания получила звание «Поставщик Двора Его Императорского Величества»."
        tmrz "В твое время они все еще работают, в ХХ веке их перевели на электрическое питание."
        character "Не знала, что они такие стар…кхем… ценные."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Если это тебя не удивило, тогда посмотри вон туда."
        hide t1 with dissolve
        hide g1 with dissolve
        scene 4back1 with fade:
            size (1280, 720)
            fit "fill"
        "Из левого крыла Балтийского вокзала вышел человек, которого сразу можно было узнать, но поверить в то, что видишь его, было невозможно."
        show ghost_nikolai:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characternikolay2 "…"
        "[player_name] потеряла дар речи. Видимо государь Российской Империи вместе с семьей вернулся из Петергофа в Петроград."
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "…"
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Вижу, ты под впечатлением, мой друг."
        character "Не каждый день я встречаю представителей семьи Романовых."
        characternikolay2 "…"
        hide g7 with dissolve
        hide ghost_nikolai with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Только сейчас заметила: а где центральный вход на вокзал?"
        tmrz "Раньше входа было два:  справа — для простого люда, а тот, что слева, принадлежал императорской семье, кстати, нам туда."
        character "Климент Аркадьевич, мы же не принадлежим к «августейшим особам». Как мы туда пройдем?"
        tmrz "Подключай смекалку, мой друг."
        "Климент Аркадьевич выдвинулся в сторону Балтийского вокзала. [player_name], вздохнув, нехотя, отправилась за ним."
        show ghost_policia:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterpolicia "Стой! Кто тут!"
        hide ghost_policia with dissolve
        hide g2 with dissolve
        hide t1 with dissolve
        label scene39_0_g:
            menu:
                character ""
                "Мы на экскурсию":
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "+ Призрак"
                    show ghost_policia:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpolicia "Вы что, с ума сошли? Какая экскурсия? А ну прочь!"
                    "Вам не удалось обойти полицейского, попробуйте еще раз."
                    jump scene39_0_g
                    hide ghost_policia with dissolve
                "Мы инженеры-механики":
                    show ghost_policia:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpolicia "Ну наконец-то, вас уже заждались. Проходите быстрее."
                    if rightornot == 0:
                        $ reality += 1
                        $ rightornot += 1
                        "+ Явь"
                    "Вам удалось обойти полицейского."
                    hide ghost_policia with dissolve
                    $ rightornot == 0
                    "Тимирязев и [player_name] переглянулись и поспешили вперед."
                    jump scene40
                "Простите, заблудились":
                    show ghost_policia:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpolicia "А ну прочь отсюда! Вам нельзя здесь находиться."
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "+ Призрак"
                    "Вам не удалось обойти полицейского, попробуйте еще раз."
                    hide ghost_policia with dissolve
                    jump scene39_0_g
        jump scene40

label scene40:
    scene 4back3 with fade:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        "Перед ними стоял темно-синий, блестящий вагон императорской семьи."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "У тебя совсем немного времени, чтобы найти последнюю книгу. Главное, будь осторожен и не привлекай внимания полицейского."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я постараюсь."
        hide m1 with dissolve
        hide t1 with dissolve
        scene 4back4 with fade:
            size (1280, 720)
            fit "fill"
        stop music fadeout 2.0
        play music haspit fadein 2.0 loop if_changed
        "Тимирязев не стал заходить. Впрочем, [player_name] уже привык к тому, что все испытания придется проходить самостоятельно."
        "Но без Климента Аркадьевича стало безумно одиноко. Кроме того, непонятно, где искать книгу."
        "Богатые интерьеры невольно заставляли любоваться ими. [player_name] постоянно напоминал себе о том, что нужно сосредоточиться и не допустить ошибок, но невозможно было не отвлекаться на подобную красоту."
        "В наше время, к сожалению, императорские вагоны сохранились только заграницей. Но в музеях можно еще увидеть макеты и даже VR-проекты. Однако [player_name] не успел с ними познакомиться."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Придется действовать наугад."
        hide m1 with dissolve
        label scene40_0_m:
            $ return_label = "scene40_0_m_timeout"        
            show screen choice_timer(5)
            menu:
                "Идти обычным шагом":
                    label scene40_0_m_timeout:
                        hide screen choice_timer
                        if rightornot == 0:
                            $ ghost += 1
                            $ rightornot += 1
                            "Вы выбрали неверную тактику и были замечены. +Призрак"
                        else:
                            "Вы выбрали неверную тактику и были замечены."
                        show ghost_policia:
                            zoom 1.0 xalign 0.7 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        characterpolicia "А ну стой! Что ты делаешь в интерьерах? Это кем себя нужно было возомнить? Сомневаюсь, что ты инженер. Хочешь что-то украсть?"
                        "Вас арестовали. Попробуйте еще раз. + Призрак"
                        hide ghost_policia with dissolve
                        jump scene40_0_m
                "Пробежать":    
                    hide screen choice_timer        
                    "По вагону раздался громкий топот ног. На шум прибежал полицейский."
                    show ghost_policia:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpolicia "Куда бежишь? Что-то украл?"
                    show m5:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Нет, просто тороплюсь."
                    characterpolicia "Очень странно себя ведешь, лучше обыскать тебя! Пройдем со мной, ты арестован."
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вы выбрали неверную тактику и были замечены. +Призрак"
                    else:
                        "Вы выбрали неверную тактику и были замечены."
                    hide m5 with dissolve
                    hide ghost_policia with dissolve
                    jump scene40_0_m
                "Пройти тихо":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ reality += 1
                        $ rightornot += 1
                        "Вы выбрали верную тактику. + Явь"
                    else:
                        "Вы выбрали верную тактику."
                    $ rightornot == 0
        "Пока что удавалось оставаться незамеченным."
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Интересно, что в дореволюционные времена мне могло грозить за такую дерзость? Надеюсь, не расстрел."
        "От этой мысли стало немного не по себе. Вообще, здесь все было пропитано тяжелой атмосферой. Может быть, из-за тяжелой судьбы Романовых стены сами по себе отдавали скорбью."
        "Не смотря на то, что призраков не было, чувство какого-то присутствия не покидало бы любого, кто осмелился сюда зайти."
        hide m2 with dissolve
        scene 4back5 with fade:
            size (1280, 720)
            fit "fill"
        "Новое помещение было похоже на столовую. Здесь стояла роскошная мебель рядом с длинным обеденным столом. На нем красовались свечи с мрачным синим пламенем."
        "Захотелось коснуться огонька рукой. Почему-то он притягивал к себе."
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Кажется, словно пламя не должно обжечь…"
        "[player_name] потянулся рукой…"
        hide m5 with dissolve
        label scene40_1_m:
            $ return_label = "scene40_1_m_timeout"        
            show screen choice_timer(3)
            menu:
                "Коснуться…":
                    label scene40_1_m_timeout:
                        hide screen choice_timer
                        "[player_name] не смог сопротивляться желанию. Протянув руку, он провел ею над пламенем."
                        "Оно оказалось дико горячим. Охватив ладонь, пламя жестоко жглось."
                        show m7:   
                            zoom 1.0 xalign -0.3 yalign 0.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        character "Больно!!!"
                        "[player_name] невольно задел подсвечник и столкнул его со стола. Огонь перекинулся на стол и занавески."
                        character "Нет! Нет, пожалуйста!!!!"
                        show ghost_policia:
                            zoom 1.0 xalign 0.7 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        characterpolicia "Что здесь происходит?! А ну иди сюда, вредитель!!!"
                        if rightornot == 0:
                            $ ghost += 1
                            $ rightornot += 1
                            "Вас поймали! Попробуйте еще раз! + Призрак."
                        else:
                            "Вас поймали! Попробуйте еще раз!"
                        hide ghost_policia with dissolve
                        hide m7 with dissolve
                        jump scene40_1_m
                "Отвернуться…":
                    hide screen choice_timer
                    show m1:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Не стоит поддаваться призрачному зову. Вдруг это снова какая-нибудь русалка…"
                    if rightornot == 0:
                            $ ghost += 1
                            $ rightornot += 1
                            "Вам удалось избежать ловушки. +Явь"
                    else:
                        "Вам удалось избежать ловушки."
                    $ rightornot == 0
                    hide m1 with dissolve
        
        "[player_name] осмотрелся. Нужно было понять, где могли спрятать книгу. Однако никаких подсказок не наблюдалось. Может быть, где-то был тайник."
        "В глубине столовой висело зеркало. Во многих фильмах за ним скрывались ниши для хранения важных документов или ценных бумаг."
        "Других вариантов не наблюдалось, и [player_name] уверенно шагнул навстречу отражению."
        "Помня про осторожность, он не спешил касаться предмета. Сосредоточившись на раме, [player_name] не сразу заметил, что с отражением что-то не так и, присмотревшись, едва ли не вскрикнул."
        show ghost_m:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что происходит?!"
        "Едва сдержав крик, [player_name] замер, не веря собственным глазам."
        characterotragenie "Я всего лишь то, что ты не желаешь принимать в себе."
        hide m7 with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Нет, ты дурацкая шутка призраков…"
        characterotragenie "О нет, поверь мне. В каждом есть сторона, которую не хочется признавать в себе."
        character "Я справлюсь и вернусь в свой мир."
        characterotragenie "Я так не думаю… Но, забавы ради, я даже отдам тебе последнюю книгу, и мы увидим, сможешь ли ты выбраться отсюда."
        character "Хватит болтать. Давай сюда и я пойду."
        characterotragenie "Неужели ты думаешь, что это будет так легко."
        "Было странно вести диалог с зеркалом, в котором ты сам себе давал ответы."
        character "Хватит играть со мной! Или верни книгу, или я сейчас разобью этот поломанный телевизор."
        "[player_name] услышал свой собственный зловещий смех от пугающей копии."
        characterotragenie "Давай посмотрим, как ты усвоил урок своего путешествия. Готов держать ответ?"
        hide m2 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я готов."
        characterotragenie "Тогда первый вопрос!"
        characterotragenie "Почему улицу назвали Везенбергской?"
        hide m1 with dissolve
        hide ghost_m with dissolve
        menu:
            "По городу":
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "В Нарвской части Санкт-Петербурга улицы для простоты ориентирования называли как города в  Прибалтике. Эта улица получила название по эстонскому городу Везенбергу, сейчас он называется Раквере."
                show ghost_m:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Ишь ты! Подготовился."
                $ reality += 1
                $ zagadkaotragenie += 1
                "Верно. + Явь"
                hide ghost_m with dissolve
                hide m2 with dissolve
            "По Замку":
                show ghost_m:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "По какому Замку?"
                character "Откуда я знаю? По красивому."
                characterotragenie "Какой глупый ответ."
                $ ghost += 1
                "Не верно. + Призрак"
                hide ghost_m with dissolve
                hide m2 with dissolve
            "По фамилии":
                show ghost_m:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "По чьей фамилии?"
                character "Везенберга."
                characterotragenie "Очень смешно. Ты ошибся."
                $ ghost += 1
                "Не верно. + Призрак"
                hide ghost_m with dissolve
                hide m2 with dissolve
        show ghost_m:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterotragenie "Следующий вопрос."
        characterotragenie "Про Везенбергскую улицу поговорили, а вот соседнюю Лейхтенбергскую почему так назвали?"
        "[player_name] судорожно вспоминал все, что помнит. Сейчас улица называется Розенштейна. Но чем это может помочь? Ничем. Придется поразмыслить…"
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Улицу назвали…"
        hide m5 with dissolve
        hide ghost_m with dissolve
        menu:
            "По городу":
                show ghost_m:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Это что за город такой?"
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Лейхтенберг."
                characterotragenie "Хорошая попытка, но ты ошибся."
                $ ghost += 1
                "Не верно. + Призрак"
                hide m2 with dissolve
                hide ghost_m with dissolve
            "По фамилии":
                show ghost_m:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Какой-такой фамилии?"
                show m2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Максимилиана Лейхтенбергского, мужа Марии Николаевны Романовой, военного и государственного деятеля."
                $ reality += 1
                $ zagadkaotragenie += 1
                "Верно. + Явь"
                hide m2 with dissolve
                hide ghost_m with dissolve
            "По названию фабрики":
                show ghost_m:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Какой фабрики?"
                show m5:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Ну одной из…"
                characterotragenie "Из чего?"
                character "Из тех, что находились тут."
                characterotragenie "Так и скажи, что не знаешь, зачем выдумывать небылицы?"
                $ ghost += 1
                "Не верно. + Призрак"
                hide m5 with dissolve
                hide ghost_m with dissolve
        show ghost_m:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterotragenie "Следующий вопрос!"
        characterotragenie "Хватит вопросов по Везенбергскому кварталу… Давай просто проверим твои знания. Раз мы находимся на железнодорожном вокзале, то и вопрос будет близкий по теме."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Слушаю."
        characterotragenie "Какую железную дорогу проложили первой в России?"
        hide m1 with dissolve
        hide ghost_m with dissolve
        menu:
            "Царскосельскую":
                show m5:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Царскосельская железная дорога — первая железная дорога общего пользования в России."
                $ reality += 1
                $ zagadkaotragenie += 1
                "Верно. + Явь"
                show ghost_m:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Ну надо же… угадал."
                hide ghost_m with dissolve
                hide m5 with dissolve
            "Николаевскую":
                show ghost_m:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Это всего лишь третья по счёту железная дорога в Российской империи."
                $ ghost += 1
                "Не верно. + Призрак"
                hide ghost_m with dissolve
            "Петергофскую":
                show ghost_m:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Ты ошибся. Не смотря на безумно интересную и своеобразную историю своего появления, Петергофская железная дорога не была первой."
                $ ghost += 1
                "Не верно. + Призрак"
                hide ghost_m with dissolve
        
        if zagadkaotragenie >= 2:
            "Отражение злобно оскалилось."
            show ghost_m:
                zoom 1.0 xalign 0.7 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterotragenie "Наплевать на твою смелость и на правильные ответы. Ты сдашься и останешься здесь с призраками!"
            show m2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Как бы не так! Отдавай книгу и помалкивай. Я вернусь в реальный мир!"
            if architect == 1:
                "Вы учитесь на архитектора."
                character "Стану архитектором, напишу большой труд об исчезнувших зданиях Везенбергского квартала, построю НОВЫЕ изящные дома, которые будут заселять НОВЫЕ люди. Они будут творить НОВУЮ историю! Квартал расцветет и станет ярче, благороднее."
                character "У Везенбергского квартала есть будущее! И его построим мы – люди, сохранив наследие прошлого."
            elif botanist == 1:
                "Вы учитесь на ботаника."
                character "Я стану ученым! Буду гордо нести наследие Климента Аркадьевича Тимирязева. Я не только помогу нашей библиотеке сохранить это гордое имя, но и приду сам читать в нее лекции."
                "Мы создадим центр притяжения лучших умов города. И вместе сделаем этот самобытный квартал еще лучше!"
            elif journalist == 1:
                "Вы учитесь на журналиста."
                character "Когда вернусь в реальный мир, сделаю репортаж о Везенбергском квартале. Я расскажу про его прекрасное прошлое, самобытное, порой темное, но при этом и яркое. И я расскажу о будущем. О том будущем, которое мы сможем построить здесь сами."
                character "Я расскажу о том, как важно сохранить то хорошее, что здесь есть и приумножить его. Я не дам забыть о прошлом, но попробую сделать шаг к прекрасному будущему."
            elif archaeologist == 1:
                "Я― будущий археолог! В моем мире я смогу стать тем, кто глубже изучит историю Везенбергского квартала и откроет все его тайны миру. Я подключу историков своего факультета, и вместе мы сделаем эти улицы и дома самым интересным краеведческим феноменом."
                "Возможно, тогда мир призраков перестанет так злиться на нас, на людей. Ведь мы сделаем так, чтобы никто не был забыт. Этот квартал уникален, и его история должна продолжаться."
            characterotragenie "Пока только обещания. Держи свою книгу и иди прочь! Это было твое последнее испытание. Ты должен был заглянуть себе в глаза и понять, достоин ли ты идти дальше своим путем."
            hide m2 with dissolve
            show m1:  
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "И как, достоин?"
            "Призрак в зеркале зловеще усмехнулся."
            characterotragenie "Скоро поймешь все сам. А пока, забери свою последнюю книгу."
            show misticPeter with fade:
                zoom 1.0 xalign 0 yalign 0
                alpha 0.0
                easein 0.3 alpha 1.0
            $ book_misticPeter += 1
            "Вы получили книгу «Мистический Петербург»."
            hide misticPeter with dissolve
            character "Прощай. Мы больше не увидимся."
            characterotragenie "Посмотрим."
            "Однако от этой встречи осталось неприятное послевкусие."
            hide m1 with dissolve
            hide ghost_m with dissolve
        elif zagadkaotragenie <= 1:
            show m1:  
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            show ghost_m:
                zoom 1.0 xalign 0.7 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterotragenie "Надеюсь, ты убедился, что твоих знаний недостаточно, чтобы так задирать нос, выставляя себя спасителем квартала."
            characterotragenie "Как ты собираешься нести ответственность за свой мир, если сам за себя ответить не можешь?"
            character "Знаешь, важно увидеть ошибку, чтобы суметь ее избежать в будущем. Это еще не конец игры! Я вернусь в свой мир."
            "Кто знает, может быть, [player_name] и прав."
            characterotragenie "Книга останется со мной. Ступай. Еще встретимся."
            character "Надеюсь, что нет."
            "Однако уверенность, к несчастью, испарялась."
            hide ghost_m with dissolve
            hide m1 with dissolve
        
        scene 4back1 with fade:
            size (1280, 720)
            fit "fill"
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Ты как, мой друг?"
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Случилась не самая приятная встреча."
        tmrz "Что ж, есть и приятные новости. Наш путь практически окончен. У нас осталось совсем немного времени, и мы узнаем, принесут ли плоды наши усилия."
        character "И что теперь мне делать?"
        tmrz "Теперь, я думаю, ты заслужил отдых."
        hide m2 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Отдых? Я думал, что мы здесь не за этим."
        tmrz "Все, что мы могли сделать, уже сделано – сражение с призраками, поиск книг. Теперь осталось дождаться, чтобы время снова соединилось в одну линию. И мы увидим, что получилось."
        character "И куда же мы теперь?"
        tmrz "Ты когда-нибудь был в Балтийских банях?"
        hide m1 with dissolve
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Нет."
        tmrz "Самое время посетить."
        hide m5 with dissolve
        hide t1 with dissolve

        scene 4back6 with fade:
            size (1280, 720)
            fit "fill"
        stop music fadeout 2.0
        play music bany fadein 2.0 loop if_changed
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Перед тобой Балтийские бани. Здесь можно было не только попариться и поплавать в бассейне, но и пройти курс лечебных процедур, лечебный массаж, циркулярный и восходящий душ. Здесь работали квалифицированные врачи из 81-й поликлиники Октябрьского района."
        tmrz "После революции, когда доходные дома превратились в коммунальные квартиры, существовал ряд бытовых проблем, в том числе отсутствие в домах ванных. Поэтому бани были спасением."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Не знал, что они такие интересные. Со стороны выглядят сурово."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Предлагаю познакомиться поближе, ступай. Тебе нужен отдых."
        character "А вы?"
        tmrz "Здесь наши пути расходятся. Спасибо тебе, это было увлекательное путешествие."
        hide m1 with dissolve
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что? Почему? "
        hide m7 with dissolve
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Значит, я вас больше не увижу?"
        tmrz "Мой друг, если наш план удастся, то ты всегда можешь прийти в библиотеку им. К.А. Тимирязева. Ты не увидишь меня, но почувствуешь, что я рядом и поддерживаю все твои благие начинания."
        tmrz "Я в тебя верю!"
        "[player_name] уже успел привыкнуть к добрым советам Климента Аркадьевича. Столько еще было вопросов, которые хотелось задать. И прощаться было тяжело. Но так было правильно."
        "[player_name] точно знал, что есть злые призраки, есть добрые, а есть Климент Аркадьевич, который не смотря ни на что продолжает нести свет как в призрачный мир, так и в реальный."
        character "Спасибо вам. Я никогда вас не забуду."
        tmrz "Ты навсегда останешься моим хорошим другом!"
        "Больше не хотелось говорить. [player_name] смело отправился исследовать последнее призрачное пространство."
        hide m6
        hide t1
        with dissolve
        scene 4back7 with fade:
            size (1280, 720)
            fit "fill"
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Мммм… приятно пахнет деревом."
        show ghost_doctor:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterdoctor "Добрый день, скажите, что вас беспокоит, и я подберу для вас процедуры."
        character "…"
        hide ghost_doctor with dissolve
        hide m1 with dissolve
        menu:
            "Спину ломит, весь день на ногах":
                show ghost_doctor:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterdoctor "Тогда распишу для вас курс массажей. А пока можете отправляться попариться в баню - стимуляция кровотока позволяет мышцам быстрее восстанавливаться после длительных нагрузок."
                hide ghost_doctor with dissolve
            "Мне очень тоскливо":
                show ghost_doctor:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterdoctor "Предлагаю вам отправиться на банные процедуры. При погружении в тёплую и влажную среду организм выделяет эндорфины, что вызывает ощущение радости и приятное состояние эйфории. Вам станет легче."
                hide ghost_doctor with dissolve
            "Не знаю, просто хочется наконец-то спокойствия":
                show ghost_doctor:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterdoctor "Предлагаю вам отправиться на банные процедуры. При погружении в тёплую и влажную среду организм выделяет эндорфины, что вызывает ощущение радости и приятное состояние эйфории. Вам станет легче."
                hide ghost_doctor with dissolve

        show m8:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что ж, приятное окончание длинного и тяжелого дня."
        "Работники бани выдали полотенце, халат и обувь. [player_name] принял душ и отправился в парную. Воздух наполнился приятной теплой тяжестью. Действительно казалось, что эта процедура создает какой-то волшебный эффект."
        "Очень захотелось спать. День был такой напряженный. Весь мир перевернулся с ног на голову. И так хотелось домой – в теплую постель. Хотелось выпить ароматного какао и забыться сном."
        "Глаза сами собой стали закрываться…"
        hide m8 with dissolve
        
        # Плохая либо Средняя
        if ghost >= 23 and book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest < 6:
            jump sceneplox
        elif ghost >= 23 and book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest == 6:
            jump scenegood
        
        # Средняя либо Отличная
        if ghost >= 10 and ghost <= 22 and book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest < 3:
            jump scenegood
        elif ghost >= 10 and ghost <= 22 and book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest >= 3:
            jump scenegreat
        
        # Отличная либо Средняя
        if ghost < 10 and  book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest >= 3: 
            jump scenegreat
        elif ghost < 10 and book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest < 3:
            jump scenegood
        jump scenegood
    elif gender == "G":
        "Перед ними стоял темно-синий, блестящий вагон императорской семьи."
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "У тебя совсем немного времени, чтобы найти последнюю книгу. Главное, будь осторожна и не привлекай внимания полицейского."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я постараюсь."
        hide g1 with dissolve
        hide t1 with dissolve
        scene 4back4 with fade:
            size (1280, 720)
            fit "fill"
        stop music fadeout 2.0
        play music haspit fadein 2.0 loop if_changed
        "Тимирязев не стал заходить. Впрочем, [player_name] уже привыкла к тому, что все испытания придется проходить самостоятельно."
        "Но без Климента Аркадьевича стало безумно одиноко. Кроме того, непонятно, где искать книгу."
        "Богатые интерьеры невольно заставляли любоваться ими. [player_name] постоянно напоминала себе о том, что нужно сосредоточиться и не допустить ошибок, но невозможно было не отвлекаться на подобную красоту."
        "В наше время, к сожалению, императорские вагоны сохранились только заграницей. Но в музеях можно еще увидеть макеты и даже VR-проекты. Однако [player_name] не успела с ними познакомиться."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Придется действовать наугад."
        hide g1 with dissolve
        label scene40_0_g:
            $ return_label = "scene40_0_g_timeout"        
            show screen choice_timer(5)
            menu:
                "Идти обычным шагом":
                    label scene40_0_g_timeout:
                        hide screen choice_timer
                        if rightornot == 0:
                            $ ghost += 1
                            $ rightornot += 1
                            "Вы выбрали неверную тактику и были замечены. +Призрак"
                        else:
                            "Вы выбрали неверную тактику и были замечены."
                        show ghost_policia:
                            zoom 1.0 xalign 0.7 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        characterpolicia "А ну стой! Что ты делаешь в интерьерах? Это кем себя нужно было возомнить? Сомневаюсь, что ты инженер. Хочешь что-то украсть?"
                        "Вас арестовали. Попробуйте еще раз. + Призрак"
                        hide ghost_policia with dissolve
                        jump scene40_0_g
                "Пробежать":
                    hide screen choice_timer
                    "По вагону раздался громкий топот ног. На шум прибежал полицейский."
                    show ghost_policia:
                        zoom 1.0 xalign 0.7 yalign 1.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    characterpolicia "Куда бежишь? Что-то украла?"
                    show g5:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Нет, просто тороплюсь."
                    characterpolicia "Очень странно себя ведешь, лучше обыскать тебя! Пройдем со мной, ты арестована."
                    if rightornot == 0:
                        $ ghost += 1
                        $ rightornot += 1
                        "Вы выбрали неверную тактику и были замечены. +Призрак"
                    else:
                        "Вы выбрали неверную тактику и были замечены."
                    hide g5 with dissolve
                    hide ghost_policia with dissolve
                    jump scene40_0_g
                "Пройти тихо":
                    hide screen choice_timer
                    if rightornot == 0:
                        $ reality += 1
                        $ rightornot += 1
                        "Вы выбрали верную тактику. + Явь"
                    else:
                        "Вы выбрали верную тактику."
                    $ rightornot == 0
        
        "Пока что удавалось оставаться незамеченным."
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Интересно, что в дореволюционные времена мне могло грозить за такую дерзость? Надеюсь, не расстрел."
        "От этой мысли стало немного не по себе. Вообще, здесь все было пропитано тяжелой атмосферой. Может быть, из-за тяжелой судьбы Романовых стены сами по себе отдавали скорбью."
        "Не смотря на то, что призраков не было, чувство какого-то присутствия не покидало бы любого, кто осмелился сюда зайти."
        hide g2 with dissolve
        scene 4back5 with fade:
            size (1280, 720)
            fit "fill"
        "Новое помещение было похоже на столовую. Здесь стояла роскошная мебель рядом с длинным обеденным столом. На нем красовались свечи с мрачным синим пламенем."
        "Захотелось коснуться огонька рукой. Почему-то он притягивал к себе."
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Кажется, словно пламя не должно обжечь…"
        "[player_name] потянулась рукой…"
        hide g5 with dissolve
        label scene40_1_g:
            $ return_label = "scene40_1_g_timeout"        
            show screen choice_timer(3)
            menu:
                "Коснуться…":
                    label scene40_1_g_timeout:
                        hide screen choice_timer
                        "[player_name] не смогла сопротивляться желанию. Протянув руку, она провела ею над пламенем."
                        "Оно оказалось дико горячим. Охватив ладонь, пламя жестоко жглось."
                        show g7:   
                            zoom 1.0 xalign -0.3 yalign 0.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        character "Больно!!!"
                        "[player_name] невольно задела подсвечник и столкнула его со стола. Огонь перекинулся на стол и занавески."
                        character "Нет! Нет, пожалуйста!!!!"
                        show ghost_policia:
                            zoom 1.0 xalign 0.7 yalign 1.0
                            alpha 0.0
                            easein 0.3 alpha 1.0
                        characterpolicia "Что здесь происходит?! А ну иди сюда, вредитель!!!"
                        if rightornot == 0:
                            $ ghost += 1
                            $ rightornot += 1
                            "Вас поймали! Попробуйте еще раз! + Призрак."
                        else:
                            "Вас поймали! Попробуйте еще раз!"
                        hide ghost_policia with dissolve
                        hide g7 with dissolve
                        jump scene40_1_g
                "Отвернуться…":
                    hide screen choice_timer
                    show g1:   
                        zoom 1.0 xalign -0.3 yalign 0.0
                        alpha 0.0
                        easein 0.3 alpha 1.0
                    character "Не стоит поддаваться призрачному зову. Вдруг это снова какая-нибудь русалка…"
                    if rightornot == 0:
                            $ ghost += 1
                            $ rightornot += 1
                            "Вам удалось избежать ловушки. +Явь"
                    else:
                        "Вам удалось избежать ловушки."
                    $ rightornot == 0
                    hide g1 with dissolve
        
        "[player_name] осмотрелась. Нужно было понять, где могли спрятать книгу. Однако никаких подсказок не наблюдалось. Может быть, где-то был тайник."
        "В глубине столовой висело зеркало. Во многих фильмах за ним скрывались ниши для хранения важных документов или ценных бумаг."
        "Других вариантов не наблюдалось, и [player_name] уверенно шагнула навстречу отражению."
        "Помня про осторожность, она не спешила касаться предмета. Сосредоточившись на раме, [player_name] не сразу заметила, что с отражением что-то не так и, присмотревшись, едва ли не вскрикнула."
        show ghost_g:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что происходит?!"
        "Едва сдержав крик, [player_name] замерла, не веря собственным глазам."
        characterotragenie "Я всего лишь то, что ты не желаешь принимать в себе."
        hide g7 with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Нет, ты дурацкая шутка призраков…"
        characterotragenie "О нет, поверь мне. В каждом есть сторона, которую не хочется признавать в себе."
        character "Я справлюсь и вернусь в свой мир."
        characterotragenie "Я так не думаю… Но, забавы ради, я даже отдам тебе последнюю книгу, и мы увидим, сможешь ли ты выбраться отсюда."
        character "Хватит болтать. Давай сюда и я пойду."
        characterotragenie "Неужели ты думаешь, что это будет так легко."
        "Было странно вести диалог с зеркалом, в котором ты сам себе давал ответы."
        character "Хватит играть со мной! Или верни книгу, или я сейчас разобью этот поломанный телевизор."
        "[player_name] услышала свой собственный зловещий смех от пугающей копии."
        characterotragenie "Давай посмотрим, как ты усвоила урок своего путешествия. Готова держать ответ?"
        hide g2 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я готова."
        characterotragenie "Тогда первый вопрос!"
        characterotragenie "Почему улицу назвали Везенбергской?"
        hide g1 with dissolve
        hide ghost_g with dissolve
        menu:
            "По городу":
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "В Нарвской части Санкт-Петербурга улицы для простоты ориентирования называли как города в  Прибалтике. Эта улица получила название по эстонскому городу Везенбергу, сейчас он называется Раквере."
                show ghost_g:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Ишь ты! Подготовилась."
                $ reality += 1
                $ zagadkaotragenie += 1
                "Верно. + Явь"
                hide ghost_g with dissolve
                hide g2 with dissolve
            "По Замку":
                show ghost_g:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "По какому Замку?"
                character "Откуда я знаю? По красивому."
                characterotragenie "Какой глупый ответ."
                $ ghost += 1
                "Не верно. + Призрак"
                hide ghost_g with dissolve
                hide g2 with dissolve
            "По фамилии":
                show ghost_g:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "По чьей фамилии?"
                character "Везенберга."
                characterotragenie "Очень смешно. Ты ошиблась."
                $ ghost += 1
                "Не верно. + Призрак"
                hide ghost_g with dissolve
                hide g2 with dissolve
        show ghost_g:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterotragenie "Следующий вопрос."
        characterotragenie "Про Везенбергскую улицу поговорили, а вот соседнюю Лейхтенбергскую почему так назвали?"
        "[player_name] судорожно вспоминала все, что помнит. Сейчас улица называется Розенштейна. Но чем это может помочь? Ничем. Придется поразмыслить…"
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Улицу назвали…"
        hide g5 with dissolve
        hide ghost_g with dissolve
        menu:
            "По городу":
                show ghost_g:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Это что за город такой?"
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Лейхтенберг."
                characterotragenie "Хорошая попытка, но ты ошиблась."
                $ ghost += 1
                "Не верно. + Призрак"
                hide g2 with dissolve
                hide ghost_g with dissolve
            "По фамилии":
                show ghost_g:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Какой-такой фамилии?"
                show g2:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Максимилиана Лейхтенбергского, мужа Марии Николаевны Романовой, военного и государственного деятеля."
                $ reality += 1
                $ zagadkaotragenie += 1
                "Верно. + Явь"
                hide g2 with dissolve
                hide ghost_g with dissolve
            "По названию фабрики":
                show ghost_g:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Какой фабрики?"
                show g5:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Ну одной из…"
                characterotragenie "Из чего?"
                character "Из тех, что находились тут."
                characterotragenie "Так и скажи, что не знаешь, зачем выдумывать небылицы?"
                $ ghost += 1
                "Не верно. + Призрак"
                hide g5 with dissolve
                hide ghost_g with dissolve
        show ghost_g:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterotragenie "Следующий вопрос!"
        characterotragenie "Хватит вопросов по Везенбергскому кварталу… Давай просто проверим твои знания. Раз мы находимся на железнодорожном вокзале, то и вопрос будет близкий по теме."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Слушаю."
        characterotragenie "Какую железную дорогу проложили первой в России?"
        hide g1 with dissolve
        hide ghost_g with dissolve
        menu:
            "Царскосельскую":
                show g5:   
                    zoom 1.0 xalign -0.3 yalign 0.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                character "Царскосельская железная дорога — первая железная дорога общего пользования в России."
                $ reality += 1
                $ zagadkaotragenie += 1
                "Верно. + Явь"
                show ghost_g:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Ну надо же… угадала."
                hide ghost_g with dissolve
                hide g5 with dissolve
            "Николаевскую":
                show ghost_g:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Это всего лишь третья по счёту железная дорога в Российской империи."
                $ ghost += 1
                "Не верно. + Призрак"
                hide ghost_g with dissolve
            "Петергофскую":
                show ghost_g:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterotragenie "Ты ошиблась. Не смотря на безумно интересную и своеобразную историю своего появления, Петергофская железная дорога не была первой."
                $ ghost += 1
                "Не верно. + Призрак"
                hide ghost_g with dissolve
        
        if zagadkaotragenie >= 2:
            "Отражение злобно оскалилось."
            show ghost_g:
                zoom 1.0 xalign 0.7 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterotragenie "Наплевать на твою смелость и на правильные ответы. Ты сдашься и останешься здесь с призраками!"
            show g2:   
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "Как бы не так! Отдавай книгу и помалкивай. Я вернусь в реальный мир!"
            if architect == 1:
                "Вы учитесь на архитектора."
                character "Стану архитектором, напишу большой труд об исчезнувших зданиях Везенбергского квартала, построю НОВЫЕ изящные дома, которые будут заселять НОВЫЕ люди. Они будут творить НОВУЮ историю! Квартал расцветет и станет ярче, благороднее."
                character "У Везенбергского квартала есть будущее! И его построим мы – люди, сохранив наследие прошлого."
            elif botanist == 1:
                "Вы учитесь на ботаника."
                character "Я стану ученым! Буду гордо нести наследие Климента Аркадьевича Тимирязева. Я не только помогу нашей библиотеке сохранить это гордое имя, но и приду сама читать в нее лекции."
                "Мы создадим центр притяжения лучших умов города. И вместе сделаем этот самобытный квартал еще лучше!"
            elif journalist == 1:
                "Вы учитесь на журналиста."
                character "Когда вернусь в реальный мир, сделаю репортаж о Везенбергском квартале. Я расскажу про его прекрасное прошлое, самобытное, порой темное, но при этом и яркое. И я расскажу о будущем. О том будущем, которое мы сможем построить здесь сами."
                character "Я расскажу о том, как важно сохранить то хорошее, что здесь есть и приумножить его. Я не дам забыть о прошлом, но попробую сделать шаг к прекрасному будущему."
            elif archaeologist == 1:
                "Я― будущий археолог! В моем мире я смогу стать тем, кто глубже изучит историю Везенбергского квартала и откроет все его тайны миру. Я подключу историков своего факультета, и вместе мы сделаем эти улицы и дома самым интересным краеведческим феноменом."
                "Возможно, тогда мир призраков перестанет так злиться на нас, на людей. Ведь мы сделаем так, чтобы никто не был забыт. Этот квартал уникален, и его история должна продолжаться."
            characterotragenie "Пока только обещания. Держи свою книгу и иди прочь! Это было твое последнее испытание. Ты должна была заглянуть себе в глаза и понять, достойна ли ты идти дальше своим путем."
            hide g2 with dissolve
            show g1:  
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            character "И как, достойна?"
            "Призрак в зеркале зловеще усмехнулся."
            characterotragenie "Скоро поймешь все сама. А пока, забери свою последнюю книгу."
            show misticPeter with fade:
                zoom 1.0 xalign 0 yalign 0
                alpha 0.0
                easein 0.3 alpha 1.0
            $ book_misticPeter += 1
            "Вы получили книгу «Мистический Петербург»."
            hide misticPeter with dissolve
            character "Прощай. Мы больше не увидимся."
            characterotragenie "Посмотрим."
            "Однако от этой встречи осталось неприятное послевкусие."
            hide g1 with dissolve
            hide ghost_g with dissolve
        elif zagadkaotragenie <= 1:
            show g1:  
                zoom 1.0 xalign -0.3 yalign 0.0
                alpha 0.0
                easein 0.3 alpha 1.0
            show ghost_g:
                zoom 1.0 xalign 0.7 yalign 1.0
                alpha 0.0
                easein 0.3 alpha 1.0
            characterotragenie "Надеюсь, ты убедилась, что твоих знаний недостаточно, чтобы так задирать нос, выставляя себя спасителем квартала."
            characterotragenie "Как ты собираешься нести ответственность за свой мир, если сама за себя ответить не можешь?"
            character "Знаешь, важно увидеть ошибку, чтобы суметь ее избежать в будущем. Это еще не конец игры! Я вернусь в свой мир."
            "Кто знает, может быть, [player_name] и права."
            characterotragenie "Книга останется со мной. Ступай. Еще встретимся."
            character "Надеюсь, что нет."
            "Однако уверенность, к несчастью, испарялась."
            hide ghost_g with dissolve
            hide g1 with dissolve
        
        scene 4back1 with fade:
            size (1280, 720)
            fit "fill"
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Ты как, мой друг?"
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Случилась не самая приятная встреча."
        tmrz "Что ж, есть и приятные новости. Наш путь практически окончен. У нас осталось совсем немного времени, и мы узнаем, принесут ли плоды наши усилия."
        character "И что теперь мне делать?"
        tmrz "Теперь, я думаю, ты заслужила отдых."
        hide g2 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Отдых? Я думала, что мы здесь не за этим."
        tmrz "Все, что мы могли сделать, уже сделано – сражение с призраками, поиск книг. Теперь осталось дождаться, чтобы время снова соединилось в одну линию. И мы увидим, что получилось."
        character "И куда же мы теперь?"
        tmrz "Ты когда-нибудь была в Балтийских банях?"
        hide g1 with dissolve
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Нет."
        tmrz "Самое время посетить."
        hide g5 with dissolve
        hide t1 with dissolve

        scene 4back6 with fade:
            size (1280, 720)
            fit "fill"
        stop music fadeout 2.0
        play music bany fadein 2.0 loop if_changed
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Перед тобой Балтийские бани. Здесь можно было не только попариться и поплавать в бассейне, но и пройти курс лечебных процедур, лечебный массаж, циркулярный и восходящий душ. Здесь работали квалифицированные врачи из 81-й поликлиники Октябрьского района."
        tmrz "После революции, когда доходные дома превратились в коммунальные квартиры, существовал ряд бытовых проблем, в том числе отсутствие в домах ванных. Поэтому бани были спасением."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Не знала, что они такие интересные. Со стороны выглядят сурово."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Предлагаю познакомиться поближе, ступай. Тебе нужен отдых."
        character "А вы?"
        tmrz "Здесь наши пути расходятся. Спасибо тебе, это было увлекательное путешествие."
        hide g1 with dissolve
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что? Почему? "
        hide g7 with dissolve
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Значит, я вас больше не увижу?"
        tmrz "Мой друг, если наш план удастся, то ты всегда можешь прийти в библиотеку им. К.А. Тимирязева. Ты не увидишь меня, но почувствуешь, что я рядом и поддерживаю все твои благие начинания."
        tmrz "Я в тебя верю!"
        "[player_name] уже успела привыкнуть к добрым советам Климента Аркадьевича. Столько еще было вопросов, которые хотелось задать. И прощаться было тяжело. Но так было правильно."
        "[player_name] точно знала, что есть злые призраки, есть добрые, а есть Климент Аркадьевич, который не смотря ни на что продолжает нести свет как в призрачный мир, так и в реальный."
        character "Спасибо вам. Я никогда вас не забуду."
        tmrz "Ты навсегда останешься моим хорошим другом!"
        "Больше не хотелось говорить. [player_name] смело отправилась исследовать последнее призрачное пространство."
        hide g6
        hide t1
        with dissolve
        scene 4back7 with fade:
            size (1280, 720)
            fit "fill"
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Мммм… приятно пахнет деревом."
        show ghost_doctor:
            zoom 1.0 xalign 0.7 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterdoctor "Добрый день, скажите, что вас беспокоит, и я подберу для вас процедуры."
        character "…"
        hide ghost_doctor with dissolve
        hide g1 with dissolve
        menu:
            "Спину ломит, весь день на ногах":
                show ghost_doctor:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterdoctor "Тогда распишу для вас курс массажей. А пока можете отправляться попариться в баню - стимуляция кровотока позволяет мышцам быстрее восстанавливаться после длительных нагрузок."
                hide ghost_doctor with dissolve
            "Мне очень тоскливо":
                show ghost_doctor:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterdoctor "Предлагаю вам отправиться на банные процедуры. При погружении в тёплую и влажную среду организм выделяет эндорфины, что вызывает ощущение радости и приятное состояние эйфории. Вам станет легче."
                hide ghost_doctor with dissolve
            "Не знаю, просто хочется наконец-то спокойствия":
                show ghost_doctor:
                    zoom 1.0 xalign 0.7 yalign 1.0
                    alpha 0.0
                    easein 0.3 alpha 1.0
                characterdoctor "Предлагаю вам отправиться на банные процедуры. При погружении в тёплую и влажную среду организм выделяет эндорфины, что вызывает ощущение радости и приятное состояние эйфории. Вам станет легче."
                hide ghost_doctor with dissolve
        
        show g8:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что ж, приятное окончание длинного и тяжелого дня."
        "Работники бани выдали полотенце, халат и обувь. [player_name] приняла душ и отправилась в парную. Воздух наполнился приятной теплой тяжестью. Действительно казалось, что эта процедура создает какой-то волшебный эффект."
        "Очень захотелось спать. День был такой напряженный. Весь мир перевернулся с ног на голову. И так хотелось домой – в теплую постель. Хотелось выпить ароматного какао и забыться сном."
        "Глаза сами собой стали закрываться…"
        hide g8 with dissolve
        
        # Плохая либо Средняя
        if ghost >= 23 and book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest < 6:
            jump sceneplox
        elif ghost >= 23 and book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest == 6:
            jump scenegood
        
        # Средняя либо Отличная
        if ghost >= 10 and ghost <= 22 and book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest < 3:
            jump scenegood
        elif ghost >= 10 and ghost <= 22 and book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest >= 3:
            jump scenegreat
        
        # Отличная либо Средняя
        if ghost < 10 and  book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest >= 3: 
            jump scenegreat
        elif ghost < 10 and book_lermnt + book_canal + book_coi + book_misticPeter + book_promish + book_rest < 3:
            jump scenegood
        jump scenegood

label sceneplox:
    stop music fadeout 0.2
    play music conec_1 fadein 2.0 loop if_changed
    scene animcon1 with fade:
        size (1280, 720)
        fit "fill"
    $ renpy.pause(delay=6.4, hard=True)
    scene back0:
        size (1280, 720)
        fit "fill"   
    if gender == "M":
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что происходит? Время закончилось?"
        character "Но все должно было вернуться на места!"
        "Призрачный туман не собирался никуда исчезать. Он мягко окутывал библиотеку и скользил по улочкам."
        hide m2 with dissolve
        # кат - сцена
        scene skapina with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=3.0, hard=True)
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Снесенные дома все еще здесь… Я в призрачном мире!"
        "[player_name] хотел посмотреть на часы, но, взглянув на свои руки, ужаснулся."
        hide m7 with dissolve

        show m_ryki0 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)
        show m_ryki1 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)
        show m_ryki2 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)
        show m_ryki3 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)

        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что происходит?!"
        "В вас больше от призраков, и вы не сможете вернуться в реальность."
        "От резкой паники настроение растворялось, скатываясь в полную апатию."
        "Все, что беспокоило раньше, стало каким-то далеким и безразличным."
        "В последние секунды, когда внутри себя еще можно было почувствовать что-то человеческое, [player_name] вспомнил о библиотекарях, о книгах, о Клименте Аркадьевиче…"
        "А затем [player_name] растворился в тумане."
        hide m7 with dissolve
        scene m_1 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=3.0, hard=True)
        "Мы не слышим зов этих улиц, стараемся не замечать его, ведь что может быть интересного в неприглядных уголках окраин?"
        "Но рано или поздно мы узнаем о призраках, они заставят нас вспомнить о том, кем они были… Но бороться придется не с ними, а с собой. Ведь именно мы предали забвению историю целого квартала…"
        "И, кто знает, сможем ли все исправить? Или растворимся вместе с тайнами, которых с годами будет становиться все больше."
        "Вы шли по пути «Призрака» слишком часто, поэтому вы остались в призрачном мире."
        "Но всегда можно попробовать сразиться с призраками снова…"
        jump scenetitri
    elif gender =="G":
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что происходит? Время закончилось?"
        character "Но все должно было вернуться на места!"
        "Призрачный туман не собирался никуда исчезать. Он мягко окутывал библиотеку и скользил по улочкам."
        hide g2 with dissolve
        # кат - сцена
        scene skapina with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=3.0, hard=True)
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Снесенные дома все еще здесь… Я в призрачном мире!"
        "[player_name] хотела посмотреть на часы, но, взглянув на свои руки, ужаснулась."
        hide g7 with dissolve

        show g_ryki0 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)
        show g_ryki1 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)
        show g_ryki2 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)
        show g_ryki3 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=1.0, hard=True)

        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что происходит?!"
        "В вас больше от призраков, и вы не сможете вернуться в реальность."
        "От резкой паники настроение растворялось, скатываясь в полную апатию."
        "Все, что беспокоило раньше, стало каким-то далеким и безразличным."
        "В последние секунды, когда внутри себя еще можно было почувствовать что-то человеческое, [player_name] вспомнила о библиотекарях, о книгах, о Клименте Аркадьевиче…"
        "А затем [player_name] растворилась в тумане."
        hide g7 with dissolve
        scene g_1 with fade:
            size (1280, 720)
            fit "fill"
        $ renpy.pause(delay=3.0, hard=True)
        "Мы не слышим зов этих улиц, стараемся не замечать его, ведь что может быть интересного в неприглядных уголках окраин?"
        "Но рано или поздно мы узнаем о призраках, они заставят нас вспомнить о том, кем они были… Но бороться придется не с ними, а с собой. Ведь именно мы предали забвению историю целого квартала…"
        "И, кто знает, сможем ли все исправить? Или растворимся вместе с тайнами, которых с годами будет становиться все больше."
        "Вы шли по пути «Призрака» слишком часто, поэтому вы остались в призрачном мире."
        "Но всегда можно попробовать сразиться с призраками снова…"
        jump scenetitri

label scenegood:
    stop music fadeout 0.2
    play music conec_2 fadein 2.0 loop if_changed
    scene animcon23 with fade:
        size (1280, 720)
        fit "fill"
    $ renpy.pause(delay=6.4, hard=True)
    scene 4_1_2:
        size (1280, 720)
        fit "fill"  
    if gender == "M":
        "[player_name] не помнил, как оказался снова перед библиотекой."
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что происходит?"
        "Небо было ясное. То самое небо, которое приветливо встречало в начале дня, до того, как произошла вся эта история с призраками."
        "Казалось, что все закончилось. Но почему-то все еще не отпускало легкое чувство тревожности…"
        "[player_name], вдохнув больше воздуха, отправился в библиотеку."
        hide m7 with dissolve
        scene 1_1_2 with fade:
            size (1280, 720)
            fit "fill"
        "Библиотека выглядела вполне нормально. Зловещий туман больше не прогуливался среди интерьеров."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Здравствуйте."
        show lena2:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterlena "Здравствуйте…"
        "Девушка не двигалась и смотрела вперед пустым взглядом."
        hide m1 with dissolve
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Все в порядке?"
        characterlena "Да."
        "Верилось с трудом. Что-то здесь было нечисто."
        character "Я пройду за книгой?"
        characterlena "Да."
        "Что-то здесь было не так. Но что?"
        "Нужно было разобраться, и [player_name] проследовал в читальный зал."
        hide m6 with dissolve
        hide lena2 with dissolve
        scene 3_1_2 with fade:
            size (1280, 720)
            fit "fill"
        "Повернув налево, [player_name] едва ли не столкнулась с заведующей библиотекой."
        show irina_Ernestovna_2:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteririnaErnestovna "…"
        "[player_name] хорошо был знаком с Ириной Эрнестовной. Она всегда была очень приветливой и много раз помогала разобраться со сложностями, если по каким-то причинам в библиотеке они возникали."
        "Сейчас было странно ее видеть такой отрешенной."
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ирина Эрнестовна, здравствуйте!"
        characteririnaErnestovna "Здравствуйте, проходите."
        "[player_name] не стал докучать, но в голову закралась мысль, что вернувшиеся библиотекари ведут себя странно. Настороженно он осмотрел читальный зал."
        hide irina_Ernestovna_2 with dissolve
        show irina_2:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteririna "…"
        hide irina_2 with dissolve
        show elisaveta_2:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterelizaveta "…"
        hide elisaveta_2 with dissolve
        show anastasia_2:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteranastasia "…"
        hide anastasia_2 with dissolve
        "Механически библиотекари ходили по залу, расставляли книжки. Но их сознание словно находилось где-то далеко. И [player_name] догадывался, где."
        character "В Везенбергском квартале…"
        "Отчего-то [player_name] произнес это вслух…"
        scene 2_1_2 with fade:
            size (1280, 720)
            fit "fill"
        "В зале абонемента было тихо. [player_name] устроился на красном диванчике, стараясь осознать, что происходит."
        character "Все вернулись, но что-то пошло не так. Они сами на себя не похожи. Словно застряли в двух реальностях одновременно…"
        "Между книжными стеллажами мелькнула тень."
        hide m6 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А?"
        character "Простите…"
        hide m1 with dissolve
        show ghost_ht1:
            zoom 1.0 xpos 800 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterht1 "…"
        scene 2_1_2 with fade:
            size (1280, 720)
            fit "fill"
        hide ghost_ht1
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        "Резко вскочив на ноги, [player_name] моргнул, но уже никого не увидел."
        character "Что происходит?"
        "Развернувшись к выходу, [player_name] столкнулся с другим призраком."
        show ghost_children:
            size (1280, 720)
            fit "fill"
            zoom 1.0 xpos 450 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterchildren "Привет!"
        hide ghost_children
        "Заливисто засмеявшись, призрак убежал и растворился."
        hide m7 with dissolve
        show m2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я сейчас сойду с ума…"
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Успокойся, мой друг."
        hide m2 with dissolve
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич?"
        tmrz "Давай сядем и все обсудим."
        "Тимирязев со вздохом устроился на диванчике напротив. [player_name], не в силах вымолвить ни слова, безвольно сел на прежнее место."
        hide m7 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Вы говорили, что все закончится. Мы что-то сделали не так?"
        tmrz "Ты смог отвоевать этот мир, но не без потерь."
        character "Что это значит?"
        tmrz "Сознание библиотекарей балансирует между мирами. А ты теперь всегда будешь видеть тех призраков, что тебе не посчастливилось встретить. Но будь мужественен, навредить они тебе не смогут. Но запугивать будут."
        tmrz "Мне жаль, мой друг."
        character "Но наш мир им не удалось забрать?"
        tmrz "К счастью, нет."
        "Сложно было смириться с тем, что теперь призраки должны будут стать частью повседневности. Да и как вообще это повлияет на жизнь, не поддавалось осознанию. Но было понятно то, что теперь придется с этим как-то уживаться…"
        character "Есть и плюсы."
        tmrz "Здорово, что ты не растерял оптимизма. Какие?"
        character "Теперь у нас будет возможность с вами общаться. И мы заполним все пробелы в истории. Вы же не откажете мне в беседе?"
        tmrz "Конечно, нет. Предлагаю тебе наконец-то взять кофе, о котором ты мечтал с самого начала пути, и обсудим все, что с нами произошло."
        "Да, новые обстоятельства пугали. Но [player_name] знал, что теперь у него есть друг, который поможет со всем справиться. Вместе они найдут выход. А это уже стоило того, чтобы пройти весь путь."
        "Вы слишком часто шли по пути «Призрака», но старались оставаться в «Яви». Поэтому вы вернулись в реальность, однако призраки так и будут следовать за вами по пятам…"
        "Однако всегда можно попробовать сразиться с ними снова…"
        hide m1 with dissolve
        hide t1 with dissolve
        jump scenetitri
        return 
    elif gender =="G":
        "[player_name] не помнила, как оказалась снова перед библиотекой."
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что происходит?"
        "Небо было ясное. То самое небо, которое приветливо встречало в начале дня, до того, как произошла вся эта история с призраками."
        "Казалось, что все закончилось. Но почему-то все еще не отпускало легкое чувство тревожности…"
        "[player_name], вдохнув больше воздуха, отправилась в библиотеку."
        hide g7 with dissolve
        scene 1_1_2 with fade:
            size (1280, 720)
            fit "fill"
        "Библиотека выглядела вполне нормально. Зловещий туман больше не прогуливался среди интерьеров."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Здравствуйте."
        show lena2:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterlena "Здравствуйте…"
        "Девушка не двигалась и смотрела вперед пустым взглядом."
        hide g1 with dissolve
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Все в порядке?"
        characterlena "Да."
        "Верилось с трудом. Что-то здесь было нечисто."
        character "Я пройду за книгой?"
        characterlena "Да."
        "Что-то здесь было не так. Но что?"
        "Нужно было разобраться, и [player_name] проследовала в читальный зал."
        hide g6 with dissolve
        hide lena2 with dissolve
        scene 3_1_2 with fade:
            size (1280, 720)
            fit "fill"
        "Повернув налево, [player_name] едва ли не столкнулась с заведующей библиотекой."
        show irina_Ernestovna_2:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteririnaErnestovna "…"
        "[player_name] хорошо была знакома с Ириной Эрнестовной. Она всегда была очень приветливой и много раз помогала разобраться со сложностями, если по каким-то причинам в библиотеке они возникали."
        "Сейчас было странно ее видеть такой отрешенной."
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Ирина Эрнестовна, здравствуйте!"
        characteririnaErnestovna "Здравствуйте, проходите."
        "[player_name] не стала докучать, но в голову закралась мысль, что вернувшиеся библиотекари ведут себя странно. Настороженно она осмотрела читальный зал."
        hide irina_Ernestovna_2 with dissolve
        show irina_2:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteririna "…"
        hide irina_2 with dissolve
        show elisaveta_2:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterelizaveta "…"
        hide elisaveta_2 with dissolve
        show anastasia_2:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteranastasia "…"
        hide anastasia_2 with dissolve
        "Механически библиотекари ходили по залу, расставляли книжки. Но их сознание словно находилось где-то далеко. И [player_name] догадывалась, где."
        character "В Везенбергском квартале…"
        "Отчего-то [player_name] произнесла это вслух…"
        scene 2_1_2 with fade:
            size (1280, 720)
            fit "fill"
        "В зале абонемента было тихо. [player_name] устроилась на красном диванчике, стараясь осознать, что происходит."
        character "Все вернулись, но что-то пошло не так. Они сами на себя не похожи. Словно застряли в двух реальностях одновременно…"
        "Между книжными стеллажами мелькнула тень."
        hide g6 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А?"
        character "Простите…"
        hide g1 with dissolve
        show ghost_ht1:
            zoom 1.0 xpos 800 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterht1 "…"
        scene 2_1_2 with fade:
            size (1280, 720)
            fit "fill"
        hide ghost_ht1
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        "Резко вскочив на ноги, [player_name] моргнула, но уже никого не увидела."
        character "Что происходит?"
        "Развернувшись к выходу, [player_name] столкнулась с другим призраком."
        show ghost_children:
            size (1280, 720)
            fit "fill"
            zoom 1.0 xpos 450 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterchildren "Привет!"
        hide ghost_children
        "Заливисто засмеявшись, призрак убежал и растворился."
        hide g7 with dissolve
        show g2:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Я сейчас сойду с ума…"
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Успокойся, мой друг."
        hide g2 with dissolve
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич?"
        tmrz "Давай сядем и все обсудим."
        "Тимирязев со вздохом устроился на диванчике напротив. [player_name], не в силах вымолвить ни слова, безвольно села на прежнее место."
        hide g7 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Вы говорили, что все закончится. Мы что-то сделали не так?"
        tmrz "Ты смогла отвоевать этот мир, но не без потерь."
        character "Что это значит?"
        tmrz "Сознание библиотекарей балансирует между мирами. А ты теперь всегда будешь видеть тех призраков, что тебе не посчастливилось встретить. Но будь мужественной, навредить они тебе не смогут. Но запугивать будут."
        tmrz "Мне жаль, мой друг."
        character "Но наш мир им не удалось забрать?"
        tmrz "К счастью, нет."
        "Сложно было смириться с тем, что теперь призраки должны будут стать частью повседневности. Да и как вообще это повлияет на жизнь, не поддавалось осознанию. Но было понятно то, что теперь придется с этим как-то уживаться…"
        character "Есть и плюсы."
        tmrz "Здорово, что ты не растеряла оптимизма. Какие?"
        character "Теперь у нас будет возможность с вами общаться. И мы заполним все пробелы в истории. Вы же не откажете мне в беседе?"
        tmrz "Конечно, нет. Предлагаю тебе наконец-то взять кофе, о котором ты мечтала с самого начала пути, и обсудим все, что с нами произошло."
        "Да, новые обстоятельства пугали. Но [player_name] знала, что теперь у нее есть друг, который поможет со всем справиться. Вместе они найдут выход. А это уже стоило того, чтобы пройти весь путь."
        "Вы слишком часто шли по пути «Призрака», но старались оставаться в «Яви». Поэтому вы вернулись в реальность, однако призраки так и будут следовать за вами по пятам…"
        "Однако всегда можно попробовать сразиться с ними снова…"
        hide g1 with dissolve
        hide t1 with dissolve
        jump scenetitri
        return 

label scenegreat:
    stop music fadeout 0.2
    play music conec_3 fadein 2.0 loop if_changed
    scene animcon23 with fade:
        size (1280, 720)
        fit "fill"
    $ renpy.pause(delay=6.4, hard=True)
    scene back5:
        size (1280, 720)
        fit "fill"
    if gender == "M":
        "[player_name] не помнил, как оказался снова перед библиотекой."
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что происходит?"
        "Небо было ясное. То самое небо, которое приветливо встречало в начале дня до того, как произошла вся эта история с призраками."
        "Сердце подсказывало, что все закончилось, но не хотелось радоваться заранее. Вдруг это очередная уловка?"
        "[player_name], вдохнув больше воздуха, отправился в библиотеку."
        hide m7 with dissolve
        scene 1_0_3 with fade:
            size (1280, 720)
            fit "fill"
        show irina_Ernestovna_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteririnaErnestovna "Добро пожаловать! Рада вас снова видеть у нас."
        "[player_name] от удивления на несколько секунд застыл. В библиотеке снова кипела жизнь, сюда вернулись краски, исчез туман. По помещениям суетливо бегали библиотекари."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Здравствуйте. Я пройду?"
        characteririnaErnestovna "Конечно, проходите."
        "[player_name] решил все тщательно осмотреть, прежде чем делать выводы."
        hide m1 with dissolve
        hide irina_Ernestovna_3 with dissolve
        scene 1_2_3 with fade:
            size (1280, 720)
            fit "fill"
        "В читальном зале тоже кипела работа. Библиотекари к чему-то готовились."
        show irina_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteririna "Добрый день! Вы за книжками или хотите посетить наши мероприятия?"
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А какие у вас сегодня мероприятия проходят?"
        "[player_name] выглядел немного тревожным, напряжение все еще не хотело испаряться. Всюду чудился подвох."
        characteririna "У нас начинается фестиваль «Японская осень», поэтому проходит множество различных лекций, мастер-классов. Но об этом лучше спросить у Анастасии."
        hide irina_3 with dissolve
        show anastasia_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteranastasia "Добрый день. Уже скоро начнем играть в тосэнкё — традиционную японскую игру. Если хотите, присоединяйтесь."
        hide anastasia_3 with dissolve
        show irina_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteririna "Еще сегодня пройдет занятие по оригами, будем складывать бумажных журавликов. Хотите записаться?"
        character "Может быть в другой раз."
        characteririna "Держите, это наш буклет с мероприятиями."
        character "Большое спасибо."
        hide irina_3 with dissolve
        show anastasia_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteranastasia "Хорошего дня, рады помочь. Если надумаете – заходите."
        "Все выглядело абсолютно нормально. Словно и не было этих приключений. [player_name] невольно подумал, что все это приснилось. Прижимая буклет к себе, он решил еще немного пройтись по библиотеке."
        hide anastasia_3 with dissolve
        hide m1 with dissolve
        scene 1_3_3 with fade:
            size (1280, 720)
            fit "fill"
        "В зале было спокойно. За рабочим компьютером сидела девушка и сосредоточенно что-то рисовала."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Вы пишете картину?"
        "Девушка приветливо улыбнулась в ответ."
        show elisaveta_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterelizaveta "Завтра провожу занятие по правополушарному рисованию. Готовлюсь."
        hide m1 with dissolve
        show m8:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Очень красиво!"
        characterelizaveta "Спасибо."
        "Устроившись на красном диванчике за столиком, [player_name] пробежался глазами по буклету, который выдали библиотекари."
        "Кажется, все вернулось на свои места. В библиотеку понемногу приходили другие люди. Кто-то сдавал книжки, кто-то ждал лекцию, кто-то просто сидел со своим ноутбуком и решал рабочие вопросы."
        "От призраков не осталось и следа."
        "Пробежавшись глазами по буклету, [player_name] едва ли не поперхнулся, увидев название библиотечной экскурсии."
        hide m8 with dissolve
        hide elisaveta_3 with dissolve
        show m5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "«Тайны Везенбергского квартала»…"
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Да-да. Это история о том самом квартале, в котором тебе посчастливилось побывать в призрачном мире."
        "От неожиданности [player_name] подпрыгнул на месте. Перед ним сидел Тимирязев, появившийся из ниоткуда."
        hide m5 with dissolve
        show m7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич?!! Вы же сказали, что я больше вас не увижу."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Не пугайся, мой друг, я не знал, что будет в конце нашего пути, и сможем ли мы увидеться снова. Я прихожу к тебе в последний раз, дальше остатки тумана полностью уйдут с этих улиц, и люди больше не увидят привидений."
        tmrz "А пока я просто обязан поблагодарить тебя за спасение библиотеки и поздравить с успешным окончанием миссии."
        "Спасибо, я уже думал, что это все мне снилось. "
        tmrz "Нет, мой друг. Все было более чем реально. Я лично очень благодарен тебе."
        hide m7 with dissolve
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А что теперь?"
        tmrz "Ты победил призраков, теперь никто из них больше никогда не потревожит тебя. Но обещай мне кое-что."
        character "Что?"
        tmrz "Никогда не забывай о том, что произошло."
        hide m1 with dissolve
        show m6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Не забуду."
        tmrz "Прощай! Буду радоваться твоим новым успехам."
        character "Прощайте и, если так уж выйдет, буду рад встретиться вновь."
        hide t1 with dissolve
        "Климент Аркадьевич исчез, но [player_name] чувствовал, что его добрый дух где-то рядом и еще много лет будет охранять библиотеку от бед."
        hide m6 with dissolve
        "Только сейчас ушла эта жуткая тревожность, и стало бесконечно легко."
        "[player_name] посмотрел на часы и с улыбкой направился к библиотекарю."
        show m1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Извините, не подскажете, а я могу попасть на сегодняшнюю экскурсию по Везенбергскому кварталу?"
        show elisaveta_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterelizaveta "Конечно, поторопитесь. Группа уже внизу и скоро отправляется в путь."
        character "Спасибо!!!"
        hide elisaveta_3 with dissolve
        hide m1 with dissolve
        scene 1_0_3 with fade:
            size (1280, 720)
            fit "fill"
        show lena3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterlena "Добрый день, меня зовут Елена, я ваш экскурсовод. И сегодня мы с вами отправимся в путешествие по  кварталу-призраку."
        characterlena "Везенбергским кварталом принято называть территорию, очерченную улицами Шкапина, Розенштейна, Обводным каналом и железной дорогой завода «Красный треугольник»…"
        hide lena3 with dissolve
        scene 1_5_3 with fade:
            size (1280, 720)
            fit "fill"
        "Время снова бежало линейно, потусторонние миры успокоились и ушли в спячку. Они поняли, что бесполезно бороться с законами природы."
        "За летом всегда идет осень, за зимой – весна… Жизнь не стоит на месте, и надо смириться с этим бесконечным течением."
        "Старое уходит, приходит новое. Это не всегда плохо. Призраки увидели, что у квартала есть будущее. Один смелый человек показал, что не все потеряно."
        "Не смотря на заблуждение множества людей, призраки точно знают, что даже один человек способен изменить весь мир."
        "И призраки поверили в него…"
        "Вы смогли спасти свой мир и вернуть библиотекарей. Мы гордимся вами. Спасибо за ваше смелое прохождение!"
        jump scenetitri
        return
    elif gender =="G":
        "[player_name] не помнила, как оказалась снова перед библиотекой."
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Что происходит?"
        "Небо было ясное. То самое небо, которое приветливо встречало в начале дня до того, как произошла вся эта история с призраками."
        "Сердце подсказывало, что все закончилось, но не хотелось радоваться заранее. Вдруг это очередная уловка?"
        "[player_name], вдохнув больше воздуха, отправилась в библиотеку."
        hide g7 with dissolve
        scene 1_0_3 with fade:
            size (1280, 720)
            fit "fill"
        show irina_Ernestovna_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteririnaErnestovna "Добро пожаловать! Рада вас снова видеть у нас."
        "[player_name] от удивления на несколько секунд застыла. В библиотеке снова кипела жизнь, сюда вернулись краски, исчез туман. По помещениям суетливо бегали библиотекари."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Здравствуйте. Я пройду?"
        characteririnaErnestovna "Конечно, проходите."
        "[player_name] решила все тщательно осмотреть, прежде чем делать выводы."
        hide g1 with dissolve
        hide irina_Ernestovna_3 with dissolve
        scene 1_2_3 with fade:
            size (1280, 720)
            fit "fill"
        "В читальном зале тоже кипела работа. Библиотекари к чему-то готовились."
        show irina_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteririna "Добрый день! Вы за книжками или хотите посетить наши мероприятия?"
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А какие у вас сегодня мероприятия проходят?"
        "[player_name] выглядела немного тревожной, напряжение все еще не хотело испаряться. Всюду чудился подвох."
        characteririna "У нас начинается фестиваль «Японская осень», поэтому проходит множество различных лекций, мастер-классов. Но об этом лучше спросить у Анастасии."
        hide irina_3 with dissolve
        show anastasia_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteranastasia "Добрый день. Уже скоро начнем играть в тосэнкё — традиционную японскую игру. Если хотите, присоединяйтесь."
        hide anastasia_3 with dissolve
        show irina_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteririna "Еще сегодня пройдет занятие по оригами, будем складывать бумажных журавликов. Хотите записаться?"
        character "Может быть в другой раз."
        characteririna "Держите, это наш буклет с мероприятиями."
        character "Большое спасибо."
        hide irina_3 with dissolve
        show anastasia_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characteranastasia "Хорошего дня, рады помочь. Если надумаете – заходите."
        "Все выглядело абсолютно нормально. Словно и не было этих приключений. [player_name] невольно подумала, что все это приснилось. Прижимая буклет к себе, она решила еще немного пройтись по библиотеке."
        hide anastasia_3 with dissolve
        hide g1 with dissolve
        scene 1_3_3 with fade:
            size (1280, 720)
            fit "fill"
        "В зале было спокойно. За рабочим компьютером сидела девушка и сосредоточенно что-то рисовала."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Вы пишете картину?"
        "Девушка приветливо улыбнулась в ответ."
        show elisaveta_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterelizaveta "Завтра провожу занятие по правополушарному рисованию. Готовлюсь."
        hide g1 with dissolve
        show g8:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Очень красиво!"
        characterelizaveta "Спасибо."
        "Устроившись на красном диванчике за столиком, [player_name] пробежалась глазами по буклету, который выдали библиотекари."
        "Кажется, все вернулось на свои места. В библиотеку понемногу приходили другие люди. Кто-то сдавал книжки, кто-то ждал лекцию, кто-то просто сидел со своим ноутбуком и решал рабочие вопросы."
        "От призраков не осталось и следа."
        "Пробежавшись глазами по буклету, [player_name] едва ли не поперхнулась, увидев название библиотечной экскурсии."
        hide g8 with dissolve
        hide elisaveta_3 with dissolve
        show g5:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "«Тайны Везенбергского квартала»…"
        show t2:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Да-да. Это история о том самом квартале, в котором тебе посчастливилось побывать в призрачном мире."
        "От неожиданности [player_name] подпрыгнула на месте. Перед ней сидел Тимирязев, появившийся из ниоткуда."
        hide g5 with dissolve
        show g7:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Климент Аркадьевич?!! Вы же сказали, что я больше вас не увижу."
        hide t2 with dissolve
        show t1:   
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        tmrz "Не пугайся, мой друг, я не знал, что будет в конце нашего пути, и сможем ли мы увидеться снова. Я прихожу к тебе в последний раз, дальше остатки тумана полностью уйдут с этих улиц, и люди больше не увидят привидений."
        tmrz "А пока я просто обязан поблагодарить тебя за спасение библиотеки и поздравить с успешным окончанием миссии."
        "Спасибо, я уже думала, что это все мне снилось."
        tmrz "Нет, мой друг. Все было более чем реально. Я лично очень благодарен тебе."
        hide g7 with dissolve
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "А что теперь?"
        tmrz "Ты победила призраков, теперь никто из них больше никогда не потревожит тебя. Но обещай мне кое-что."
        character "Что?"
        tmrz "Никогда не забывай о том, что произошло."
        hide g1 with dissolve
        show g6:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Не забуду."
        tmrz "Прощай! Буду радоваться твоим новым успехам."
        character "Прощайте и, если так уж выйдет, буду рада встретиться вновь."
        hide t1 with dissolve
        "Климент Аркадьевич исчез, но [player_name] чувствовала, что его добрый дух где-то рядом и еще много лет будет охранять библиотеку от бед."
        hide g6 with dissolve
        "Только сейчас ушла эта жуткая тревожность, и стало бесконечно легко."
        "[player_name] посмотрела на часы и с улыбкой направилась к библиотекарю."
        show g1:   
            zoom 1.0 xalign -0.3 yalign 0.0
            alpha 0.0
            easein 0.3 alpha 1.0
        character "Извините, не подскажете, а я могу попасть на сегодняшнюю экскурсию по Везенбергскому кварталу?"
        show elisaveta_3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterelizaveta "Конечно, поторопитесь. Группа уже внизу и скоро отправляется в путь."
        character "Спасибо!!!"
        hide elisaveta_3 with dissolve
        hide g1 with dissolve
        scene 1_0_3 with fade:
            size (1280, 720)
            fit "fill"
        show lena3:
            zoom 1.0 xalign 1.3 yalign 1.0
            alpha 0.0
            easein 0.3 alpha 1.0
        characterlena "Добрый день, меня зовут Елена, я ваш экскурсовод. И сегодня мы с вами отправимся в путешествие по  кварталу-призраку."
        characterlena "Везенбергским кварталом принято называть территорию, очерченную улицами Шкапина, Розенштейна, Обводным каналом и железной дорогой завода «Красный треугольник»…"
        hide lena3 with dissolve
        scene 1_5_3 with fade:
            size (1280, 720)
            fit "fill"
        "Время снова бежало линейно, потусторонние миры успокоились и ушли в спячку. Они поняли, что бесполезно бороться с законами природы."
        "За летом всегда идет осень, за зимой – весна… Жизнь не стоит на месте, и надо смириться с этим бесконечным течением."
        "Старое уходит, приходит новое. Это не всегда плохо. Призраки увидели, что у квартала есть будущее. Один смелый человек показал, что не все потеряно."
        "Не смотря на заблуждение множества людей, призраки точно знают, что даже один человек способен изменить весь мир."
        "И призраки поверили в него…"
        "Вы смогли спасти свой мир и вернуть библиотекарей. Мы гордимся вами. Спасибо за ваше смелое прохождение!"
        jump scenetitri
        return

label scenetitri:
    stop music fadeout 0.2
    play music name fadein 2.0 loop if_changed
    scene titri_3 with fade:
        size (1280, 720)
        fit "fill"
    $ renpy.pause(delay=6.4, hard=True)
    show black with dissolve
    call screen credits(
        """    Мы благодарны за прохождение нашей игры!
    Рады будем узнать о ваших впечатлениях.
    Спасибо всем, кто работал над созданием этой истории:

    Сценарий:
    Письменная Елена

    Редактура текста:
    Арончикова Анастасия
    Салыкина Ирина

    Главный художник, художник по персонажам:
    Шишкина Ирина

    Художники локаций:
    Салыкина Ирина
    Арончикова Анастасия
    Шишкина Ирина
    Сорокина Елизавета
    Письменная Елена

    Художник призрачных персонажей:
    Сорокина Елизавета

    Анимация:
    Арончикова Анастасия

    Программист:
    Кулаков Олег

    Музыка:
    Письменный Андрей, при участии Воробьева Романа

    Отдельное спасибо всем тем сотрудникам МЦБС им. М.Ю.Лермонтова, чья работа осталась за кадром, но именно благодаря им мы смогли рассказать эту историю. 
    Все книги, которые использовались в визуальной новелле, вы можете взять в наших библиотеках.
     
     
    """,
        scroll_speed=50,
        display_duration=44
    )
    hide black
    # "Последующее нажатие выведет вас в главное меню"
    return  