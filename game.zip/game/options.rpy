﻿define config.has_autosave = True
define config.has_quicksave = False
define config.autosave_slots = 1
init python:
    config.keymap['toggle_skip'] = []
    config.keymap['skip'] = []
    config.keymap['rollback'] = []
    config.keymap['rollforward'] = []
    config.keymap['self_voicing'] = []
    config.keymap['accessibility'] = []
define config.autosave_on_choice = True   
define config.autosave_on_quit = True  
define config.layers = [ 'background_video', 'master', 'transient', 'screens', 'overlay' ] 
define config.name = _("The Ghosts of the Wesenberg Quarter")
define build.include_update = False                                                             
define build.web_cache_size = 0                                                                 
init python:
    config.hw_video = True  

define gui.show_name = False 
define gui.about = _p("""
""")
define build.name = "The_Ghosts_of_the_Wesenberg_Quarter"
define config.has_sound = True
define config.has_music = True
define config.has_voice = True
define config.main_menu_music = "audio/Name.mp3"
define config.default_music_volume = 0.8
define config.enter_transition = dissolve
define config.exit_transition = dissolve
define config.intra_transition = dissolve
define config.after_load_transition = None
define config.end_game_transition = None
define config.window = "auto"
define config.window_show_transition = Dissolve(.2)
define config.window_hide_transition = Dissolve(.2)
default preferences.text_cps = 30
default preferences.afm_time = 15
define config.save_directory = "TheGhostsoftheWesenbergQuarter-1756362534"
define config.window_icon = "gui/window_icon.png"
init python:
    build.classify('**~', None)
    build.classify('**.bak', None)
    build.classify('**/.**', None)
    build.classify('**/#**', None)
    build.classify('**/thumbs.db', None)
    build.documentation('*.html')
    build.documentation('*.txt')